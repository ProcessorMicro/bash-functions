#!/usr/bin/bash

COMMON_FUNCTIONS_VERSION="10.01.01 - May 05, 2023"

# This script is self documenting. Execute it as a command, it will display documentation.
#   "source"d it will define common functions.
function DO_HELP() {
  PROG="$0"
  grep '^\#\#' "$(type -p functions.sh)" | sed -e 's/^\#\#//'
}
_USAGE_FORMAT_="| fmt --split-only --width ${COLUMNS:-80} --crown-margin "

[[ $0 == $BASH_SOURCE ]] && { eval DO_HELP ${_USAGE_FORMAT_} |& less ; exit ; }

COMMON_FUNCTIONS_CMD="${BASH_SOURCE[0]##*/}"	# The name of this common functions script
COMMON_FUNCTIONS_DIR="${BASH_SOURCE[0]%/*}"	# The directory containing this common functions script

## The following functions are common functions and variables that can be
## invoked/used within user scripts.
##________________________________________________________________________________
##
## This script implements a set of functions that can be used by a parent script.
##   The primary functions included are:
##      GET_ARGS: Option/argument parsing with automatically generated help,
##           version display, parent testing options.
##      IS__EXCLUSIVE: Validates option combinations.
##      ASK: Ask a question (with headers and prompts) and verify the response
##           (automatic parent script exit with "q") and optional GUI dialog.
##           Variations: ASK_WITH_MENU (generated from an array of choices).
##      USAGE: Parent script error display and control.
## It should be 'source'd within the parent script. Vis:
##   source functions.sh' or '. functions.sh
## Two variables SCRIPT_PURPOSE and VERSION should be defined by the script
##   BEFORE this function package is 'source'd as their values are displayed
##   the built-in help (USAGE).
##
## A typical parent script should start with the following 18 lines:
##   ________________________________________________________________________________
##
##   #!/bin/bash
##
##   SCRIPT_PURPOSE="This script ."
##
##   SCRIPT_VERSION="01.01.01 - xxx xx, 202x"
##
##   # Locate common functions.
##   COMMON_FUNCTIONS="$(type -p functions.sh)"
##   if [[ -x ${COMMON_FUNCTIONS} ]] ; then
##     source "${COMMON_FUNCTIONS}"
##   else
##     echo -e "Cannot locate \"${COMMON_FUNCTIONS:-functions.sh}\"." 1>&2
##     exit
##   fi
##
##   GET_ARGS --Args_None \
##     --Opt_D "d:: dummy::@DUM"  --Des_D "This will... DUM defaults to ..." \
##     -- "$@"
##   ________________________________________________________________________________
##
## FUNCTIONS SUMMARY - Full usage info preceeds each function definition.
##     Note: For any function that is called, any options (e.g -V, -N, ...)
##           defined by the function must preceed any function arguments.
##   ASK                Ask a question or, for ASK_WITH_MENU, present a menu of
##                      choices. Verifies the response is one of the choices.
##   ASK_GUI            Similar to ASK but using a GUI interface for the
##                      response. All the options to ASK can be specified.
##   ASK_WITH_MENU      Creates a menu { 1).., 2)... } from an array, displays
##                      it and asks for a choice from the menu.
##   ASK_WITH_MENU_GUI  Similar to ASK_WITH_MENU but using a GUI interface
##                      for the response.
##   CLEANUP_SCRIPT     Standard cleanup function.
##   CLEANUP_ALWAYS     Force CLEANUP even if testing.
##   COLORS_DISPLAY     Display the color variables available.
##   COLORS_SET         Set the color variables $BLK (black), $RED (red), $PUR
##                      (purple) etc. Used with 'echo -e "${RED}...${BLK}...'.
##   DISPLAY_ENVIRONMENT Displays NAMES of functions or values of variables
##                      defined in the script environment.
##   ERROR              Simple error reporting with no "Usage" message.
##   ERROR_GUI          Similar to ERROR but using a GUI interface for the
##                      response. All the options to ERROR can be specified.
##   ERROR_SCRIPT       This script will execute if an ERR signal is raised
##                      and trapped via ERROR_TRAP_SET.
##   ERROR_TRAP_RESET   Reset the ERR trap.
##   ERROR_TRAP_SET     Trap and execute ERROR_SCRIPT on any script error.
##   EXPORT_CLEANUP     Set/Reset everything needed for any child scripts to
##                      execute CLEANUP_SCRIPT in the parent.
##   FIND_NFS_PATH_FROM_FSTAB
##                      Display all the NFS entries or match one NFS entry
##                      in /etc/fstab.
##   GET_ARGS           A function that defines acceptable parent script
##                      arguments and parses them when the parent is invoked.
##   GET_ARGS_DEFAULT   Call this to use the GET_ARGS function in this script.
##   GET_ALL_PC_NAMES   Returns a space-separated lowercase list of valid
##                      PC names Requires variable LOCAL_PCS to be set.
##   GET_IP_FROM_DOMAIN Convert a domain name into an IP address.
##   GET_LOCAL_PC_NAME  Returns (displays) the name of THIS PC. Requires
##                      variable LOCAL_PCS to be set.
##   GET_MATCHING_NFS_DOMAIN_IN_FSTAB
##                      Display the DNS domain of an NFS entry in /etc/fstab
##                      that matches $1.
##   GET_OTHER_PC_NAME  Returns (displays) a PC name from the list of PC names
##                      in this domain excluding the name of this PC.
##   GET_LOCAL_DOMAIN_NAME Returns the (hard coded) name of this PC's DOMAIN.
##   GET_UNIQUE_NFS_DOMAINS_IN_FSTAB
##                      Display all the NFS domain names found in /etc/fstab.
##   HUMAN_READABLE     Displays a number in human readable format.
##   IS_EXCLUSIVE       Returns successfully to the calling script when a valid
##                      combination of options is detected.
##   IS_HEX             Returns TRUE if Arg #1 is formatted as HEXADECIMAL.
##   IS_IP_ALIVE        Analyzes all IP_ARG... (domain names or IP addresses)
##                      to determine if any is active.
##   IS_LOGICAL_VOLUNE  Returns TRUE if $1 is a logical volume, otherwise FALSE.
##   IS_MAC              Returns TRUE if $1 is a MAC address.
##   IS_NUMERIC         Returns TRUS (0) if $1 is numeric; otherwise FALSE.
##   IS_ROOT            Returns TRUE (0) if the UID is "root"; otherwise FALSE.
##   IS_TESTING         Returns TRUE if TESTing is enabled.
##   IS_UUID            Returns TRUE is Arg #1 is formatted as a UUID.
##   MODIFY_GTK_FONT    Set or reset the default font setting for
##                      GTK-based applications.
##   MOUNT_IT           Mount the filesystem $1 onto directory $2 and remember
##                      where it was mounted.
##   UMOUNT_IT          Un-mount the filesystems/devices ($*) mounted by
##                      MOUNT_IT.
##   PAD_IT             Returns a string padded to a specific length with PAD.
##   PAUSE              Waits for a carriage return (<ENTER>) or 'q' to quit.
##   PROGRESS           Displays a "." every $1 times it is called.
##   REVERSE_ARGS       Display the arguments in reverse order.
##   SORT_ARGS          Sort the arguments and display the results. No argument
##                      can have whitepace.
##   SORT_ARGS_WS       Sort the arguments and display the results. Arguments
##                      can have whitepace.
##   ROOT_ONLY          Ensures only 'root' can run this script.
##   TEST_DISPLAY       Display the TESTing variable values.
##   TEST_RESET         Reset the TESTing variables to default and stop TESTing.
##   TEST_SET           Turn on TESTing.
##   TMP_FILE_CREATE    Create a temporary work file/directory that can be
##                      referenced by TMP_NAME_VAR.
##   TMP_DIR_CREATE     Like TMP_FILE_CREATE but creates a temporary directory
##                      rather than a file.
##   TMP_FILE_DELETE    Delete TEMP files or dirs created by TMP_FILE_CREATE.
##   TMP_DIR_DELETE     Like TMP_FILE_DELETE but deletes temporary directories
##                      instead of files.
##   TMP_FILE_PERMANENT Prevent CLEANUP from deleting a TMP file.
##   TMP_DIR_PERMANENT  Prevent CLEANUP from deleting a TMP directory.
##   TRIM               Returns ${1} with surrounding whitespace removed.
##                      Whitespace within ARG1 will not be changed.
##   USAGE              External stub for normal error processing. Calls
##                      USAGE_DEFAULT passing all arguments.
##   USAGE_DEFAULT      Default error and help function.
##   ERROR_SET_PREFIX   Sets the args as a prefix (in red characters) to
##                      proceed any USAGE or ERROR message.
##   ERROR_PREFIX       Alias for ERROR_SET_PREFIX.
##   USAGE_SET          Function to invoke, with an option, the functions
##                      USAGE_FORCE_RETURN, USAGE_SET_EXIT, ERROR_SET_PREFIX
##                      and USAGE_SET_RETURN.
##   USAGE_SET_EXIT     In the script from this point forward, makes the USAGE
##                      and ERROR functions exit with an error code of 1 rather
##                      than return to the script.
##   USAGE_EXIT         Alias for USAGE_SET_EXIT.
##   USAGE_SET_RETURN   In the script from this point forward, makes the USAGE
##                      and ERROR functions return with an error code of 2
##                      rather than exit the script.
##   USAGE_RETURN       Alias for USAGE_SET_RETURN.
##   USAGE_FORCE_RETURN Issue a USAGE message and return even if
##                      IS_USAGE_EXIT="1".
##   USAGE_OBSOLETE     Issue a default message and 'exit' even if IS_USAGE_EXIT
##                      is not set.
##   OBSOLETE           Alternate name for USAGE_OBSOLETE.
##   USAGE_EXIT         Alternate name for USAGE_OBSOLETE with a different
##                      default message ('Exit from script \"${CMD}\" forced.').
##   WARNING            Simple error reporting with no "Usage" message.
##   WARNING_SET_PREFIX Sets the args as a prefix (in purple characters) to
##                      proceed any WARNING or ERROR message.
##   ZERO_FILL          Display a zero-filled NUMBER of size NUM_DIGITS.
##________________________________________________________________________________
##
## Global VARIABLES defined/set are:
##      ANSWER          Variable is set to the answer from ASK and
##                      ASK_WITH_MENU. Is a number, a character, 'y' or 'n'.
##      ANSWER_IDX      Variable is set to the index into the menu item
##                      ARGS/array passed to ASK_WITH_MENU.
##      ANSWER_VAL      Variable is set to the value passed to ASK_WUTH_MENU
##                      that matches the menu choice made.
##      Args[*]         Array containing the non-option arguments in an parent
##                      script. Set by GET_ARGS when parsing script options.
##      BLK RED PUR GLD BLU GRN YEL ORG PNK LIM UL BOLD
##                      Variable strings used in the echo command to display
##                      colored characters.
##                      I.E echo -e "${PUR}purple chars${BLK}black chars."
##      COMMON_FUNCTIONS  Variable is set to the absolute pathname of this
##                      script.
##      COMMON_FUNCTIONS_DIR
##                      Variable is set to the containing directory of this
##                      script.
##      CMD             Variable is set. $CMD is the basename of the script.
##      CMD_DIR         Variable is set. $CMD_DIR is the dirname of the script.
##      CMD_LINE        Variable is set. $CMD_LINE is the command line (quoted)
##                      that invoked the script.
##      _ERROR_MESSAGE_ If an error occurs, contains the error message even
##                      if it is displayed.
##             EXTRA_NL Set to "\n" to add a blank line between USAGE paragaphs.
##      GET_FS_INFO_EOF_CODE
##                      Variable set by GET_FS_INFO to indicate no more
##                      elements found.
##      GET_FS_INFO_ERROR_CODE
##                      Variable set by GET_FS_INFO to indicate an error
##                      occurred.
##      _LOCAL_DOMAIN_ _ALL_PCS_ _LOCAL_PC_ _OTHER_PCS_
##                      Global, exported variables set by the functions
##                      GET_LOCAL_DOMAIN,_NAME GET_LOCAL_PC_NAME,
##                      GET_OTHER_PC_NAME and GET_ALL_PC_NAMES.
##      LOCAL_PCS       A space-separated list of PCs available to the local
##                      network. Used by GET_ALL_PC_NAMES and GET_OTHER_PC_NAME.
##      _MOUNTED_FS_ARRAY_
##                      An array set internally containing the filesystems
##                      mounted by MOUNT_IT. It is unset by default.
##      Opt_x Opt_x_Val Where 'x' is the 1st option name in OPTLIST. Set by
##                      GET_ARGS when parsing script options.
##      Opts_All        A space separated list of every option (i.e. -x)
##                      detected when invoking the script.
##      _PROGRESS_COUNTER_ _PROGRESS_INTERVAL_ _PROGRESS_MAX_
##                      Can be set by the calling script. See the PROGRESS
##                      function below.
##      SCRIPT_PURPOSE  This variable should be set by the script BEFORE
##                      function.sh is 'source'd. It is included in the USAGE
##                      display.
##      SCRIPT_VERSION  This variable should be set by the script BEFORE
##                      function.sh is 'source'd. It is included in the USAGE
##                      display.
##      THIS_PC_DOMAIN  A hard-coded value containing the named domain used
##                      in this PC environment.
##      TEST_xxx        A set of variables used to invoke script testing. See
##                      the function 'TEST_DISPLAY'.
##      _TMP_NAMES_ARRAY_ Variable set internally. An associative array of
##                      the TMP files created by TMP_FILE_CREATE.
##________________________________________________________________________________
##
## COMMANDS/FUNCTIONS executed by this script to set defaults are:
##      shopt -s extglob  Turn on extended pattern expansions.
##      trap CLEANUP_SCRIPT EXIT
##                      Run the cleanup function CLEANUP_SCRIPT on any exit.
##      COLORS_SET      Set the color variables ($RED and $BLK) that will
##                      be used.
##      TEST_RESET      The default is no TESTing.
##      USAGE_SET_EXIT  The default is to exit if the USAGE function is called.
##      ERROR_SET_PREFIX  Set the default USAGE message prefix.

set +o histexpand					# We don't want history expansion in scripts
declare -gx CMD="$(basename "${0#-}")"			# The script file name
declare -gx CMD_DIR="$(dirname "${0#-}")"		# The script file location
declare -gx CMD_LINE=$(sed -e 's/^\/bin\/bash./"/' -e 's/\x0/" "/g' -e 's/ "$//' /proc/$$/cmdline)	# The command line (quoted)
# ###########################################################################################
# In the shell environment execute:  export LOCAL_PCS="pc1 pc2 ..."                         #
# ###########################################################################################
declare -gx LOCAL_PCS=${LOCAL_PCS:=UNDEFINED}   	# List of local PCs to be accessed  #
# ###########################################################################################
declare -gx THIS_PC_DOMAIN="$( hostname -d )"		# The name of PC's home domain

[[ -n $BASH_VERSION ]] && shopt -s extglob		# Turn on extended pattern expansion
unset _ERROR_MESSAGE_ _HEADING_ LOCAL_USAGE _USAGE_OPTIONS_

##________________________________________________________________________________
##
## ASK - Used to ask a question or, for ASK_WITH_MENU, present a menu of
##                      choices. It will verify the response is one of the
##       acceptable choices/answers (or QUIT_CODE) and assign it to the
##                      variable VARIABLE.
##   Usage: ASK ASKCODE [OPTIONS] QUESTION
##   Where:
##     ASKCODE
##       Is a code that indicates what type of response is expected. It also
##       determines the allowed characters in CHIOCES.
##       There is no default ASKCODE. Possible ASKCODE values are:
##         -yn|--yesno
##            The response (CHOICES is ignored) must be 'y' or 'n'.
##         -a|--alpha
##            The alphabetic response(s) must be an alphabetic character from
##            the CHOICES alphabetic RANGE (default [A-Za-z]).
##         -l|--lower
##            The alphabetic response(s) must be a lowercase character from
##            the CHOICES lowercase RANGE (default [a-z]).
##         -u|--upper
##            The alphabetic response(s) must be an uppercase character from
##            the CHOICES uppercase RANGE (default [A-Z]).
##         -k[=LEN]|--key[=LEN]
##            The response can be any number of any character except
##            whitespace. -C CHOICES is required and each choice must be LEN
##            characters long. LEN is a number from 1 to 9. The default for LEN
##            is 1. Acceptable responses must begin with one of the CHOICES.
##         -n|--number|-d|--digit|-r|--range
##            The numeric response(s) must be a positive integer (greater than
##            -1) from the CHOICES numeric RANGE (default [1-99]).
##         -p|--phrase
##            The alphanumeric response must be a phrase created from the set
##            '[A-Za-z0-9_\ \"\']'. No validation is done unless '-C CHOICES'
##            is used.
##         -w|--word
##            The response(s) is/are any multi-character word from the set
##            '[A-Za-z0-9_]'. No validation is done unless '-C CHOICES' is used
##            in which case ANSWER must be an exact match.
##         -e|--everything|--anything
##            Any response is acceptable. No validation is done, '<CTRL-C>'
##            is used to quit and -C CHOICES is ignored. Generates 'pause'.
##     OPTIONS
##       -1 Force the menu choices to be displayed in a single column. The
##          default is a single column for up to 20 lines and wide thereafter.
##       -C CHOICES
##          A space separated list of the choices that can be made
##          (e.g. "a e x") when QUESTION is displayed. The CHOICES list must
##          follow the acceptable set of responses by each ASKCODE below.
##          If ASKCODE is:
##            -n, -d or -r:  ecah CHOICE is a RANGE or an integer > -1
##            -a, -l or -u:  each CHOICE is a RANGE or an alphabetic character
##            -w or -k:      each CHOICE is a word
##            -p:            each CHOICE is a phrase enclosed in single quotes.
##          If -C CHOICES is not specified, an acceptable response is any
##          character(s)/word(s)/RANGE acceptable to the ASKCODE.
##       -D DEFAULTANSWER:
##          DEFAULTANSWER is used as the answer if a null response is
##          returned. It must be one of the acceptable choices. If -D is not
##          used the only acceptable answers are the valid choices or QUITCODE.
##       -G Display the question with a gui interface (dialog box).
##       -H HEADER
##          Display HEADER prior to the list of choices. HEADER can have
##          'echo -e ...' escape sequences.
##       -L LEGEND
##          Add LEGEND before the "Enter your choice..." message that follows
##          the question.
##       -M[=ALL] -C CHOICES
##          Multiple answers. For any valid answer with numeric CHOICES,
##          accept all answers that numerically match the numbers in CHOICES.
##          For any valid answer with non-numeric CHOICES, accept all strings
##          that match the strings in CHOICES.
##          An additional single response of ALL (or the default of "a" for
##          numeric or "all" otherwise) is accepted to return all the choices.
##          In this case VARIABLE will be filled with all the CHOICES.
##          VARIABLE (see -V) is an array (origin-0) containing the responses
##          made in the order they were entered. Option -C is required with -M.
##       -R Return rather than exit from a "quit".
##       -U FILEDESC
##          Use file descriptor FILEDESC to read the response to the
##          question. FILEDESC is a single digit from 3 to 9.
##          The default FILEDESC is 9
##       -V VARIABLE
##          Is the name of a variable that contains the result. The default
##          VARIABLE name is 'ANSWER'. VARIABLE may be referenced as ${VARIABLE}
##          or ${VARIABLE[x]}: x = 0 to the number of VARIABLE elements minus
##          one. For -M, VARIABLE_IDX[x] and VARIABLE_VAL[x] is also created.
##          If the expected result is numeric a numeric comparison with CHOICES
##          is made. However leading zeros are NOT removed in the result.
##       -W Force the menu choices to be displayed multiple columns (wide).
##          The default is a single column for up to 20 lines and wide thereafter.
##       -- Indicates the end of options. The remaining arguments comprise
##          the QUESTION. This is needed only if QUESTION begins with a "-".
##     QUESTION
##       Is a set of lines separated by NEWLINE that is displayed as a
##       prompt. Escape sequences recognized by 'echo -e ...'  may be usedi
##       to format the QUESTION. QUESTION (and HEADER) is displayed on STDERR
##     RANGE
##       A numeric RANGE has the format 'm-n' or 'm thru n' (m > n).
##       If ASKCODE is:
##         -n or -r:  m and n must be positive integers.
##         -a:        m and n must be a lowercase character.
##         -u:        m and n must be an uppercase character.
##       Examples:  ASK -C '1-5' -n ...  or  ASK -C '6 thru 10' -r ...
##                  ASK -C "a-e" -a ...  or  ASK -C "F thru J' -u ...
##     QUITCODE
##       Is "q" unless "q" is one if the CHOICES in which case it is "qq"
##       or "qqq" or ....
##       Responding with QUITCODE causes an immediate exit from the calling
##       script unless USAGE_RETURN has been called.
##     The return code is 0 (true) for all valid responses, is 1 (false) for a
##     'n' response to a yn choice) or 2 (false) for a QUITCODE.
function ASK() {
  unset _ASK_WITH_GUI_
  _ASK_DOIT_ "$@"
}
unset _ASK_WITH_GUI_

##________________________________________________________________________________
##
## ASK_GUI - Equivalent to 'ASK -G'. Usies a GUI interface for the response.
##   All the options of ASK can be specified. The <OK> button simulates a
##   default response that returns a null answer unless the -D option is used.
##   The <Cancel> button is equivalent to the QUIT_CODE (q or qq).
function ASK_GUI() {
  _ASK_WITH_GUI_="1"
  _ASK_DOIT_ "$@"
}

function _ASK_DOIT_() {
  local __ANSWER_ORIG__ __ANSWER__ ASK_ERROR ASK_TYPE ASK_CODE CHOICE CHOICES _DEFAULT_ANSWER_ _DEFAULT_ANSWER_MESSAGE_ _DEFAULT_CHOICE_
  local MULTI_CHOICES THE_CHOICES THE_CHOICES_ORIG THE_CHOICES_ERR THE_CHOICES_PROMPT KEY_PREFIX=999 ASK_RETURN
  local _THE_ASK_HEADER_ _THE_ASK_MENU_ MAX_SINGLE_COLUMN="20" SINGLE_COLUMN="0" MENU_COLUMNS="0" QUIT_ME="q"
  local _Alpha_Acceptable_="[a-z]"  _Error_Prompt_ _Menu_Prompt_="Enter your choice" _Multiple_Menu_all_="a" _Multiple_Menu_Prompt_
  local _ASK_LEGEND_ _CTRL_C_TO_QUIT_ _PTS_ _FILE_DESC_="9"
  _DEFAULT_ANSWER_VARIABLE_="ANSWER"
  LOCAL_USAGE="1"
  _CTRL_C_TO_QUIT_="0"
  while true ; do
    case "$1" in
      -1)	#|--single-column)
          SINGLE_COLUMN="1"
          MENU_COLUMNS="0" ;;
      -C)	#|--choices)
          THE_CHOICES="$( sed -e 's/ \+/ /g' -e 's/^ //' -e 's/ $//' <<<"${2}" )"	# Normalize the valid choices
          THE_CHOICES_ORIG="$2"
          shift 1 ;;
      -D)	#|--default)
          _DEFAULT_ANSWER_="$2"				# The default answer if "OK" or "<Enter>"
          _DEFAULT_CHOICE_="$2"
          _DEFAULT_ANSWER_MESSAGE_=", default: ${_DEFAULT_ANSWER_@Q}"
          shift 1 ;;
      -G)	#|--gui)				# The GUI version
          _ASK_WITH_GUI_="1" ;;
      -H)	#|--header)
          _THE_ASK_HEADER_="${2}\n"			# The header to display
          shift 1 ;;
      -L)	#|--legend
          _ASK_LEGEND_="$2"
          shift 1 ;;
      -M*)	#|--multiple-choices*)
          MULTI_CHOICES="1"
          _Menu_Prompt_="Enter multiple choices:"
          _Multiple_Menu_Prompt_=" or \";;;\" for all"
          [[ $1 =~ = ]] && _Multiple_Menu_all_="${1#*=}"
          _Error_Prompt_=" or more" ;;
      -R)	#|--return
          ASK_RETURN="1" ;;
      -U) [[ $2 =~ ^[3-9]$ ]] || ERROR "${COMMON_FUNCTIONS_CMD}: ASK: Invalid file descriptor \"-U $2\"."
          _FILE_DESC_="$2"
          shift 1 ;;
      -V)	#|--variable)
          _DEFAULT_ANSWER_VARIABLE_="$2"		# The variable that will contain the response
          [[ ${_DEFAULT_ANSWER_VARIABLE_} == ANSWER ]] && unset ANSWER || local ANSWER
          shift 1 ;;
      -W)	#|--wide)
          MENU_COLUMNS="1"
          SINGLE_COLUMN="0" ;;
       --) shift 1 ; break ;;				# '--' indicates the end of options
       -*|--*)
          if [[ -z ${ASK_CODE} ]] ; then		# Any  other arg starting with '-' or '--' must be an ask code
            ASK_CODE="$1"
          else
           ERROR "ASK: ASKCODE \"$1\" conflicts with \"${ASK_CODE}\". Only one ASKCODE is allowed."
          fi
          ;;
       *) break ;;					# No more options
    esac
    shift 1
  done
  case "${ASK_CODE//-/}" in				# ASK_CODE (without '-' or '--') is the type of question.
    yn|yesno)
      ASK_TYPE="Y"
      THE_CHOICES="y n"
      THE_CHOICES_ERR="y, n"
      THE_CHOICES_PROMPT="(${THE_CHOICES_ERR} or ${QUIT_ME} to quit${_DEFAULT_ANSWER_MESSAGE_})"
      ;;
    a|alpha*)
      ASK_TYPE="A"
      [[ -z ${_Multiple_Menu_all_} ]] && _Multiple_Menu_all_="all"
      _Acceptable_1_="^\s*[A-Za-z]\s*$"
      _Acceptable_M_="^\s*([A-Za-z] +)*[A-Za-z]\s*$|^\s*;;;\s*$"
      [[ ${THE_CHOICES/thru/ } =~ [^-iA-Za-z\ ] ]] && _ASK_USAGE_CHOICE_ "${ASK_CODE}"
      _ASK_NORMALIZE_RANGE_ "${THE_CHOICES:=A thru z}" 1 || _ASK_USAGE_CHOICE_ "${ASK_CODE}"
      ;;
    l|lower*)
      ASK_TYPE="A"
      [[ -z ${_Multiple_Menu_all_} ]] && _Multiple_Menu_all_="all"
      _Acceptable_1_="^\s*[a-z]\s*$"
      _Acceptable_M_="^\s*([a-z] +)*[a-z]\s*$|^\s*;;;\s*$"
      [[ ${THE_CHOICES/thru/ } =~ [^-a-z\ ] ]] && _ASK_USAGE_CHOICE_ "${ASK_CODE}"
      _ASK_NORMALIZE_RANGE_ "${THE_CHOICES:=a thru z}" 1 || _ASK_USAGE_CHOICE_ "${ASK_CODE}"
      ;;
    u|upper*)
      ASK_TYPE="A"
      [[ -z ${_Multiple_Menu_all_} ]] && _Multiple_Menu_all_="all"
      _Acceptable_1_="^\s*[A-Z]\s*$"
      _Acceptable_M_="^\s*([A-Z] +)*[A-Z]\s*$|^\s*;;;\s*$"
      [[ ${THE_CHOICES/ thru/} =~ [^-A-Z\ ] ]] && _ASK_USAGE_CHOICE_ "${ASK_CODE}"
      _ASK_NORMALIZE_RANGE_ "${THE_CHOICES:=A thru Z}" 1 || _ASK_USAGE_CHOICE_ "${ASK_CODE}"
      ;;
    n|number|d|digit|r|range)
      ASK_TYPE="N"
      _Acceptable_1_="^\s*[0-9]{1,2}\s*$"
      _Acceptable_M_="^\s*([0-9]{1,2} +)*[0-9]{1,2}\s*$|^\s*;;;\s*$"
      [[ ${THE_CHOICES/ thru/} =~ [^-0-9\ ] ]] && _ASK_USAGE_CHOICE_ "${ASK_CODE}"
      _ASK_NORMALIZE_RANGE_ "${THE_CHOICES:=1 thru 99}"
      ;;
    k*|key*)
      ASK_TYPE="K"
      KEY_PREFIX="${ASK_CODE#*=}"			# How many characters for the KEY
      [[ ${KEY_PREFIX:=1} == [1-9] ]] ||  _USAGE_CHOICE_ "ASK: For \"${ASKCODE}\" the length LEN must be a number from 1 to 9."
      if [[ -z ${THE_CHOICES} ]] ; then
         _USAGE_CHOICE_ "ASK: The option -C CHOICES is required for \"${ASK_CODE}\"."
      else
        local Idx TheChoices
        TheChoices=( ${THE_CHOICES} )
        for Idx in ${!TheChoices[*]} ; do
          (( ${#TheChoices[Idx]} != KEY_PREFIX )) &&  _USAGE_CHOICE_ "ASK: With ASKCODE \"${ASK_CODE}\" choice \"${TheChoices[Idx]}\" must be ${KEY_PREFIX} characters long."
        done
        THE_CHOICES_ERR="${TheChoices[*]}"
        THE_CHOICES_ERR="${THE_CHOICES_ERR// /, }"
        THE_CHOICES_PROMPT="(${THE_CHOICES_ERR}${_Multiple_Menu_Prompt_} or ${QUIT_ME} to quit${_DEFAULT_ANSWER_MESSAGE_})"
      fi
      _Acceptable_1_="^.*$"
      _Acceptable_M_="^.*$"
      _ASK_QUIT_ME_ "${THE_CHOICES}"
      ;;
    p|phrase)
      ASK_TYPE="P"
      THE_CHOICES="${THE_CHOICES_ORIG}"			# No modification done on the choices
      if [[ -n ${THE_CHOICES} ]] ; then
        [[ ${THE_CHOICES} =~ [^-A-Za-z0-9_\ \"\'] ]] && _ASK_USAGE_CHOICE_ "${ASK_CODE}"
        THE_CHOICES_ERR="${THE_CHOICES}"
      else
        THE_CHOICES_ERR="an alphanumeric phrase"
      fi
      _ASK_QUIT_ME_ "${THE_CHOICES}"
      THE_CHOICES_PROMPT="(${THE_CHOICES_ERR} or ${QUIT_ME} to quit${_DEFAULT_ANSWER_MESSAGE_})"
      ;;
    w|word)
      ASK_TYPE="W"
      [[ -z ${_Multiple_Menu_all_} ]] && _Multiple_Menu_all_="all"
      _Acceptable_1_="^\s*[[:alnum:]]+\s*$"
      _Acceptable_M_="^\s*([[:alnum:]]+ +)*[[:alnum:]]+\s*$|^\s*;;;\s*$"
      [[ ${THE_CHOICES} =~ [^-A-Za-z0-9_\ ] ]] && _ASK_USAGE_CHOICE_ "${ASK_CODE}"
      _ASK_QUIT_ME_ "${THE_CHOICES}"
      [[ -z ${THE_CHOICES} ]] && THE_CHOICES_ERR="type one${_Error_Prompt_} word" || THE_CHOICES_ERR="${THE_CHOICES// /, }"
      THE_CHOICES_PROMPT="(${THE_CHOICES_ERR}${_Multiple_Menu_Prompt_} or ${QUIT_ME} to quit${_DEFAULT_ANSWER_MESSAGE_})"
      ;;
    e|everything|anything)
      ASK_TYPE="E"
      THE_CHOICES_PROMPT="(Enter anything or <CTRL-C> to quit${_DEFAULT_ANSWER_MESSAGE_})"
      _CTRL_C_TO_QUIT_=1
      ;;
    *)
      _USAGE_CHOICE_ "ASK: The ASKCODE \"${1:0:8}\" is not valid or missing."
      ;;
  esac

  if (( MULTI_CHOICES )) ; then
    [[ ${ASK_TYPE} =~ [EPY] ]] && THE_CHOICES_ERR="You cannot use OPTION --multi-choices with ASKTYPE \"--everything\", \"--phrase\" or \"--yesno\"."
    [[ -z ${THE_CHOICES} ]] && THE_CHOICES_ERR="You must use OPTION -C with OPTION -M."
    _Acceptable_="${_Acceptable_M_}"
    _Acceptable_="${_Acceptable_/;;;/${_Multiple_Menu_all_}}"
    _Multiple_Menu_Prompt_="${_Multiple_Menu_Prompt_/;;;/${_Multiple_Menu_all_}}"
    THE_CHOICES_PROMPT="${THE_CHOICES_PROMPT/;;;/${_Multiple_Menu_all_}}"
  else
    _Acceptable_="${_Acceptable_1_}"
  fi
  THE_CHOICES=" ${THE_CHOICES} "			# Surround the choices with a space
  _THE_ASK_MENU_="$*"
  if (( ( $# > MAX_SINGLE_COLUMN && ! SINGLE_COLUMN ) || MENU_COLUMNS )) ; then
    FORMAT_OUT="column"
  else
    FORMAT_OUT="cat"
  fi
  while true ; do					# Now display the question/menu
    unset __ANSWER_ORIG__ ${_DEFAULT_ANSWER_VARIABLE_}
    if (( _ASK_WITH_GUI_ )) ; then
      MODIFY_GTK_FONT -s -f "Monospace 14"
      __ANSWER_ORIG__="$( yad --fixed --center --nowrap --entry --entry-text="${_DEFAULT_CHOICE_}" --button=yad-quit:2 --button=yad-ok:0 --title "Make a Choice" --text "$( _ASK_MENU_TEXT_ )" 2>/dev/null )"
      (( $? == 2 )) && __ANSWER_ORIG__="${QUIT_ME}"
      MODIFY_GTK_FONT -r -f "Monospace 14"
      _OLD_ASK_WITH_GUI_="${_ASK_WITH_GUI_}"
      unset _ASK_WITH_GUI_
    else
      _ASK_MENU_TEXT_					# Display the "menu"
      _PTS_=( $( ps -p $$ -h ) )			# Find the character special path for my input device
      [[ ${_PTS_[1]} =~ ^pts/[0-9]+$ ]] || ERROR "${COMMON_FUNCTIONS_CMD}: ASK: No input device (keyboard) available."
      eval exec ${_FILE_DESC_}\</dev/${_PTS_[1]}	# Open a temporary input file descriptor so no conflict with I/O redirection
      if [[ ${ASK_TYPE} =~ [EK] ]] ; then
        # Accept all characters - even trailing spaces
        IFS="" read -u ${_FILE_DESC_} -r __ANSWER_ORIG__ || ERROR "Code=$?: ${COMMON_FUNCTIONS_CMD}: ASK: While reading the response."
      else
      # Record the original response
        read -u ${_FILE_DESC_} __ANSWER_ORIG__ || ERROR "Code=$?: ${COMMON_FUNCTIONS_CMD}: ASK: While reading the response."
      fi
      eval exec ${_FILE_DESC_}\<\&-			# Close the temporary input file descriptor
    fi
    [[ -z ${__ANSWER_ORIG__} ]] && __ANSWER_ORIG__="${_DEFAULT_ANSWER_}"
    eval ${_DEFAULT_ANSWER_VARIABLE_}=\( \${__ANSWER_ORIG__} \)	# Answers are an array (multiple elements if -M, otherwise 1 element)
    if [[ ${__ANSWER_ORIG__} == ${QUIT_ME} && ${_CTRL-C_TO_QUIT_} != 1 ]] ; then
      (( ASK_RETURN )) && return 2
      (( IS_USAGE_EXIT )) && exit 2 || return 2
    fi
    case "${ASK_TYPE}" in
      Y)						# Check for "Y" type to allow for a y or n response in a menu
        __ANSWER__="${__ANSWER_ORIG__:0:1}"		# Only look at the 1st character
        case "${__ANSWER__,,}" in
          y) return 0 ;;				# Return 'true'
          n) return 1 ;;				# Return 'false'
        esac
        ;;
      E)
        unset ${_DEFAULT_ANSWER_VARIABLE_}
        eval ${_DEFAULT_ANSWER_VARIABLE_}=\"\${__ANSWER_ORIG__}\"	# The answer is a scaler containing any characters
        return 0
        ;;
      N|A)						# A SINGLE alphabetic or numeric character (menu selection)
        _ASK_VERIFY_ANSWER_ && return 0
        ;;
      W|K)						# Check for multiple-character single word response
        _ASK_VERIFY_ANSWER_ && return 0
        ;;
      P)						# Check for phrases (in quotes)
        eval ${_DEFAULT_ANSWER_VARIABLE_}=\"\${__ANSWER_ORIG__}\"	# For a phrase the ANSWER is a scaler
        if [[ ${THE_CHOICES// /} =~ ^$ ]] ; then
          return 0					# No chioces so accept what is entered
        else
          PFXSFX="[\"']*"
          [[ ${THE_CHOICES} =~ \ ${PFXSFX}${__ANSWER_ORIG__}${PFXSFX}\  ]] && return 0
        fi
        ;;
    esac
    if [[ ${ASK_TYPE} =~ [PW] && -z ${THE_CHOICES// /} ]]
      then ASK_ERROR="\nResponse \"${__ANSWER_ORIG__}\" is incorrect.\n"
      else ASK_ERROR="\nResponse \"${__ANSWER_ORIG__}\" is incorrect.\nYou must respond with one${_Error_Prompt_} of the choices shown.\n"
    fi
    _ASK_WITH_GUI_="${_OLD_ASK_WITH_GUI_}"
  done
}

function _ASK_MENU_TEXT_() {
  echo -en "${ASK_ERROR}${_THE_ASK_HEADER_}"
  echo -en "${_THE_ASK_MENU_}" | expand | ${FORMAT_OUT}
  echo -en "\n${_ASK_LEGEND_}${_Menu_Prompt_} ${THE_CHOICES_PROMPT}: "
}

function _ASK_NORMALIZE_RANGE_() {
  local _THE_CHOICES_="${1/ thru /..}"
  _THE_CHOICES_="${_THE_CHOICES_/-/..}"
  if [[ ${_THE_CHOICES_} =~ ".." ]] ; then
    eval _THE_CHOICES_=\( {${_THE_CHOICES_}} \)
    THE_CHOICES=" ${_THE_CHOICES_[*]} "
    if (( ${#_THE_CHOICES_[*]} > 8 )) ; then
      THE_CHOICES_ERR="${_THE_CHOICES_[0]} thru ${_THE_CHOICES_[-1]}"
    else
      THE_CHOICES_ERR="${_THE_CHOICES_[*]}"
      THE_CHOICES_ERR="${THE_CHOICES_ERR// /, }"
    fi
  else
    if (( 0$2 == 1 )) ; then				# The set of choices must be single characters
      local TCa TCs
      TCa=( ${1} ) ; TCs=${TCa[*]}			# Create an array and a scalar of the choices
      (( ${#TCa[*]} * 2 - 1 == ${#TCs} )) || return 1	# Compare the number of array entries (plus separators) with the length of the scalar
    fi
    THE_CHOICES="${1}"
    THE_CHOICES_ERR="${1// /, }"
  fi
  if [[ ${ASK_TYPE} =~ [NR] ]] ; then
    THE_CHOICES="$( gawk '{print gensub(/(0+)([0-9])/, "\\2", "g")}' <<<"${THE_CHOICES}" )"
    THE_CHOICES_ERR="$( gawk '{print gensub(/(0+)([0-9])/, "\\2", "g")}' <<<"${THE_CHOICES_ERR}" )"
  fi
  THE_CHOICES_ORIG="${1}"
  _ASK_QUIT_ME_ "${THE_CHOICES}"
  THE_CHOICES_PROMPT="(${THE_CHOICES_ERR}${_Multiple_Menu_Prompt_} or ${QUIT_ME} to quit${_DEFAULT_ANSWER_MESSAGE_})"
}

function _ASK_QUIT_ME_() {
  while [[ " ${1} " =~ " ${QUIT_ME} " ]] ; do
    QUIT_ME+="q"					# Ensure there is a code to exit ASK (q or qq or qqq or ...)
  done
}

function _ASK_USAGE_CHOICE_() {
  _USAGE_CHOICE_ "ASK: Choices \"${THE_CHOICES}\" is invalid or has a character not acceptable to the choice type \"$1\"."
}

function _ASK_VERIFY_ANSWER_() {
  local _Answer_Orig_ _Bad_ _Token_
  if [[ ${__ANSWER_ORIG__} =~ ${_Acceptable_} ]] ; then
    if [[ ${ASK_TYPE} =~ [NR] ]] ; then
      _Answer_Orig_="$( gawk '{print gensub(/(0+)([0-9])/, "\\2", "g")}' <<<"${__ANSWER_ORIG__}" )"
    else
      _Answer_Orig_="${__ANSWER_ORIG__}"
    fi
    [[ -z ${THE_CHOICES// /} ]] && return 0		# No choices == any valid response acceptable
    if (( MULTI_CHOICES )) ; then
      if [[ ${__ANSWER_ORIG__} == ${_Multiple_Menu_all_} ]] ; then
        eval ${_DEFAULT_ANSWER_VARIABLE_}=\( ${THE_CHOICES} \)
        return 0
      fi
    fi
    for _Token_ in ${_Answer_Orig_} ; do
      [[ "${THE_CHOICES} " =~ \ ${_Token_:0:${KEY_PREFIX}}\  ]] || _Bad_="1"
    done
    (( ! _Bad_ )) && return 0
  fi
  return 1
}

##________________________________________________________________________________
##
## ASK_WITH_MENU - Creates a menu { 1).., 2)... } from an array, displays it and
##     asks for a choice from the menu.
##   Usage: ASK_WITH_MENU [OPTIONS] { ARRAYNAME | ARGS }
##   OPTIONS are:
##     -A Use an alphabetic charaacter ([a-zA-Z]) as the menu choice rather
##        than a number.
##     -D DEFAULTANSWER
##        Is used as the answer if a null response is given. It must be one of
##        the menu choices.
##     -G Display the menu with a gui interface.
##     -H HEADER
##        Is displayed prior to the menu items.
##     -L LEGEND
##        Add LEGEND before the "Enter your choice..." message that follows
##        the question.
##     -M[=ALL]
##        Same as for ASK but option -C CHOICES is generated automatically
##        from ARRAYNAME/ARGS
##     -R Return rather than exit after a "quit".
##     -V VARIABLE
##        VARIABLE Is the name of an array variable that contains the result.
##        The default VARIABLE name is 'ANSWER'.
##   ARRAYNAME or ARGS
##     Either: ARRAYNAME: If there is a single argument, then it is assumed
##             to be ARRAYNAME which is the name of an array containing the
##             menu items. It can be a sparse (non contiguous) indexed or an
##             associative array. For the latter, the order of the displayed
##             menu items is indeterminant.
##     Or:     ARGS: If there is more tnan one argument then ARGS are the menu
##             items from which a choice is made.
##             ARGS is converted into an array (index at 0).
##     Returns, as an answer, three arrays (origin-0) indexed x = 0 to number
##       of array VARIABLE elements minus one.
##         VARIABLE[x]:     The menu number of the choice made.
##         VARIABLE_IDX[x]: The index into ARRAYNAME or the ARGSi 'position'.
##         VARIABLE_VAL[x]: The menu item text. I.E. The value of
##                          ARRAYNAME[${VARIABLE_IDX}] or ARGSi (based upon the
##                          choice(s) made).
function ASK_WITH_MENU() {
  local -A _ARRAY_ITEM_MAP_
  local _ARRAY_IS_ARGS_ _IDX_ _IDX1_ _MENU_IDX_ _THE_ARRAY_ _THE_INDICES_ _THE_MENU_=""
  local _CHOOSE_FROM_ _MENU_CHOICE_ _MENU_CHOICES_ _MENU_TYPE_="-n" _MENU_IDX_="0"
  local _MENU_ANSWER_ _MENU_ANSWER_VARIABLE_="ANSWER" _MULTI_CHOICE_
  local _MAX_SINGLE_COLUMN_="20" _SINGLE_COLUMN_="1" _MENU_COLUMNS_="0"
  local _ASK_MULTIPLE_MENU_all_="XxXxX" _ASK_OPTIONS_ _ASK_RETURN_
  unset _ASK_OPTIONS_
  while true ; do
    case "${1}" in
      -1)	#|--single-column)			# The default
          _SINGLE_COLUMN_="1"
          _MENU_COLUMNS_="0" ;;
      -A)	#|--alpha)
          _MENU_CHOICES_=( {a..z} {A..Z} )		# Max = 52 alpha choices
          _MENU_TYPE_="-a" ;;
      -D)	#|--default)
          _DEFAULT_ANSWER_="$2"				# The default answer if "OK" or "<Enter>"
          _DEFAULT_ANSWER_MESSAGE_=", default: ${_DEFAULT_ANSWER_}"
          shift 1 ;;
      -G)	#|--gui)				# The GUI version
          _ASK_OPTIONS_+=( $1 ) ;;
      -H)	#|--header)				# Check if a menu header is requested.
          _ASK_OPTIONS_+=( $1 "$2" )
          shift 1 ;;
      -L)	#|--legend
          _ASK_OPTIONS_+=( $1 "$2" )
          shift 1 ;;
      -M*)	#|--multiple-choices)
          _ASK_MULTIPLE_="$1" ;;
      -R)	#|--return
          _ASK_RETURN_="1"
          _ASK_OPTIONS_+=( $1 ) ;;
      -V)	#|--variable)				# The variable that will contain the response
          _MENU_ANSWER_VARIABLE_="$2"
          shift 1 ;;
      -W)	#|--wide)
          _MENU_COLUMNS_="1"
          _SINGLE_COLUMN_="0" ;;
       *) break ;;					# No more options
    esac
    shift 1
  done
  if [[ -n ${_ASK_MULTIPLE_} ]] ; then
    if [[ ! ${_ASK_MULTIPLE_} =~ = ]] ; then
      [[ ${_MENU_TYPE_} == -a ]] && _ASK_MULTIPLE_="-M=all" || _ASK_MULTIPLE_="-M=a"
    fi
    _ASK_MULTIPLE_MENU_all_="${_ASK_MULTIPLE_#*=}"
    _ASK_OPTIONS_+=( ${_ASK_MULTIPLE_} )
  fi
  unset ${_MENU_ANSWER_VARIABLE_} ${_MENU_ANSWER_VARIABLE_}_IDX ${_MENU_ANSWER_VARIABLE_}_VAL
  (( ${#_MENU_CHOICES_[*]} == 0 )) && _MENU_CHOICES_=( {1..99} )	# Max = 99 numeric choices
  if (( $# == 1 )) ; then				# Must create an array of the menu items
    eval _THE_ARRAY_=( \"\${$1[@]}\" )			# Only one arg = the name of an array containing the menu items
    eval _THE_INDICES_=( \"\${!$1[@]}\" )		# Remember the original indices
  else
    _THE_ARRAY_=( "${@}" )				# The menu items are arguments
    _THE_INDICES_=( "${!_THE_ARRAY_[@]}" )		# Remember the generated indices
    _ARRAY_IS_ARGS_="1"
  fi
  (( ${#_THE_ARRAY_[@]} == 0 )) && return 1		# There are no items in the menu array
  for _IDX_ in "${!_THE_ARRAY_[@]}" ; do		# Process all the menu items
    [[ -z ${_THE_ARRAY_[_IDX_]} ]] && continue		# But ignore empty ones
    _MENU_CHOICE_="${_MENU_CHOICES_[_IDX_]}"
    _CHOOSE_FROM_+=( ${_MENU_CHOICE_} )
    # Because some elements may be ignored or if we have an associative array we must map the menu item with the choice number
    _ARRAY_ITEM_MAP_[${_MENU_CHOICE_}]="${_THE_INDICES_[_IDX_]}"
    # Align the single-digit numerical choices. Assumes no more than '2-digit' number of choices.
    if IS_NUMERIC "${#_MENU_CHOICE_}" ; then
      (( ${#_MENU_CHOICE_} == 1 )) && _MENU_CHOICE_=" ${_MENU_CHOICE_}"
    fi
    _THE_MENU_+="   ${_MENU_CHOICE_}  ${_THE_ARRAY_[_IDX_]}\n"
  done
  if (( ( ${_IDX_} > _MAX_SINGLE_COLUMN_ &&  ! _SINGLE_COLUMN_ ) || _MENU_COLUMNS_ )) ; then
    _ASK_OPTIONS_+=( -W )
    _THE_MENU_+="\n"					# Wide needs an extra NL
  else
    _ASK_OPTIONS_+=( -1 )				# Otherwise get rid of the final NL
    _THE_MENU_="${_THE_MENU_%\\n}"
  fi
  (( ${#_CHOOSE_FROM_[*]} > 8 )) && _MENU_CHOICES_="${_CHOOSE_FROM_[0]} thru ${_CHOOSE_FROM_[-1]}" || _MENU_CHOICES_="${_CHOOSE_FROM_[*]}"
  _ASK_DOIT_ ${_MENU_TYPE_} -C "${_MENU_CHOICES_}" "${_ASK_OPTIONS_[@]}" -V _MENU_ANSWER_ "${_THE_MENU_}\n"
  if (( $? == 2 )) ; then				# ==> quit
    (( _ASK_RETURN_ )) && return 2
    (( IS_USAGE_EXIT )) && exit 2 || return 2
  fi
  [[ ${_MENU_ANSWER_} =~ ${_ASK_MULTIPLE_MENU_all_} ]] && _MENU_ANSWER_=( ${_CHOOSE_FROM_[*]} )
  eval ${_MENU_ANSWER_VARIABLE_}=\( \${_MENU_ANSWER_[\*]} \)
  for _IDX_ in  ${!_MENU_ANSWER_[*]} ; do		# The answers, answer indices and answer values are arrays
    eval _IDX1_="${_ARRAY_ITEM_MAP_[${_MENU_ANSWER_[_IDX_]}]}"
    eval ${_MENU_ANSWER_VARIABLE_}_IDX[_IDX_]=\"${_IDX1_}\"
    if (( _ARRAY_IS_ARGS_ )) ; then
      eval ${_MENU_ANSWER_VARIABLE_}_IDX[_IDX_]=$(( _IDX1_ + 1 ))	# The index for arguments is origin-1
      eval ${_MENU_ANSWER_VARIABLE_}_VAL[_IDX_]=\"\${$((_IDX1_ + 1 ))}\"
    else
      eval ${_MENU_ANSWER_VARIABLE_}_VAL[_IDX_]=\"\${$1[${_IDX1_}]}\"
    fi
  done
}

##________________________________________________________________________________
##
## ASK_WITH_MENU_GUI - Equivalent to 'ASK_WITH_MENU -G'.
##   All the options of ASK can be specified. The <OK> button simulates a
##   default response that returns a null answer unless the -D option is used.
##   The <Cancel> button is equivalent to the QUIT_CODE (q or qq).
function ASK_WITH_MENU_GUI() {
  _ASK_WITH_GUI_="1"
  ASK_WITH_MENU "$@"
}

##________________________________________________________________________________
##
## CLEANUP_SCRIPT - Standard cleanup function.
##   The command 'trap CLEANUP_SCRIPT EXIT' is executed by this function.
##    CLEANUP_SCRIPT un-mounts any filesystems (remembered in
##      ${_MOUNTED_FS_ARRAY_}) mounted by MOUNT_IT.
##    CLEANUP_SCRIPT then removes any names (files and directories) created
##      by TMP_FILE_CREATE ir TMP_DIR_CREATE.
##    Before cleaning up, CLEANUP_SCRIPT calls the function
##      CLEANUP_EXTRAS_BEFORE, if it is defined, so additional clean-up actions
##      can be before CLEANUP_SCRIPT is executed.
##    After cleaning up,  CLEANUP_SCRIPT calls the function
##      CLEANUP_EXTRAS_AFTER,  if it is defined,
##      so additional clean-up actions can be after CLEANUP_SCRIPT is executed.
##   Set the variable _CLEANUP_ALWAYS_ or call the function CLEANUP_ALWAYS to
##      ensure CLEANUP is run even if testing.
##   If "TESTing", the default is to display the cleanup commands rather
##     than execute them.
function CLEANUP_SCRIPT() {
  local FS
  if (( _CLEANUP_ALWAYS_ )) ; then
    unset TEST_CMD
    echo -e "CLEANUP scripts will execute."
  else
    TEST_CMD="$( sed 's/:/ CLEANUP_SCRIPT:/'<<<"${TEST_CMD}" )"
  fi
  type -t CLEANUP_EXTRAS_BEFORE >/dev/null && CLEANUP_EXTRAS_BEFORE	# Execute function CLEANUP_EXTRAS if it is defined
  ${TEST_CMD} UMOUNT_IT --ALL
  ${TEST_CMD} TMP_FILE_DELETE -A					# Delete any temporary files created by TMP_FILE_CREATE
  ${TEST_CMD} TMP_DIR_DELETE -A						# Delete any temporary dirs created by TMP_DIR_CREATE
  type -t CLEANUP_EXTRAS >/dev/null && ${TEST_CMD} echo -e "function 'CLEANUP_EXTRAS' defined in '$CMD'.\nChange it to \"CLEANUP_EXTRAS_BEFORE\" or \"CLEANUP_EXTRAS_AFTER\".."  # Function name CLEANUP_EXTRAS is now obsolete
  type -t CLEANUP_EXTRAS_AFTER >/dev/null && ${TEST_CMD} CLEANUP_EXTRAS_AFTER	# Execute function CLEANUP_EXTRAS if it is defined
}
trap CLEANUP_SCRIPT EXIT				# run the cleanup function on any exit
unset _CLEANUP_ALWAYS_

##________________________________________________________________________________
##
## CLEANUP_ALWAYS - Force CLEANUP even if testing.
##   Sets the variable _CLEANUP_ALWAYS_ to ensure CLEANUP is run even if testing.
function CLEANUP_ALWAYS() {
  _CLEANUP_ALWAYS_="1"
}

##________________________________________________________________________________
##
## COLORS_DISPLAY - Display  the color variables $BLK (black), $RED (red), ...
function COLORS_DISPLAY() {
  echo -e "BLK=${BLK}BLK${BLK}    RED=${RED}RED${BLK}      PUR=${PUR}PUR${BLK}     GLD=${GLD}GLD${BLK}   BLU=${BLU}BLU${BLK}"
  echo -e "GRN=${GRN}GRN${BLK}    YEL=${YEL}YEL${BLK}      ORG=${ORG}ORG${BLK}     PNK=${PNK}PNK${BLK}   LIM=${LIM}LIM${BLK}"
  echo -e " UL=${UL}UL${BLK}    BOLD=${BOLD}BOLD${BLK}    GREP=${GREP}GREP${BLK}"
}

##________________________________________________________________________________
##
## COLORS_SET - Set the color variables $BLK (black), $RED (red), ...
##   $GLD (gold). Used with 'echo -e "${RED}...${BLK}...'
function COLORS_SET() {
  declare -gx BLK="\\033[0m"   RED="\\033[38;5;198m" PUR="\033[38;5;129m" GLD="\033[38;5;220m" BLU="\033[38;5;33m"
  declare -gx GRN="\\033[46m"  YEL="\\033[38;5;226m" ORG="\033[38;5;208m" PNK="\033[38;5;207m" LIM="\033[38;5;118m"
  declare -gx  UL="\\033[4m"  BOLD="\\033[1m"       GREP="\033[38;5;201m"
}

COLORS_SET						# Set the color variables that will be used.

##________________________________________________________________________________
##
## DISPLAY_ENVIRONMENT - Displays NAMES of functions or values of variables
##     defined in the script environment.
##   Usage: DISPLAY_ENVIRONMENT [ -f | -F -v ] [ NAMES ]
##   Where: -f  Display the definition of environment functions named by NAMES.
##          -F  Display only the name of environment functions named by NAMES.
##          -v  Display the values of environment variables named by NAMES as
##              an assignment NAME="VALUE".
##   Option -v is the default.
##   Each NAME is a grep expression used to display one or more NAMES.
function DISPLAY_ENVIRONMENT() {
  local EC ENVIRON IDX OPTION PATTERN
  if [[ \ ${1}\  =~ \ -[fFv]\  ]] ; then
    [[ $1 != -v ]] && OPTION="$1"
    shift 1
  fi
  for (( IDX=1 ; IDX <= $# ; IDX++ )) ; do
    eval PATTERN+=\"\$$IDX\|\"
  done
  set -o pipefail
  if [[ ${OPTION} == -f ]] ; then
    while read -u 3 ENVIRON ; do
      declare -p ${OPTION} "${ENVIRON}"
      EC="$((EC+$?))"
    done 3< <( declare -p ${OPTION^^} | cut -f 3 -d " " | egrep "${PATTERN%*\|}" )
  else
    declare -p ${OPTION} | cut -f 3 -d " " | egrep "${PATTERN%*\|}"
    EC="$?"
  fi
  set +o pipefail
  return "${EC}"
}

##________________________________________________________________________________
##
## ERROR - Simple error reporting with no USAGE message.
##   The message is displayed on stderr.
function ERROR() {
  unset _ERROR_WITH_GUI_
  _ERROR_DOIT_ "$@"
}

function _ERROR_DOIT_() {
  _ERROR_MESSAGE_="$@"
  if (( _ERROR_WITH_GUI_ )) ; then
    MODIFY_GTK_FONT -s -f "Monospace 14"
    yad --fixed --center --nowrap  --button=yad-quit:2  --title "ERROR" --text "$@" 2>/dev/null
    MODIFY_GTK_FONT -r -f "Monospace 14"
  else
    echo -e "${USAGE_ERROR_PREFIX}""$@" 1>&2
  fi
  (( IS_USAGE_EXIT )) && exit 2 || return 2
}

##________________________________________________________________________________
##
## ERROR_GUI - Similar to ERROR but using a GUI interface for the response. All
##   the options to ERROR can be specified.
function ERROR_GUI() {
  _ERROR_WITH_GUI_="1"
  _ERROR_DOIT_ "$@"
}

##________________________________________________________________________________
##
## ERROR_SCRIPT - This script will execute if an ERR signal is raised and
##   trapped via ERROR_TRAP_SET. Create a function ERROR_SCRIPT to do different
##   things (other than the default) on a script error
function ERROR_SCRIPT() {
  (( IS_USAGE_EXIT )) && exit 2 || return 2
}

##________________________________________________________________________________
##
## ERROR_TRAP_RESET - Reset the ERR trap.
function ERROR_TRAP_RESET() {
  set -o errtrace					# Child commands will inherite the ERR trap
  trap ERR
}

##________________________________________________________________________________
##
## ERROR_TRAP_SET - Trap and execute ERROR_SCRIPT on any script error
##   Redefine the function ERROR_SCRIPT to do different things on a script error
function ERROR_TRAP_SET() {
  set -o errtrace					# Child commands will inherite the ERR trap
  trap ERROR_SCRIPT ERR
}

##________________________________________________________________________________
##
## EXPORT_CLEANUP - Set/Reset everything needed for any child scripts to
##     execute CLEANUP_SCRIPT in the parent.
##   Usage: EXPORT_CLEANUP [ set | unset ]
##   Where: set ==   Export the function and variable names to enable
##                   CLEANUP_SCRIPT in a child process. This is the default.
##          unset == Reset the exported names.
function EXPORT_CLEANUP () {
  if [[ ${1:-set} == set ]]
    then
      declare -g -x -f CLEANUP_SCRIPT CLEANUP_SCRIPT_BEFORE CLEANUP_SCRIPT_AFTER
      declare -g -x -f UMOUNT_IT      REVERSE_ARGS          IS_NUMERIC            _USAGE_CHOICE_  TMP_FILE_DELETE
      declare -g -x    REVERSE_ARGS   _TMP_NAMES_ARRAY_     _MOUNTED_FS_ARRAY_
    else
      declare -g +x -f CLEANUP_SCRIPT CLEANUP_SCRIPT_BEFORE CLEANUP_SCRIPT_AFTER
      declare -g +x -f UMOUNT_IT      REVERSE_ARGS          IS_NUMERIC            _USAGE_CHOICE_  TMP_FILE_DELETE
      declare -g +x    REVERSE_ARGS  _TMP_NAMES_ARRAY_       _MOUNTED_FS_ARRAY_
  fi
 }

##________________________________________________________________________________
##
## FIND_NFS_PATH_FROM_FSTAB - Display all the NFS entries or match one NFS
##     entry in /etc/fstab.
##   Usage:    DISPLAY_NFS_FROM_FSTAB FIELDS [ -V VARIABLE ] [ NFSPATH ]
##   Displays: The first and/or second /etc/fstab fields depending upon the
##             first argument.
##   Returns:  If a match is made, returns 0, otherwise returns 1.
##   Where:
##     FIELDS This option is required.
##       It can have the format { -1 | -11 | -12 | -2 | -22 }
##       The number(s) after the '-' indicate what field is to be displayed
##         from each  matchiong fstab line. 1 displays the first (device) field
##         and 2 displays the second (mount point) field.
##       The two-numbered optins (-11 -12 -22) display two fields.
##     -V VARIABLE
##       Store the fields in array VARIABLE rather than displaying it.
##     NFSPATH makes an attempt to match NFSPATH (or a parent dir of NFSPATH).
##       Otherwise all NFS filesystem entries found in /etc/fstab are displayed.
function FIND_NFS_PATH_FROM_FSTAB () {
  local FSTAB_F1 FSTAB_F2
  local Cmd Domain Idx Options Path Rest Var
  unset _ERROR_MESSAGE_
  while true ; do
    case "$1" in
     -1|-11|-12|-2|-22)
         Options=( ${1:1:1} ${1:2:1} )
         shift 1 ;;
     -V) Var="$2"
         unset ${Var}
         shift 2 ;;
      *) break ;;
    esac
  done
  if (( $# > 0 )) ; then
    [[ $1 =~ : ]] || { _ERROR_MESSAGE_="The pathname \"$1\" is not a valid nfs pathname." ; return 1 ; }
    Path="${1#*:}"					# Get the path part of PC:path
    Domain="$( GET_MATCHING_NFS_DOMAIN_IN_FSTAB -Q ${1%:*} )"
    [[ $? -gt 0 || -z ${Domain} ]] && { _ERROR_MESSAGE_="The domain name in \"$1\" is not valid." ; return 1 ; }
    Cmd="grep --color=none ^${Domain}:"
  else
    Cmd="cat"
  fi
  while read -u 3 FSTAB_F1 FSTAB_F2 Rest ; do
    if (( $# > 0 )) ; then
      if [[ ${Path} =~ ^${FSTAB_F1#*:} ]] ; then
        _FIND_NFS_PATH_FROM_FSTAB_
        return 0
      fi
    else
      _FIND_NFS_PATH_FROM_FSTAB_
    fi
  done 3< <( grep --color=none ":.*\snfs[0-9]*\s" /etc/fstab | ${Cmd} )
  (( $# > 0 )) && return 1 || return 0
}

# Internal function
function _FIND_NFS_PATH_FROM_FSTAB_ () {
  local Sep
  for Idx in ${Options[*]} ; do
    [[ -n ${Var} ]] && { eval ${Var}+=\( \"${Sep}\${FSTAB_F${Idx}}\" \) ; } || eval echo -n \"${Sep}\${FSTAB_F${Idx}}\"
    Sep=" "
  done
}

##________________________________________________________________________________
##
## GET_ARGS - This function, when called in a parent script, does the following:
##     1) It defines acceptable parent script options and arguments.
##     2) When the parent script is invoked, it parses the command line options.
##     3) It generates a manpage-like help (USAGE) message.
##
##   Usage: GET_ARGS [ GET_ARGS_OPTIONS ] -- "$@"
##
##   Where: GET_ARGS_OPTIONS is a list of options that have two purposes:
##            1) Define accceptable parent script options.
##            2) Define information to be included in the USAGE message.
##   Note: "--" and "$@" must be the last two GET_ARGS_OPTIONS and are required.
##
##   When invoked, GET_ARGS uses the GET_ARGS_OPTIONS to generate a call to
##     the linux getopt command which parses the parent shell command-line
##     options ("$@" following the "--"). It then creates variables, related
##     to the command-line options used, that can subsequently be tested by
##     the parent script.
##   In conjunction with GET_ARGS, the function IS_EXCLUSIVE can be used to
##     define and verify valid combinations of the parent script options.
##
##   Because the list of GET_ARGS_OPTIONS is usually long, it is suggested the
##     bash line continuation character "\" be used as follows:
##
##       GET_ARGS \
##         GET_ARGS_OPTION_1 \
##         GET_ARGS_OPTION_2 \
##         ... \
##         -- "$@"
##
##   SUMMARY OF GET_ARGS_OPTIONS THAT DEFINE VALID PARENT SCRIPT OPTIONS
##     --Opt[ion]_D[efinition] [FC] OPTLIST
##         --Des[cription]_D[efinition] OPTION_DESCRIPTION
##     --Hid[den]_D[efinition] [FC] OPTLIST
##         --Des[cription]_D[efinition] OPTION_DESCRIPTION
##     --Act[ion]_D[efinition] [FC] OPTLIST [-k ACTKEY] [-o] [-a] [ -i ACTINFO]
##         --Des[cription]_D[efinition] OPTION_DESCRIPTION
##     --Act[ion]_D[efinition] [FC] "" [-k ACTKEY] [-o] [-a] [ -i ACTINFO ]
##     --Args_None [FC] [@KEYWORD]          | --Args_Req[uired] [FC] N [@KEYWORD]
##     --Args_Min[inimum] [FC] N [@KEYWORD] | --Args_Max[imum] [FC] N[@KEYWORD]
##     --Args_Opt[ional] [FC] N [@KEYWORD]  | --Args_Array [FC] [@KEYWORD]
##     --Opts_Req[uired] [FC] N             | --Opts_Min[imum] [FC] N
##
##     GET_ARGS_OPTIONS --Opt_D, --Hid_D and the first --Act_D must always be
##       followed by --Des_D DESCRIPTION
##
##   SUMMARY OF GET_ARGS_OPTIONS THAT AUGMENT THE USAGE DISPLAY
##     --Filter FC FILTER_DESCRIPTION
##     --Cmd [FC]_D[escription] CMD_DESCRIPTION
##     --Title [FC] [-N] SECTION TITLE
##     --Para[graph] [FC] [-N] SECTION PARAGRAPH
##     --Where [FC] INFO    | --Info [FC] INFORMATION
##     --Action [FC] ACTION | --Exam[ples] [FC] EXAMPLE
##     --Copy[right] [FC] [COPYRIGHT]
##     --Head[ing] HEADING  | --Bas[ic]_O[ption] MODIFY
##     --Comp[act]          | --Tab[stops] TAB
##
##   SUMMARY OF ADDITIONAL GET_ARGS_OPTIONS
##     --Exec_Pri COMMAND   | --Exec_Post COMMAND
##     --Save
##
##     For all the GET_ARGS_OPTIONS above the optional '[FC]' is required
##       if the GET_ARGS_OPTION --Filter is used.  Otherwise the optional
##       '[FC]' must NOT be used.
##
##   USAGE DISPLAY
##     GET_ARGS also uses GET_ARGS_OPTIONS to create a USAGE page.
##       This is displayed by invoking the parent script with the basic options:
##               -h, -H, --help or --HELP
##       The help message is divided into multiple sections each with a header.
##         The section headers (optional ones are [...]), in order, are:
##           PURPOSE          SYNOPSIS       [mysynopsis]   [DESCRIPTION]
##           [ACTION SYNTAX]  OPTIONS        BASIC OPTIONS  [mybasicoptions]
##           [WHERE]          [INFORMATION]  [EXAMPLES]     [COPYRIGHT]
##           NOTE             [mynote]
##         The optional sections are created when the appropriate GET_ARGS_OPTION
##           is used. E.G. The WHERE section is created if --Where is used.
##         The my... sections are empty (no automatic header). --Title and --Para
##           can be used to define extra text in any of the sections.
##     The lines displayed by USAGE are automatically folded to fit into the
##       terminal width. The folding attempts to maintain the indentation of the
##       preceeding line. GET_ARGS_OPTIONS --Compact and --TabStops can be used
##       to modify the default format. Also the USAGE filter modifier <FM> of
##       b (brief), c (compact) and e (expand) can be used to temporalily modify
##       the format.
##     NOTE: For any GET_ARGS_OPTION that adds text to USAGE, the text can contain
##       any backslash-escaped characters acceptable to "echo -e ...".
##     NOTE: Two variables SCRIPT_PURPOSE and VERSION should be defined by the
##       parent script before this script is 'source'd as they are displayed
##       in the appropriate USAGE section. The contents of SCRIPT_PURPOSE is
##       inserted into the section PURPOSE. The contents of VERSION is displayed
##       by the basic options -v or --version.
##
##   GET_ARGS_OPTION PARENT SCRIPT OPTION DEFINITIONS
##     --Opt[ion]_D[efinition] [FC] OPTLIST
##         --Des[cription]_D[efinition] OPTION_DESCRIPTION
##       Each --Opt_D defines a parent script option that can be used when the
##         script is executed. Every "--Opt_D [FC] OPTLIST" must immediately be
##         followed by "--Des_D OPTION_DESCRIPTION". OPTION_DESCRIPTION is used
##         in the help message to describe the options defined by --Opt_D.
##       OPTION_DESCRIPTION normally should not contain newlines as it is folded
##         and indented to fit within the terminal width. Spaces, newlines, \t
##         and \n can be used to force formatting.
##       Each Opt_D and Des_D pair defines an acceptable invoking script option
##         and a description of the option for the help message.
##       Any number of --Opt_D --Des_D pairs may be defined.
##
##       FC is a set of single-character filter <codes> (FCi) that apply to
##           --Opt_D, --Hid_D or --Act_D and to some GET_ARGS_OPTIONS below.
##         Each FCi used must be defined by a corresponding --Filter option
##           (see below).
##         FC can contain any number of FCi (no spaces). When help is invoked
##           with a -h<FCi> all the paragraphs are displayed that have the
##           corresponding <code> in FC. Some section are always displayed.
##         A special FC i of "a" can be used to always display a help paragraph.
##           An empty FC ("") implies an FC of "a". When invoking the parent
##           script, specifying options -h[FCi] or --help=[FCi] the (filtered)
##           USAGE message is displayed.
##         FC code 'b' is reserved for "brief" help unless modified by the
##           GET_ARGS_OPTION --Bas_O (see below).
##         FC code 'c' is reserved for "compact" help unless modified by the
##           GET_ARGS_OPTION --Bas_O (see below).
##
##       OPTLIST Is a list of one or more related script options OPT1 OPT2...
##           Each OPTi in the list must NOT begin with a "-" but may contain it.
##         The OPTLIST list of script options may be separated by a combination of
##           spaces and/or commas.
##         If any OPTi is a single character it is a short option (E.G. "-p").
##           Otherwise it is a long option (E.G. "--list").
##         If any OPTi is followed by a ":", the option requires a VALUE. If used,
##           ":" must follow each OPTi in the OPTLIST.
##         If any OPTi is followed by "::", the option has an optional VALUE. If
##           used, "::" must follow each OPTi in the OPTLIST.
##             E.G. --Opt_D "l:: list-format::" enables the shell options "-l" or
##                  "-lshort" or "--list-format" or "--list-format=short".
##         If OPTLIST begins with a "*" those OPTi may appear more than once
##           at parent script invocation. Otherwise multiple occurances of the
##           options OPTi is an error.
##         If OPTLIST ends with "@KEYWORD" then, in the USAGE message, the
##           characters of KEYWORD replace the placeholder "VALUE" for options
##           that have an (optional) argument (OPTi: or OPTi::).
##         The variables Opt_OPT1 and Opt_OPT1_Val (where "OPT1" is replaced by
##           the first option in OPTLIST) are unset by GET_ARGS when parsing
##           GET_ARGS_OPTIONS.  When parsing the parent script options, the value of
##           the option variable Opt_OPT1 is set to the number of times that
##           option is used. If : or :: follows OPti, the vaiable Opt_OPT1_Val
##           is set to the value of the option.
##         If OPT1 contains any "-" characters, all "-" in OPT1 are converted to
##           "_" when creating the corresponding variable. E.G. For an OPTLIST
##           of "long-opt:", using --long-opt at script invocation creates the
##           variable names "Opt_long_opt" and "Opt_long_opt_Val"..
##         If an option has or requires a VALUE, the Opt_OPT1_Val variable is a
##           zero-based array containing one element for each similar OPT1 option
##           encountered. E.G. ${Opt_OPTi_Val[0], ${Opt_OPTi_Val[1]} ...
##           and Opt_OPT1 contains the number of elements in the array.
##         After invoking GET_ARGS, the parent script can test if any single
##           OPTi has been used on the command line with:
##             if (( Opt_OPT1 )) ; then ...
##
##       GET_ARGS creates an associative array Alt_Opt[*] that, for each
##         OPTi in OPTLIST, the array element: ${Alt_Opt[${OPT1}]}
##           (indexed on the first OPTi) contains a list of the remaining OPTi
##           (OPT2 ... OPTn) or a space (" ") if there is only one OPTi..
##         This array can be used by any shell that calls GET_ARGS to
##           programatically determine the set of shell options that have been
##           defined by each GET_ARGS argument "--Opt_D ...".
##         Assuming option -x was defined in the calling script as:
##             Opt_D "x extra X" Des_D "..."
##           then ${Alt_Opt[-x]} will contain " --extra -X "
##
##       GET_ARGS creates a variable "Opts_All" which contains a space separated
##         list of all options used (in that order but no values) at parent script
##         invocation. Only the OPT1 option is used in the list. The remaining
##         OPTi can be accessed with ${Alt_Opt[${OPT1}]}
##         If OPTLIST begins with a "*" then Opts_All will contain each occurance
##         of OPTi as it is encountered in the calling script.
##           EXAMPLE: CMD is inoked as:   CMD -x -YYY -z aaa -z bbb -z ccc
##           To parse the options used in the order they were specified, use:
##             for OPT in ${Opts_All} ; do
##               case "${OPT}" in
##                 -x) $Opt_x_Val ... ;;
##               -YYY) $Opt_YYY_Val ... ;;
##                 -z) ${Opt_z_Val[i]} ... ;;
##              esac ; done
##           To test a single option use:
##             (( Opt_YYY )) && ...
##             (( ! Opt_x )) && ...
##             for (( Idx=0 ; Idx<Opt_z ; Idx++ )) ; do
##               MYVAL=${Opt_x_Val{Idx]}
##             done
##
##     --Des[cription]_D[efinition] OPTION_DESCRIPTION
##       This GET_ARGS_OPTION must immediately follow --Opt_D, --Hid_D or
##       (optionally) --Act_D. OPTION_DESCRIPTION explains the meaning of the
##       previous GET_ARGS_OPTION. It is displayed in the USAGE message.
##
##       EXAMPLES
##         For the following examples --Des_D "OPTION_DESCRIPTION" has been left out
##         for clarity.
##
##         EXAMPLE: If CMD.sh contains the line:
##             GET_ARGS --Opt_D "a all" --Opt_D "file: f:" --Opt_D "*n: N: new:"
##           The  command line:
##             CMD.sh --all -n ABC -f FILE1 --new=def -Nghi
##           GET_ARGS generates:
##             Opts_All="-a -n --file -n -n"
##             Opt_a="1"  Opt_file="1" Opt_file_Val="FILE1"
##             Opt_n="3" and an array Opt_n_Val=( ABC def ghi )
##             The associative array Alt_Opt with values:
###              Alt_Opt[-a]=" --all "
##               Alt_Opt[--file]=" -f "
##               Alt_Opt[-n]=" -N --new "
##
##         EXAMPLE: If CMD.sh contains the line:
##             GET_ARGS --Opt_D "*d: directory:"
##           Then the following command is valid:
##             CMD.sh -d Adir --directory Bdir -d Cdir
##
##     --Act[ion]_D[efinition] [FC] OPTLIST [-K ACTKEY] [-O] [-A] [ -I ACTINFO ]
##          --Des[cription]_D[efinition] OPTION_DESCRIPTION
##     --Act[ion]_D[efinition] [FC] "" [-K ACTKEY] [-O] [-A] [ -I ACTINFO ]
##       Each --Act_D describes alternate variations of command syntax.
##         It creates a section 'ACTION SYNTAX' with the following format:
##           CMD [ACTKEY] [{-Opt_1|--Opt_2...}] [OPTIONS] [ARGs] [ACTINFO]
##         Note: A following --Des_D is required unless OPTLIST is empty.
##               However OPTLIST is required, even if empty.
##       If '-K ACTKEY' is included, a list of action keys is made. Then, when
##         the parent script is invoked if the first non-option argument (ARG1)
##         matches a key in the list the variable Act_Key is created containing
##         the key and ARG1 is removed. No match generates an error.
##         ACTKEY is included in the generated ACTION description immediately
##         following the parent script name and it is highlighted.
##       ACTKEY is the same as seen in 'btrfs' syntax: btrfs filesystem ...
##         If -K ACTKEY is used, it must be used in every --Act_D.
##       If OPTLIST is not empty, OPTLIST (see above) is converted from a
##         space/comma separated list to a "choose-from" option list.
##         like '{-Opt_1|--Opt_2...}' in the ACTION description.
##         Also a GET_ARGS_OPTION '--Opt_D [FC] OPTLIST' is automatically
##         generated as in --Opt_D above. In this case --Act_D MUST be followed
##         by a '--Des_D OPTION_DESCRIPTION'.
##       If -O is included then the string '[ OPTIONS ]' is included in the
##         action description.
##       If -A is included then, if any ARGs have been defined (see '--Arg...'
##         below), '[ ARGs ]' is included in the ACTION description.
##       If -I ACTINFO is included then 'ACTINFO' is included following the ACTION
##           description.
##         ACTINFO is freeform input that is displayed at the end of
##           the ACTION description line.
##         If ACTINFO contains spaces it must be enclosed in quotes.
##         It is suggesteed that ACTINFO starts with "# " to simulate a comment.
##         The ACTINFO display may be continued on the next line using '\n' and
##           may contain tab (\t) characters as well.
##       Any number of '--Act_D ... [--Des_D]' may be defined. If --Act_D is
##         used it is suggested that --Action (see below) be used as well.
##     --Hid[den]_D[efinition] [FC] OPTLIST --Des_D OPTION_DESCRIPTION
##       This is a special case of -Opt_D that defines a script option which,
##       along with OPTION_DESCRIPTION, is not displayed in the help message.
##       A script can call another script using its --Hid_D option to do a
##       script-related action not normally done by a user.
##       Note: --Des_D OPTION_DESCRIPTION is still required.
##     --Opts_Min[imum] [FC] N
##       Minimum options = N. Generates an error if the number of options at
##       invocation of the script is less than N.
##     --Opts_Req[uired] [FC] N
##       Required options = N. Generates an error if the number of options at
##       invocation of the script is not N.
##
##     Options --Opt_D, --Hid_D and --Act_D may be intermixed.
##     Options --Opts_Min and --Opts_Req are mutually exclusive.
##     DESCRIPTION in any of the GET_ARGS_OPTIONS can contain the escape
##       sequences available in the "echo" command.
##
##     EXAMPLE: The GET_ARGS_OPTION:
##       --Act_D "a all" -A copy -O -I "# Will copy..."
##          --Des_D "-a|--all will cause the copy action to..."
##       Displays the ACTION:
##          CMD copy {-a|--all} [OPTIONS]       # Will copy...
##       And also generates:
##          --Opt_D "a all" --Des_D "-a|--all will cause the copy action to..."
##
##   BASIC OPTIONS
##     GET_ARGS implements the following parent script basic options by default.
##       -h[<FilterFC>[<FilterFM>]]| --help[=<FilterFC>[<FilterFM>]]
##         Display the generated help message.
##       -H[<FilterFC>[<FilterFM>]] | --HELP[=<FilterFC>[<FilterFM>]]
##         Display the generated help message with "less" as a screen pager.
##         If GET_ARGS_OPTION --Filter is used, only the FC paragraphs are
##         displayed (see FC above).
##         <FilterFC> displays FC paragraphs, <FilterFM> modifies the display.
##       -t[NOCLEANUP] | --test[=NOCLEANUP]
##         Implement script testing. Script commands using "${TEST_CMD} ..." are
##         not executed but are displayed.  Any clean-up scripts are executed
##         unless the keyword NOCLEANUP is specified.
##         See TEST_RESET and TEST_SET below.
##       -v | --version
##         The contents of the variable SCRIPT_VERSION are displayed and the
##         script exits. SCRIPT_VERSION must be defined in the calling script
##         before GET_ARGS is called.
##     The mnemonic for any basic option can be changed with --Bas_O. See below.
##     FILTERED HELP: <FilterFC>
##       For <FilterFC>, if a GET_ARGS_OPTION "--Filter" is used, then only the
##         FC paragraphs matchine <FilterFC> are displayed.
##       If no GET_ARGS_OPTION "--Filter" is used, <FilterFC> must not be used.
##     BRIEF, COMPACT or EXPAND HELP: <FilterFM>
##       A <FilterFM> of "b" can be used to display brief help where only the
##         sections PURPOSE, SYNOPSIS, OPTIONS and BASIC OPTIONS are displayed.
##         Any descriptions (g.e. OPTIONS section) are limited to one line and
##         truncated. A <FilterFM> of "c" or "e" compresses or expands the
##         display
##
##   MODIFY A BASIC OPTION
##     --Bas[ic]_O[ption] BASOPT=NEWOPT
##     --Bas[ic]_O[ption] ALLOPT=NEWALLOPT[@ALLMSG]
##     --Bas[ic]_O[ption] MODOPT=NEWMODOPT[@MODMSG]
##         BASEOPT, ALLOPT or MODOPT is the basic option to be modified.
##           Valid BASEOPT are:
##             c compact e expand h help H HELP t test v version
##         ALLOPT can be "a" or "all" which redefines the default <FilterFC>
##           of "a" used to display all (un-filtereed) USAGE lines.
##         ALLMSG replaces the default filter "all" message of:
##                  All - display all help information
##         MODOPT can be b, brief, c, compact, e, expand which redefines the
##           default <FilterFM>.
##         MODMSG replaces the default filter message of:
##                  BRIEF   = Brief - display summarized help
##                  COMPACT = Compact - remove blank lines.
##                  EXPANT  = Expand - include blank lines.
##         NEWOPT is the replacement option. It can consist of any alphanumeric
##           characters, '-' and '_'.
##           If BASEOPT is one character only the first character of NEWOPT is used.
##         NEWALLOPT and NEWBRIEFOPT can only be a single alphanumeric character.
##         EXAMPLE:
##           A PARENT_SCRIPT has GET_ARGS that contains: '--Bas_O "h=m"'
##           EXECUTING: PARENT_SCRIPT -m
##           CAUSES:    GET_ARGS to display help (USAGE) information
##       This GET_ARGS_OPTION is used to redefine a default basic option so
##         the default basic option can be used as a regular option and NEWOPT
##         can be used for the basic option. Normally if OPTLIST contains a
##         basic option (say: --Opt_d "h html") then 'CMD -h' will not display
##         USAGE help.
##
##   USAGE FILTER OPTION
##     --Filter FC FILTER_DESCRIPTION
##       You can filter the output of the USAGE message with the "--Filter"
##         GET_ARGS_OPTION. A filtered help message is then created.
##       FC is a single alphanumeric character.
##       FILTER_DESCRIPTION is the text that describes the filter to be applied.
##         E.G. --Filter m "Display the management options"
##       A default (reserved) FC of "a" is pre-defined to display all the USAGE
##         information. This FC can be modified by --Bas_O.
##       FILTER_CODES "a", "b", "c" and "e" are reserved. None can be used as a
##         standard filter code unless modified by --Bas_O.
##       The --Filter GET_ARGS_OPTION may be used multiple times to describe
##         different filters. Most GET_ARGS_OPTIONS have an optional FC argument.
##       If the --Filter GET_ARGS_OPTION is used, then the FC argument is
##         always required.
##       If the --Filter GET_ARGS_OPTION is not used, Then the FC argument cannot
##         be used.
##       All --Filter GET_ARGS_OPTIONS must preceed the first GET_ARGS_OPTION that
##         uses a [FC].
##       Use of --Filter causes the invoking script options -h, -H, --help and
##         --HELP to have a required argument <code>. The <code> is
##         then used to display the paragraphs of the help message that correspond
##         to that <code>.
##       If, in the invoking script, help is requested without <code>, a legend,
##         created from the --Filter GET_ARGS_OPTION arguments, is displayed.
##
##   ARGUMENT OPTIONS
##     --Args_None [FC]
##       No arguments. Generates an error if any non-option arguments are
##       specified. Is an alias for "--Args_Req [FC] 0". This is the default.
##     --Args_Req[uired] [FC] N[@KEYWORD]
##       Required arguments = N. Generates an error if the number of ARGS at
##       invocation of the script is not N.
##     --Args_Min[imum] [FC] N[@KEYWORD]
##       Minimum arguments = N.  Generates an error if the number of ARGS at
##       invocation of the script is less than N.
##     --Args_Max[imum] [FC] N[@KEYWORD]
##       Maximum arguments = N.  Generates an error if the number of ARGS at
##       invocation of the script is greater than N.
##     --Args_Opt[ional] [FC] N[@KEYWORD]
##       Optional arguments = N. Generates an error if the number of ARGS at
##           invocation of the script is not N or zero.
##         If N is zero then all ARGS are optional (zero or any number of args
##           are accepted).
##     --Args_Array [FC] [@KEYWORD]
##       Zero or more arguments are processed. This is NOT equivalent to not
##       using any --Arg_... GET_ARGS_OPTIONS.
##     If no "--Args_..." GET_ARGS_OPTION is specified all non-option arguments
##       at script invocation are ignored. Otherwise all arguments are placed in
##       an array Args[*] (origin 1) in the order encountered at script
##       invocation.
##     Note: --Args_None, --Args_Req, --Args_Min, --Args_Max, --Args_Opt and
##           --Args_Array  are mutually exclusive.
##     If no --Args... GET_ARGS_OPTION is sepcified, invoking the parent script
##       with one or more arguments generates an error.
##     If @KEYWORD is included then, in the SYNTAX section of the USAGE message,
##       the characters of KEYWORD replace the placeholder "ARG".
##
##     EXAMPLE: If CMD.sh contains the line:
##         GET_ARGS --Args_None --Opt_D "print-it p" --Opt_D "f: format:" -- "$@"
##       This command line parses error free:              CMD.sh -p --format=long
##       And the following variable assignments are made:
##           Opt_print_it="1"; Opt_f"1" ;  Opt_f_Val="long"
##       But this command line creates an error message:   CMD.sh file1
##
##     EXAMPLE: If CMD.sh contains the line:
##         GET_ARGS --Args_Array -- "$@ "
##       Executing the following:          CMD.sh file1 file2
##       Creates the array assignments:    Args[1]="file1" ; Args[2]="file2"
##
##   FREEFORM INFORMATION
##     The USAGE display sections are created automatically by GET_ARGS_OPTIONS
##       and are placed in the section to which they are related. I.E. --Des_D
##       DESCRIPTIONS are automatically placed in the OPTIONS section. Every
##       WHERE text is placed in the WHERE section etc. The first time text is
##       placed in a section it is preceeded by the header for that section
##       except for sections 'mysynopsis', mybasicoptions and mynote.
##     The following options --Title and --Para place text in SECTION.
##       SECTION must be one of:
##         P PURPOSE        S SYNOPSIS     s mysynopsis     D DESCRIPTION
##         A ACTION SYNTAX  O OPTIONS      B BASIC OPTIONS  b mybasicoptions
##         W WHERE          I INFORMATION  E EXAMPLES       C COPYRIGHT
##         N NOTE           n mynote
##     --Title [FC] [-N] SECTION TITLE
##       Inserts left-justified text "TITLE" usually where it occurs within the
##         current position of section SECTION. TITLE will be preceeded with a
##         blank line unless -N is specified or if --Compact is used.
##       If SECTION doesn't exist it is created. Multiple --Title options
##         can be defined.
##     --Para[graph] [FC] [-N] SECTION PARAGRAPH
##       Inserts an indented PARAGRAPH usually where it occurs within the current
##         position of section SECTION. PARAGRAPH will be preceeded with a blank
##         line unless -N is specified or if --Compact is used. Multiple --Para
##         options can be defined.
##     The location of TITLE or PARAGRAPH is in the section SECTION and usually
##       in the next position available in that section. Exception sections are:
##         PURPOSE - Only at the end of the section.
##         SYNOPSYS and BASIC OPTIONS - Only at the beginning of the section.
##     The section myssynipsis is created only if a --Title or --Para is specified
##       for that section. Its purpose is to allow text to be placed after the
##       SYNOPSYS section. No header is automatically placed in this section.
##     Similarly the section 'myBASICOPTIONS' follows the basic options section
##       and 'mynote' follows section NOTE..
##
##   INFORMATION OPTIONS
##     --Action [FC] ACTION
##       Inserts the string ACTION after the parent script name in the command
##         synopsis. ACTION usually is a single word indicating the command has
##         a keyword that identifies separate set of options vis: 'btrfs keyword.
##       If this option is used, some Opt_D definitions should be changed to
##         --Act_D to create an 'ACTION SYNTAX' section.
##     --Cmd [FC]_D[escription] CMD_DESCRIPTION
##       Create a 'DESCRIPTION' section immediately following the SYNOPSYS
##         section with a paragraph CMD_DESCRIPTION. Use --Cmd_D to create a
##         detailed description of the purpose of the parent script.
##       Additional paragraphs can be added with the --Para GET_ARGS_OPTION.
##     --Head[ing] HEADING
##       Add HEADING at the end of the first line of USAGE. No leading
##         whitespace is automatically included in HEAADIBG.
##     --Where [FC] INFO
##       Inserts INFO into the WHERE section (following BASIC OPTIONS).
##         Multiple --Where options can be defined.
##     --Info [FC] INFO
##       Inserts INFO into the INFORMATION section (following section WHERE).
##         Multiple --Info options can be defined.
##     --Exam[ple] [FC] EXAMPLE
##       Inserts EXAMPLE into the EXAMPLE section (following section
##         INFOMATION). Multiple --Example options can be defined.
##     --Copy[right] [FC] [COPYRIGHT]
##       In the COPYRIGHT section, display the COPYRIGHT text if present,
##         otherwise display a default (basic) linux copyright paragraph.
##     --Comp[act]
##       Remove any blank lines and set the tab stops to 4. Subsequent use of
##       the GET_ARGS_OPTION --Tab will reset the default of 4.
##       Note: --Compact must preceed any GET_ARGS_OPTION that uses FC.
##     --Tab[stops] TAB
##       Set the tab stop (column) width to TAB. The stops are used by the
##         USAGE command. TAB is a number representing the tab stop width.
##       The default TAB is 8 columns.
##       Note: --Tab must preceed any GET_ARGS_OPTION that uses FC.
##     --Exec[ute]_Pri[or] COMMAND   and   --Exec[ute]_Pos[t] COMMAND
##       Execute COMMAND prior to (_Pre) or subsequent to (_Post) parsing
##         the script options and arguments (not GET_ARGS_OPTIONS).
##       If COMMAND has arguments, it must be enclosed in quotes.
##
##   OPTOMIZATION OPTIONS
##     --Save
##       Saves the parsed values as a BASH_SCRIPT into the /tmp directory.
##       Subsequent execution of the parent script sets the parsed values
##       from BASH_SCRIPT rather than re-parsing the GET_ARGS_OPTIONS. This is
##       useful for parent scripts that have a large number of script options.
##       The bash script is named:
##           /tmp/${CMD}.${SCRIPT_VERSION}.sh
##       CMD is the name of the parent script and SCRIPT_VERSION is the version.
##       If the value of ${SCRIPT_VERSION} is changed, a new BASH_SCRIPT is
##       created.

# Stub to implement the GET_ARGS_DEFAULT function.
# Thus the parent script can use these functions, redefine GET_ARGS but have GET_ARGS_DEFAULT available.
function GET_ARGS() {
  GET_ARGS_DEFAULT "$@"
}

TAB_STOP_WIDTH="8"					# Default tab stops unless either --Compact or --Tab is used
EXTRA_NL="\n"						# Add blank lines in the USAGE display

##________________________________________________________________________________
##
## GET_ARGS_DEFAULT - Call this to use the GET_ARGS function defined above.
##   It will bypass another implementation of GET_ARGS within the calling script.
function GET_ARGS_DEFAULT() {
  LOCAL_USAGE="1"
  _ALL_OPTIONS_=" "					# Holds all the defined options
  unset _ERROR_MESSAGE_ Args
  unset _GET_ARGS_OPTION_FOUND_ _GET_ARGS_Args_VERIFY_CALLED_ USAGE_BASIC_OPTION_1 USAGE_BASIC_OPTION_2
  local _USAGE_less_
  local EXTRA_HELP_MESSAGE THE_MESSAGE USAGE_NL
  local DEFAULT_TAB_STOP_WIDTH="4" SAVE_VARIABLES="0"
  local Count=0 Act_D_Count Act_D_K_Count
  local Args_None Args_Array Args_Optional Args_Required Args_Minimum Args_Maximum Opts_Required Opts_Req Opts_Minimum Opts_Min
  local Exec_Prior Exec_Post FC FC_VAL _FM_brief_
  local I OPTIONS LONG_OPTIONS OPT_D OPT_LEN OPT_NAMES OPT_SHIFTS OPT_TMP OPT_VALUE SPACE
  local CMD_DESCRIPTION _THIS_OPTION_ _PREVIOUS_OPTION_
  local ONE_OPT OPTLISTCOUNT OPTLIST OPTLIST_KEYWORD OPTLIST_STARS OPT_COLON OPT_COLONS OPT_OPTIONAL OPT_NUM="0" Des_D_FOUND="1"
  local DISPLAY_THIS_OPT _FILTER_IS_ON_ FILTER_HELP_CHANGED FILTER_HELP_MESSAGE
  local FILTER_CODE _REMAKE_SAVED_ BASIC_OPTS_LHS BASIC_OPTS_VARS
  local ACTION_KEYWORD ACTION_MESSAGE_PART ERROR_LENGTH SAVED_FC SAVED_OPTIONS
  local ACT_OPTS OPT_PART_DASH AO_IDX
  local KEY_PART OPT_PART OPT_PART_BEG OPT_PART_MID OPT_PART_END ARG_PART INFO_PART
  local gawk_SCRIPT="$(type -p .functions.sh.GET_ARGS_Pre_Scan.gawk)"
  local OLD_FC_ALL SHIFT _SHIFT_ME_ DisplayArgMessage="1"
  local SAVED_VARIABLES_FILE="/tmp/${CMD}.SavedEnvironment.${SCRIPT_VERSION// /}.sh" SAVED_VARIABLES_FILE_PATTERN="/tmp/${CMD}.SavedEnvironment.*.sh"
  local ENVIRONMENT_AFTER_FILE ENVIRONMENT_BEFORE_FILE PARSE_GET_ARGS_OPTIONS GAO_IDX
  local Idx Alt_Opt_Idx			# The index ==> the first OPTi ==> OPT1
  declare -gA Alt_Opt			# For each --Opt_D, indexed by the first option in Opt_i; contains the remaining Opt_i
  declare -gA FILTER_HELP_TEXT
  declare -gA USAGE_SECTION_HEADER USAGE_SECTION_TEXT
  USAGE_SECTION_HEADER[P]="PURPOSE"
  _GET_ARGS_Section_INSERT_ "PURPOSE" "P" "${SCRIPT_PURPOSE:-Variable \"SCRIPT_PURPOSE\" undefined.}"
  USAGE_SECTION_HEADER[S]="SYNOPSIS"
  USAGE_SECTION_HEADER[s]="mysynopsys"
  USAGE_SECTION_HEADER[D]="DESCRIPTION"
  USAGE_SECTION_HEADER[A]="ACTION SYNTAX"
  USAGE_SECTION_HEADER[O]="OPTIONS"
  USAGE_SECTION_HEADER[B]="BASIC OPTIONS"
  USAGE_SECTION_HEADER[b]="mybasicoptions"
  USAGE_SECTION_HEADER[W]="WHERE"
  USAGE_SECTION_HEADER[I]="INFORMATION"
  USAGE_SECTION_HEADER[E]="EXAMPLES"
  USAGE_SECTION_HEADER[C]="COPYRIGHT"
  USAGE_SECTION_HEADER[N]="NOTE"
  USAGE_SECTION_HEADER[n]="mynote"
  _VALID_SECTIONS_="   P PURPOSE   S SYNOPSIS       s mysynopsis      D DESCRIPTION  A ACTION SYNTAX
   O OPTIONS   B BASIC OPTIONS  b MYBASICOPTIONS  W WHERE        I INFORMATION
   E EXAMPLES  C COPYRIGHT      N NOTE            n mynote"
  _NO_CLEANUP_="NOCLEANUP"

  # The gawk scripti below may redefine the following values
  _a_="a" ; _all_="all"		; _a_msg_="All - display all help information."	# Filter code for "all"
  _b_="b" ; _brief_="brief"	; _b_msg_="Brief - display summarized help"
  _c_="c" ; _compact_="compact"	: _c_msg_="Compact - remove blank lines."
  _e_="e" ; _expand_="expand"	; _e_msg_="Expand - include blank lines."
  _h_="h" ; _help_="help"
  _H_="H" ; _HELP_="HELP"
  _t_="t" ; _test_="test"
  _v_="v" ; _version_="version"
  BASIC_OPTS_LHS=" ${_a_} ${_all_} ${_b_} ${_brief_} ${_c_} compact ${_e_} ${_expand_} ${_h_} ${_help_} ${_H_} ${_HELP_} ${_t_} ${_test_} ${_v_} ${_version_} "
  BASIC_OPTS_VARS=" -v _a_=${_a_} -v _all_=${_all_} -v _b_=${_b_} -v _brief_=${_brief_} -v _c_=${_c_} -v _compact_=compact -v _e_=${_e_} -v _expand_=${_expand_} -v _h_=${_h_} -v _help_=${_help_} -v _H_=${_H_} -v _HELP_=${_HELP_} -v _t_=${_t_} -v _test_=${_test_} -v _v_=${_v_} -v _version_=${_version_}"
  # Do a pre-scan (with an gawk script) of the arguments to GET_ARGS
  # Evaluation of the output of the gawk script includes:
  #   1) May create/modify the following variables:
  #        EXPECTING_FILTER FILTER_CODE _FM_brief_ EXTRA_NL TAB_STOP_WIDTH
  #   2) Detects redefinition of basic options (via --Bas_O) and redefines the variables:
  #        _a_ _a_msg_ _b_ _b_msg_ _c_ _c_msg_ _e_ _e_msg_ _h_, _H_, _help_, _HELP_, _t_, _test_, _v_ and _version_.
  local _b_msg_="Brief - display summarized help." _c_msg_="Compact - remove blank lines." _e_msg_="Expand - include blank lines."
#echo  eval "$( gawk ${BASIC_OPTS_VARS} -v "BasicOpts=${BASIC_OPTS}" -v "DefaultTabStopWidth=${DEFAULT_TAB_STOP_WIDTH}" -f "${gawk_SCRIPT}" <<<"${@@Q}" )" ; exit
  eval "$( gawk -F "' '" ${BASIC_OPTS_VARS} -v "BasicOptsLHS=${BASIC_OPTS_LHS}" -v "DefaultTabStopWidth=${DEFAULT_TAB_STOP_WIDTH}" -f "${gawk_SCRIPT}" <<<"' ${@@Q} '" )"
  local FC_ARG="${_a_}" COUNT_ARG="2" TEXT_ARG="2" TEXT_ARG2="3"  TEXT_ARG3="4" OPTLIST_ARG="2" SHIFT_ARGS="2"
  if (( SAVE_VARIABLES )) ; then			# Parsing optimization requested?
    # If we saved the environment AND if there is no FILTER_CODE then use the saved environment
    if [[ -f ${SAVED_VARIABLES_FILE} && ${_REMAKE_SAVED_} != 1 ]] ; then
      source "${SAVED_VARIABLES_FILE}" >& /dev/null	# Set the parsed variables from this file
      for (( GAO_IDX=1 ; GAO_IDX<=$# ; GAO_IDX++ )) ; do
        eval [[ \${$GAO_IDX} == "--" ]] && break
      done
      eval [[ \${${GAO_IDX}} != -- ]] && echo -e "SHIT: In functions.sh GET_ARGS cannot find first '--'.\nLocated by \${GAO_IDX}"
      shift ${GAO_IDX}					# Bypass all the GET_ARGS_OPTIONS
      PARSE_GET_ARGS_OPTIONS="0"
    else						# Otherwise parse the GAT_ARGS_OPTIONS and save the environment
      rm -f ${SAVED_VARIABLES_FILE_PATTERN} >&/dev/null	# Clean up any old files
      TMP_FILE_CREATE ENVIRONMENT_BEFORE_FILE ENVIRONMENT_AFTER_FILE
      set > "${ENVIRONMENT_BEFORE_FILE}"		# Save the environment before parsing
      PARSE_GET_ARGS_OPTIONS="1"
    fi
  else
    PARSE_GET_ARGS_OPTIONS="1"
  fi
  if (( PARSE_GET_ARGS_OPTIONS ))  ; then		# Start parsing GET_ARGS_OPTIONS
    # Now we can set the values of the USAGE 'BASIC OPTIONS' variables
    _GET_ARGS_Section_INSERT_ "BASIC OPTIONS" "B" ""	# Create this section header right away
    if (( EXPECTING_FILTER )) ; then
      _USAGE_h_="-${_h_}[<filter>[${_b_}|${_c_}|${_e_}]] "
      _USAGE_help_="--${_help_}[=<filter>[${_b_}|${_c_}|${_e_}]] "
      _USAGE_H_="-${_H_}[<filter>[${_b_}|${_c_}|${_e_}]] "
      _USAGE_HELP_="--${_HELP_}[=<filter>[${_b_}|${_c_}|${_e_}]] "
    else
      _USAGE_h_="-${_h_}[${_b_}|${_c_}|${_e_}] "
      _USAGE_help_="--${_help_}[={${_b_}|${_c_}|${_e_}}] "
      _USAGE_H_="-${_H_}[${_b_}|${_c_}|${_e_}] "
      _USAGE_HELP_="--${_HELP_}[={${_b_}|${_c_}|${_e_}}] "
    fi
    _getopt_h_="${_h_}::"             _option_h_="-${_h_} "
    _getopt_help_="${_help_}::,"      _option_help_="--${_help_} "
    _getopt_H_="${_H_}::"             _option_H_="-${_H_} "
    _getopt_HELP_="${_HELP_}::,"      _option_HELP_="--${_HELP_} "
    _getopt_t_="${_t_}::"             _option_t_="-${_t_}[${_NO_CLEANUP_}] "          ; _pattern_t_="-${_t_} "
    _getopt_test_="${_test_}::,"      _option_test_="--${_test_}[=${_NO_CLEANUP_}] "  ; _pattern_test_="--${_test_} "
    _getopt_v_="${_v_}"               _option_v_="-${_v_} "
    _getopt_version_="${_version_},"  _option_version_="--${_version_} "

    VALID_FILTER_CODES="${_a_}"
    # Start of GET_ARGS_OPTIONS parsing.
    while true ; do					# Preamble to determine if parsing is to be augmented
      _THIS_OPTION_="$1 $2 ..."
      unset SAVED_OPTLIST
      case "$1" in
         --Act*_D*) unset KEY_PART OPT_PART OPT_PART_BEG OPT_PART_MID OPT_PART_END ARG_PART INFO_PART
                    _GET_ARGS_DISPLAY_THIS_ "${!FC_ARG}" "$1 ${!FC_ARG@Q} ${!OPTLIST_ARG@Q}" && DISPLAY_THIS_OPT="1" || unset DISPLAY_THIS_OPT
                    [[ ${FC_ARG} == 2 ]] && shift 1	# Get rid of FC <code> if it is present
                    [[ ${2:0:2} =~ -- ]] && _GET_ARGS_ERROR_ "$*" "OPTLIST is missing."
                    unset OPT_PART_BEG OPT_PART_END
                    SAVED_OPTLIST="$2"			# There always must be an OPTLIST even if it is empty
                    ACT_OPTS="${2%@*}"			# Remove unnecessary 'stuff'
                    ACT_OPTS="${ACT_OPTS#\*}"
                    ACT_OPTS=( ${ACT_OPTS//[:,]/ } )	# Make it into an array
                    for (( AO_IDX=0 ; AO_IDX<${#ACT_OPTS[*]} ; AO_IDX++)) ; do
                      (( ${#ACT_OPTS[AO_IDX]} > 1 )) && OPT_PART_DASH="--" || OPT_PART_DASH="-"
                      (( AO_IDX )) && { OPT_PART_BEG=" {" ; OPT_PART_MID="${OPT_PART_MID# }|${OPT_PART_DASH}${ACT_OPTS[AO_IDX]}" ; } \
                        || OPT_PART_MID=" ${OPT_PART_DASH}${ACT_OPTS[AO_IDX]}"
                    done
                    (( AO_IDX > 1 )) && OPT_PART_END="}"
                    shift 1
                    (( ++Act_D_Count ))			# Count the number of --Act*_D* defined
                    while true ; do
                      case "$2" in
                        -K) [[ ${3:0:1} == - ]] && _GET_ARGS_ERROR_ "$*" "For \"--Act_D ... -K ACTKEY ...\", ACTKEY is missing or starts with a \"-\"."
                            KEY_PART=" ${GLD}${3}${BLK}"
                            [[ ${_KEYS_} =~ \ $1\  ]] &&  _GET_ARGS_ERROR_ "$*" "Action key \"$3\" has been defined more than once."
                            (( Act_D_Count == ++Act_D_K_Count )) || _GET_ARGS_ERROR_ "$*" "Invalid use of --Act_D option -K.\nIf used, -K must be specified in every --Act_D."
                            [[ -z ${_KEYS_} ]] && _KEYS_="$3 " ||_KEYS_+=" $3"
                            shift 1
                            ;;
                        -O) OPT_PART=" [OPTIONS]" ;;
                        -A) ARG_PART=" ${USAGE_GET_ARGS# }" ;;
                        -I) [[ ${3:0:1} == - ]] && _GET_ARGS_ERROR_ "$*" "For \"--Act_D ... -I ACTINFO ...\",  ACTINFO is missing or starts with a \"-\"."
                            INFO_PART=" $3"
                            shift 1
                            ;;
                       --*) break
                            ;;
                         *) _GET_ARGS_ERROR_ "$*" "GET_ARGS_OPTION --Act_D formatted incorrectly."
                            ;;
                      esac
                      shift 1				# Go to the next GET_ARGS_OPTION
                    done
                    if [[ -z ${SAVED_OPTLIST} ]] ; then
                      [[ $2 =~ --Des*_D* ]] && _GET_ARGS_ERROR_ "$*" "'--Des_D ...' must not follow an '--Act_D ...' that has an empty OPTLIST."
                    else
                      [[ ! $2 =~ --Des*_D* ]] && _GET_ARGS_ERROR_ "$*" "'--Des_D ...' must follow an '--Act_D ...' that has a non-empty OPTLIST."
                    fi
                    [[ -n ${DISPLAY_THIS_OPT} ]] && _GET_ARGS_Section_INSERT_ "$1" -N "A" "${CMD}${KEY_PART}${OPT_PART_BEG}${OPT_PART_MID}${OPT_PART_END}${OPT_PART}${ARG_PART}${INFO_PART}"
                    ACTION_KEYWORD="${GLD}ACTION:${BLK} "
                    if [[ -n ${SAVED_OPTLIST} ]] ; then
                      IS_Act_D="1"
                      shift 1
                      _SHIFT_ME_="0"
                    else				# No OPTLIST so look at nets GET_ARGS_OPTION
                      _PREVIOUS_OPTION_="${_THIS_OPTION_}"
                      continue
                    fi
                    ;&					# Continue parsing as if it were --Opt_D
         --Opt*_D*|--Hid*_D*)
                    _USAGE_OPTIONS_=" [OPTIONS]"
                    unset USAGE_MESSAGE_PART
                    OPT_SHIFT=0 ; OPT_COLONS=0
                    if (( IS_Act_D )) ; then
                      BAD_COLON="OPTLIST \"${SAVED_OPTLIST}\""
                      OPTLIST="${SAVED_OPTLIST#\*}"	# There might be a "repeat this option (*)" indicator
                      if [[ ${OPTLIST} =~ @ ]]		# Do we want to redefine the KEYWORD?
                        then OPTLIST_KEYWORD="${SAVED_OPTLIST##*@}"
                             OPTLIST="${SAVED_OPTLIST%@*}"
                        else OPTLIST_KEYWORD="VALUE"
                      fi
                    else
                      (( ! Des_D_FOUND )) && _GET_ARGS_ERROR_ "$*" "--Opt_D does not have a corresponding --Des_D."
                      [[ ${!FC:0:1}${!OPTLIST_ARG:0:1} =~ - || -z ${!OPTLIST_ARG} ]] && _GET_ARGS_ERROR_ "$*" "OPTLIST or FC missing or contains a \"-\"."
                      if [[ $1 =~ ^--Hid[[:alpha:]]*_D ]] ; then
                        unset DISPLAY_THIS_OPT
                      else
                        _GET_ARGS_DISPLAY_THIS_ "${!FC_ARG}" "$1 ${!FC_ARG@Q} ${!OPTLIST_ARG@Q}" && DISPLAY_THIS_OPT="1" || unset DISPLAY_THIS_OPT
                      fi
                      BAD_COLON="OPTLIST \"${!OPTLIST_ARG}\""
                      OPTLIST="${!OPTLIST_ARG#\*}"	# There might be a "repeat this option (*)" indicator
                      if [[ ${OPTLIST} =~ @ ]]		# Do we want to redefine the KEYWORD?
                        then OPTLIST_KEYWORD="${!OPTLIST_ARG##*@}"
                             OPTLIST="${OPTLIST%@*}"
                        else OPTLIST_KEYWORD="VALUE"
                      fi
                    fi
                    unset Des_D_FOUND
                    BAD_COLON+=" has incompatible use of \":\".\nEither one or two colons can be used and each Opt_i must have the same number of colons."
                    OPT_LEN=0
                    unset OPT_ARG_SAVED
                    OPTLISTCOUNT="0"
                    for ONE_OPT in ${OPTLIST//,/ } ; do	# Parse the OPTLIST (converting ',' to ' ')
                      (( OPTLISTCOUNT++ ))
                      OPT_ARG="${ONE_OPT//:}"		# Remove ":" (if any)
                      [[ ${_ALL_OPTIONS_} =~ \ ${OPT_ARG}\  ]] && _GET_ARGS_ERROR_ "$*" "The option \"${OPT_ARG}\" is a duplicate of one previously defined."
                      _ALL_OPTIONS_+="${OPT_ARG} "	# Remember all that were defined
                      OPT_COLON="${ONE_OPT##${OPT_ARG}}"	# Get the ":"s
                      OPT_COLON="${#OPT_COLON}"		# Count them
                      (( OPT_COLON > 2)) && _GET_ARGS_ERROR_ "$*" "${BAD_COLON}"
                      if (( ! OPT_COLONS ))
                        then OPT_COLONS="${OPT_COLON}"	# Remember how many ":"s
                        else (( OPT_COLON != OPT_COLONS )) && _GET_ARGS_ERROR_ "$*" "${BAD_COLON}"
                      fi
                      if [[ ${ONE_OPT} == ${OPT_ARG} ]]	# I.E. There is no ":"
                        then (( "${OPT_SHIFT}" == 2 )) && _GET_ARGS_ERROR_ "$*" "${BAD_COLON}"
                             OPT_SHIFT="1"
                             unset OPT_VALUE
                        else (( "${OPT_SHIFT}" == 1 )) && _GET_ARGS_ERROR_ "$*" "${BAD_COLON}"
                             OPT_SHIFT="2"
                             if (( OPT_COLON == 2 )) ;  then
                               local EQU="="
                               unset OPT_VALUE
                               (( ${#OPT_ARG} == 1 )) && unset EQU
                               OPT_OPTIONAL="[${EQU}${OPTLIST_KEYWORD}]"
                             else OPT_VALUE="${OPTLIST_KEYWORD}"
                             fi
                      fi
                      # If -h, -H, -t, -v, etc. have been defined by --Opt_D, --Act_D or --Hid_D do not show it in the USAGE message.
                      case "${OPT_ARG}" in
                              ${_h_}) unset _getopt_h_        _option_h_      _USAGE_h_       ;;
                           ${_help_}) unset _getopt_help_     _option_help_   _USAGE_help_    ;;
                              ${_H_}) unset _getopt_H_        _option_H_      _USAGE_H_       ;;
                           ${_HELP_}) unset _getopt_HELP_     _option_HELP_   _USAGE_HELP_    ;;
                              ${_t_}) unset _getopt_t_        _option_t_      _pattern_t_     ;;
                           ${_test_}) unset _getopt_test_     _option_test_   _pattern_test_  ;;
                              ${_v_}) unset _getopt_v_        _option_v_                      ;;
                        ${_version_}) unset _getopt_version_  _option_version_                ;;
                      esac
                      if (( ${#OPT_ARG} == 1 ))		# "-' or "--"
                        then OPT_DASH="-"
                             OPTIONS+="${ONE_OPT}"
                        else OPT_DASH="--"
                             [[ -n ${OPT_OPTIONAL} ]] && OPT_OPTIONAL="${OPT_OPTIONAL}"
                             LONG_OPTIONS="${ONE_OPT},${LONG_OPTIONS}"
                             [[ -n ${OPT_VALUE} ]] && OPT_VALUE="=${OPT_VALUE}"
                      fi
                      # Create an array of valid OPTLIST and the corresponding SHIFT values
                      OPT_NAMES[OPT_NUM]="${OPT_NAMES[OPT_NUM]% } ${OPT_DASH}${OPT_ARG}"
                      OPT_SHIFTS[OPT_NUM]="${OPT_SHIFT}"
                      OPT_TMP="${OPT_DASH}${OPT_ARG}${OPT_OPTIONAL}"
                      OPT_LEN="$((OPT_LEN + ${#OPT_TMP} + ${#OPT_VALUE} + 1 ))"
                      if (( OPTLISTCOUNT == 1 )) ; then
                        USAGE_MESSAGE_PART+="${OPT_TMP}"
                        Alt_Opt_Idx="${OPT_DASH}${OPT_ARG}"
                        Alt_Opt[${Alt_Opt_Idx}]+=" "
                      else
                        USAGE_MESSAGE_PART+=" ${OPT_TMP}"
                        Alt_Opt[${Alt_Opt_Idx}]+="${OPT_DASH}${OPT_ARG} "
                      fi
                      unset OPT_OPTIONAL
                      [[ -z ${OPT_ARG_SAVED} ]] && OPT_ARG_SAVED="${OPT_ARG}"
                    done
                    if (( IS_Act_D )) ; then
                      [[ ${SAVED_OPTLIST:0:1} != '*' ]] && IS_Star="1" || unset IS_Star
                    else
                      [[ ${!OPTLIST_ARG:0:1} != '*' ]] && IS_Star="1" || unset IS_Star
                    fi
                    if (( IS_Star )) ; then
                      OPTLIST_STARS[OPT_NUM]="${OPT_ARG_SAVED}"	# There is a "*". Test for this below
                    else
                      OPTLIST_STARS[OPT_NUM]=""			# No "*". Test for this below
                    fi
                    USAGE_MESSAGE_PART="${USAGE_MESSAGE_PART% }${OPT_VALUE}"
                    ((OPT_NUM++))
                    (( IS_Act_D )) && unset IS_Act_D || _SHIFT_ME_=${SHIFT_ARGS} ;;
         --Des*_D*) [[ ${2:0:2} == -- || -z ${2} ]] && _GET_ARGS_ERROR_ "$*" "GET_ARGS_OPTION --Opt_D has a missing description or it starts with \"-\"."
                    Des_D_FOUND="1"
                    [[ ${_FM_brief_} == "${_b_}" ]] && OPT_LEN=$(( TAB_STOP_WIDTH + 1 ))	# If brief help requested, always want the description on the next line.
                    if (( OPT_LEN < TAB_STOP_WIDTH ))
                      then USAGE_MESSAGE_PART+="\t${ACTION_KEYWORD}${2}"
                      else USAGE_MESSAGE_PART+="\n\t\t${ACTION_KEYWORD}${2}"
                    fi
                    ACTION_KEYWORD=""
                    (( DISPLAY_THIS_OPT )) && _GET_ARGS_Section_INSERT_ "$1" "O" "${USAGE_MESSAGE_PART}"
                    unset USAGE_MESSAGE_PART
                    _SHIFT_ME_=2 ;;
          --Action) if _GET_ARGS_DISPLAY_THIS_ "${!FC_ARG}" $1 ; then
                      if [[ -z ${USAGE_ACTION_INFO} ]]
                        then USAGE_ACTION_INFO=" ${GLD}${!TEXT_ARG}${BLK}"
                        else USAGE_ACTION_INFO=" [${USAGE_ACTION_INFO/\] /} ${GLD}${!TEXT_ARG}${BLK} ]"
                             USAGE_ACTION_INFO="${USAGE_ACTION_INFO/\[ \[/[}"
                      fi
                    fi
                    _SHIFT_ME_=${SHIFT_ARGS} ;;
       --Args_Non*) Args_Required="0" ; unset Args_Array ; Args_None="1"
                    _GET_ARGS_Args_VERIFY_ "$1" "${!FC_ARG}" "${!COUNT_ARG}"
                    _GET_ARGS_DISPLAY_THIS_ "${!FC_ARG}" "$1 ${!FC_ARG@Q}" && DisplayArgMessage="1" || unset DisplayArgMessage
                    _SHIFT_ME_=$((SHIFT_ARGS - 1)) ;;
       --Args_Arr*) Args_Array="1" ; unset Args_None
                    if [[ ${!COUNT_ARG:0:1} == @ ]]	# --Args_Array has a KEYWORD
                      then _GET_ARGS_Args_VERIFY_ "$1" "${!FC_ARG}" "${!COUNT_ARG}"
                           SHIFT=${SHIFT_ARGS}
                      else _GET_ARGS_Args_VERIFY_ "$1" "${!FC_ARG}" ""
                           SHIFT=$((SHIFT_ARGS - 1))
                    fi
                    _GET_ARGS_DISPLAY_THIS_ "${!FC_ARG}" "$1 ${!FC_ARG@Q}"
                      _GET_ARGS_Section_INSERT_ "$1" "N" "Zero to any number of arguments may be specified."
                    _SHIFT_ME_=${SHIFT} ;;
       --Args_Opt*) Args_Optional="${!COUNT_ARG%%@*}" ; Args_Array="1" ; unset Args_None
                    _GET_ARGS_Args_VERIFY_ "$1" "${!FC_ARG}" "${!COUNT_ARG}"
                    if _GET_ARGS_DISPLAY_THIS_ "${!FC_ARG}" "$1 ${!FC_ARG@Q} ${!COUNT_ARG}" ; then
                      _GET_ARGS_Section_INSERT_ "$1" "N" "Up to ${Args_Optional} argument(s) may be specified."
                    fi
                    _SHIFT_ME_=${SHIFT_ARGS} ;;
       --Args_Req*) Args_Required="${!COUNT_ARG%%@*}" ; Args_Array="1" ; unset Args_None
                    _GET_ARGS_Args_VERIFY_ "$1" "${!FC_ARG}" "${!COUNT_ARG}"
                    if _GET_ARGS_DISPLAY_THIS_ "${!FC_ARG}" "$1 ${!FC_ARG@Q} ${!COUNT_ARG}" ; then
                      if [[ -z ${!TEXT_ARG} ]]
                        then _GET_ARGS_Section_INSERT_ "$1" "N" "Additional arguments may be specified."
                        else _GET_ARGS_Section_INSERT_ "$1" "N" "Exactly ${Args_Required} argument(s) must be specified."
                      fi
                    fi
                    _SHIFT_ME_=${SHIFT_ARGS} ;;
       --Args_Min*) Args_Minimum="${!COUNT_ARG%%@*}" ; Args_Array="1" ; unset Args_None
                    _GET_ARGS_Args_VERIFY_ "$1" "${!FC_ARG}" "${!COUNT_ARG}"
                    if _GET_ARGS_DISPLAY_THIS_ "${!FC_ARG}" "$1 ${!COUNT_ARG}" ; then
                      _GET_ARGS_Section_INSERT_ "$1" "N" "A minimum of ${Args_Minimum} argument(s) must be specified."
                    fi
                    _SHIFT_ME_=${SHIFT_ARGS} ;;
       --Args_Max*) Args_Maximum="${!COUNT_ARG%%@*}" ; Args_Array="1" ; unset Args_None
                    _GET_ARGS_Args_VERIFY_ "$1" "${!FC_ARG}" "${!COUNT_ARG}"
                    if _GET_ARGS_DISPLAY_THIS_ "${!FC_ARG}" "$1 ${!COUNT_ARG}" ; then
                      _GET_ARGS_Section_INSERT_ "$1" "N" "A maximum of ${Args_Maximum} argument(s) can be specified."
                    fi
                    _SHIFT_ME_=${SHIFT_ARGS} ;;
       --Opts_Req*) Opts_Required="${!COUNT_ARG}"
                    _GET_ARGS_Opts_VERIFY_ "$1" "${!COUNT_ARG}" "${!FC_ARG}"
                    if _GET_ARGS_DISPLAY_THIS_ "${!FC_ARG}" "$1 ${!FC_ARG@Q} ${!COUNT_ARG}" ; then
                      _GET_ARGS_Section_INSERT_ "$1" "N" "Exactly ${Opts_Required} option(s) must be specified."
                    fi
                    _SHIFT_ME_=${SHIFT_ARGS} ;;
       --Opts_Min*) Opts_Minimum="${!COUNT_ARG}"
                    _GET_ARGS_Opts_VERIFY_ "$1" "${!COUNT_ARG}" "${!FC_ARG}"
                    if _GET_ARGS_DISPLAY_THIS_ "${!FC_ARG}" "$1 ${!FC_ARG@Q} ${!COUNT_ARG}" ; then
                      _GET_ARGS_Section_INSERT_ "$1" "N" "A minimum of ${Opts_Minimum} option(s) must be specified."
                    fi
                    _SHIFT_ME_=${SHIFT_ARGS} ;;
           --Where) _GET_ARGS_DISPLAY_THIS_ "${!FC_ARG}" "$1 ${!FC_ARG@Q} ${!TEXT_ARG}" && _GET_ARGS_Section_INSERT_ "$1" "W" "${!TEXT_ARG}"
                    _SHIFT_ME_=${SHIFT_ARGS} ;;
            --Info) _GET_ARGS_DISPLAY_THIS_ "${!FC_ARG}" "$1 ${!FC_ARG@Q} ${!TEXT_ARG}" && _GET_ARGS_Section_INSERT_ "$1" "I" "${!TEXT_ARG}"
                    _SHIFT_ME_=${SHIFT_ARGS} ;;
           --Exam*) _GET_ARGS_DISPLAY_THIS_ "${!FC_ARG}" "$1 ${!FC_ARG@Q} ${!TEXT_ARG}" && _GET_ARGS_Section_INSERT_ "$1" "E" "${!TEXT_ARG}"
                    _SHIFT_ME_=${SHIFT_ARGS} ;;
           --Para*) ;&					# Continue on to --Title)
           --Title) if [[ ${!TEXT_ARG} == -N ]] ; then
                      _GET_ARGS_DISPLAY_THIS_ "${!FC_ARG}" "$1 ${!FC_ARG@Q} ${!TEXT_ARG3}" && \
                        _GET_ARGS_Section_INSERT_ $1 "${!TEXT_ARG}" "${!TEXT_ARG2}" "${!TEXT_ARG3}"
                      _SHIFT_ME_=$(( SHIFT_ARGS + 2 ))
                    else
                      _GET_ARGS_DISPLAY_THIS_ "${!FC_ARG}" "$1 ${!FC_ARG@Q} ${!TEXT_ARG2}" && \
                        _GET_ARGS_Section_INSERT_ $1 "${!TEXT_ARG}" "${!TEXT_ARG2}"
                      _SHIFT_ME_=$(( SHIFT_ARGS + 1 ))
                    fi ;;
           --Head*) _HEADING_="${2}"
                    _SHIFT_ME_="2" ;;
          --Cmd_D*) [[ ${!TEXT_ARG:0:2} == -- ]] && _GET_ARGS_Args_MISSING_ "$1" "$2"
                    _GET_ARGS_Section_INSERT_ "$11" "D" "${!TEXT_ARG}"
                    _SHIFT_ME_=${SHIFT_ARGS} ;;
           --Copy*) if _GET_ARGS_DISPLAY_THIS_ "${!FC_ARG}" "$1 ${!FC_ARG@Q} ${!TEXT_ARG}" ; then
                      if [[ ${!TEXT_ARG:0:2} == -- ]] ; then	# If the next arg starts with "--" use the default copyright.
                        _GET_ARGS_Section_INSERT_ "$1" "C" "Copyright © 2021 Free Software Foundation, Inc.  License GPLv3+: GNU GPL version 3 or later <https://gnu.org/licenses/gpl.html>.\n\tThis is free software: you are free to change and redistribute it.  There is NO WARRANTY, to the extent permitted by law."
                        _SHIFT_ME_=$((SHIFT_ARGS - 1))
                      else
                        _GET_ARGS_Section_INSERT_ "$1" "C" "${!TEXT_ARG}"
                        _SHIFT_ME_=${SHIFT_ARGS}
                      fi
                    fi ;;
          --Filter) _FILTER_IS_ON_="1"
                    if [[ ${2:0:1}${3:0:1} =~ - ]]
                      then _GET_ARGS_ERROR_ "$*" "GET_ARGS_OPTION --Filter arguments are missing or incorrrect. They must not start with a \"-\"."
                    fi
                    FC="${2:0:1}"
                    [[ ${FC} =~ [${_a_}${_b_}${_c_}${_e_}] ]] && _GET_ARGS_ERROR_ "$*" "--Filter code \"${FC}\" is reserved.\nReserved codes are: ${_a_}=all, ${_b_}=brief, ${_c_}=compact and  ${_e_}=expand."
                    [[ ${FC} =~ [^A-Za-z0-9] ]] && _GET_ARGS_ERROR_ "$*" "--Filter code \"${FC}\" is not alphanumeric."
                    [[ ${VALID_FILTER_CODES} =~ ${FC} ]] && _GET_ARGS_ERROR_ "$*" "Filter GET_ARGS_OPTION \"--Filter $2\" is a duplicate of a previous filter."
                    VALID_FILTER_CODES+="${FC}"	# Remember the code
                    if [[ -z ${FILTER_HELP_MESSAGE_PFX} ]] ; then	# Only want to do it once
                      FILTER_HELP_MESSAGE_PFX="${CMD}: ${RED}ERROR:${BLK} Invalid or missing help filter <FC> \"${FILTER_CODE}\".\nFor more help, use one of:"
                      FILTER_HELP_MESSAGE_SFX="\nAcceptable <FM> modifiers are: ${_b_}, ${_c_} and ${_e_}.\n\tFC/FM\tHELP TO BE DISPLAYED\n\t  ${_a_}\t${_a_msg_}\n\t  ${_b_}\t${_b_msg_}\n\t  ${_c_}\t${_c_msg_}\n\t  ${_e_}\t${_e_msg_}"
                      FC_ARG="2" COUNT_ARG="3" ; TEXT_ARG="3" ;TEXT_ARG2="4" ;  TEXT_ARG3="5" ; OPTLIST_ARG="3" ; SHIFT_ARGS="3"	# Redefine the defaults
                    fi
                    FILTER_HELP_MESSAGE_SFX+="\n\t  ${FC}\t$3"
                    FILTER_HELP_TEXT[${FC}]="$3"	# Remember the text of the filter code
                    _SHIFT_ME_=3 ;;
         --Bas*_O*) _SHIFT_ME_=2 ;;			# The gawk filter pre-scan processes this
           --Comp*) _SHIFT_ME_=1 ;;			# The gawk filter pre-scan processes this
            --Save) _SHIFT_ME_=1 ;;			# The gawk filter pre-scan processes this
            --Tab*) _SHIFT_ME_=2 ;;			# The gawk filter pre-scan processes this
      --Exec*_Pri*) [[ ${2:0:2} == -- ]] && _GET_ARGS_Args_MISSING_ "$1" "$2"
                    Exec_Prior="$2"
                    _SHIFT_ME_=2 ;;
      --Exec*_Pos*) [[ ${2:0:2} == -- ]] && _GET_ARGS_Args_MISSING_ "$1" "$2"
                    Exec_Post="$2"
                    _SHIFT_ME_=2 ;;
                --) shift 1				# End of GET_ARGS arguments
                    break ;;
                 *) _GET_ARGS_ERROR_ "This option=${_THIS_OPTION_} <==> The previous option=${_PREVIOUS_OPTION_} $*" "The last two arguments to GET_ARGS must be \"--\" and \"\$@\".\nThe previous option may be incorrect or there is a missing line continuation."
                    break ;;
      esac
      _PREVIOUS_OPTION_="${_THIS_OPTION_}"
      (( _SHIFT_ME_ )) && shift ${_SHIFT_ME_}
      _SHIFT_ME_="0"
    done
    ##                     _GET_ARGS_Section_INSERT_ "$1" "N" "No arguments may be specified."
    (( (Args_Array == 0 && Args_None == 1 ) && DisplayArgMessage )) && _GET_ARGS_Section_INSERT_ "--Args_None" "N" "No arguments are allowed."
    # End of GET_ARGS_OPTIONS parsing. Final task is to set the Alt_Opt array for the BASIC OPTIONS
    _GET_ARGS_SET_Alt_Opt_ "${_option_h_}" "${_option_help_}"
    _GET_ARGS_SET_Alt_Opt_ "${_option_H_}" "${_option_HELP_}"
    _GET_ARGS_SET_Alt_Opt_ "${_option_t_}" "${_option_test_}"
    _GET_ARGS_SET_Alt_Opt_ "${_option_v_}" "${_option_version_}"
    if (( SAVE_VARIABLES )) ; then			# Parsing optimization requested?
      set > "${ENVIRONMENT_AFTER_FILE}"			# Save the environment again then create the file
      diff "${ENVIRONMENT_BEFORE_FILE}" "${ENVIRONMENT_AFTER_FILE}" --ed --suppress-common-lines | grep "=" > "${SAVED_VARIABLES_FILE}"
    fi
  fi
  # Now parse parent script options
  [[ -n ${Exec_Prior} ]] && ${Exec_Prior}		# Execute the "pre GET_ARGS" command
  LONG_OPTIONS="${LONG_OPTIONS}${_getopt_help_}${_getopt_HELP_}${_getopt_test_}${_getopt_version_}"
  OPTS=$( getopt --name "${CMD}" --options ${OPTIONS}${_getopt_h_}${_getopt_H_}${_getopt_t_}${_getopt_v_} --longoptions ${LONG_OPTIONS%,} -- "$@" )
  CODE=$?
  (( CODE == 1 )) && _GET_ARGS_ERROR_ "$*" "getopt: Invalid option."
  (( CODE > 1 ))  && _GET_ARGS_ERROR_ "$*" "getopt: Script getopt parameters invalid or internal error."
  eval set -- "${OPTS}"
  OPT_NUM=0 ; Opts_All=" "
  local OPT_ARRAY
  local Index First_Opt
  for Index in ${!OPT_NAMES[*]} ; do			# Ensure all Opt_OPTi, Opt_OPTi_Val variables are unset.
    First_Opt=( ${OPT_NAMES[Index]} )
    First_Opt="${First_Opt:1}"
    [[ ${First_Opt:0:1} == - ]] && First_Opt="${First_Opt:1}"
    unset Opt_${First_Opt//-/_} Opt_${First_Opt//-/_}_Val
  done

  while true ; do					# Options/Arguments - one by one
    [[ ${1} == "" ]] && { shift 1 ; continue ; }
    [[ ${1} == -- ]] && { shift 1 ; break ; }
    if (( ${#OPT_NAMES[*]} > 0 )) ; then		# Any "--Opt_D" GET_ARGS_OPTION used?
      for ((I=0 ; I<${#OPT_NAMES[*]} ; I++)) ; do
        if [[ " ${OPT_NAMES[I]} " =~ " ${1} " ]] ; then
          OPT_ARRAY=( ${OPT_NAMES[I]} )			# Remove the leading space
          OPT_D="${OPT_ARRAY[0]}"			# Just use the first OPT in OPTLIST
          (( ${#OPT_D} == 2 )) && OPT_DASH="-" || OPT_DASH="--"
          OPT_D="${OPT_D#${OPT_DASH}}"			# Remove leading "-"
          if [[ ${Opts_All} =~ " ${OPT_DASH}${OPT_D} " ]]
            then [[ ${OPTLIST_STARS[I]} == ${OPT_D} ]] && { OPT_NAMES[I]=${OPT_NAMES[I]# } ; _GET_ARGS_ERROR_ "$*" "Option(s) ${OPT_NAMES[I]// /\|} must not be used more than once." ; }
          fi
          Opts_All="${Opts_All}${OPT_DASH}${OPT_D} "	# Create a space separated list of options found
          OPT_D="${OPT_D//-/_}"				# Convert remaining "-" to "_" to make it a valid variable name.
          ((OPT_NUM++))
          eval "(( Opt_${OPT_D}++ ))"			# Create/Increment the "OPT" variable
          eval [[ -z \${Opt_${OPT_D}_Val[\$\{#Opt_${OPT_D}_Val\[\*\]}]} ]] && unset SPACE || SPACE=\" \"	# Only a space if two or more VALUEs
          (( ${OPT_SHIFTS[I]} == 2 )) && eval Opt_${OPT_D}_Val[\$\{\#Opt_${OPT_D}_Val\[\*\]}]='"${2}"' || eval Opt_${OPT_D}_Val[\$\{\#Opt_${OPT_D}_Val\[\*\]}]=\"\"
          shift ${OPT_SHIFTS[I]}
          continue 2					# Get the next script parameter
        fi
      done
    fi
    case "${1} " in					# Implement the built-in options
      ${_option_h_:-""}|${_option_help_:-""}|${_option_H_:-""}|${_option_HELP_:-""})
          if (( _FILTER_IS_ON_ ))
            then FC_VAL="- '$2'"
            else unset FC_VAL
          fi
          ;;&
      ${_option_h_:-""}|${_option_help_:-""})
          USAGE_DEFAULT ${FC_VAL}
          return 1
          ;;&
      ${_option_H_:-""}|${_option_HELP_:-""})
          _USAGE_less_="|& less -R"
          USAGE_DEFAULT ${FC_VAL}
          return 1
          ;;
      ${_pattern_t_:-""}|${_pattern_test_:-""})
          local TEST_SHIFT="1"
          if [[ -n ${_pattern_t_} ]] ; then
            (( Opt_t++ ))
          elif [[ -n ${_pattern_test_} ]] ; then
            (( Opt_test++ ))
          fi
          TEST_SET
          # Now look for the keyword NOCLEANUP (in fact, any non-empty value for NOCLEANUP will work).
          _CLEANUP_ALWAYS_="1"
          if [[ -n ${_option_t_} ]] ; then
            if [[ -n ${2} && ${2:0:1} != - ]] ; then
              unset _CLEANUP_ALWAYS_
              TEST_SHIFT="2"
            fi
          elif [[ -n ${_option_test_} ]] ; then
            if [[ -n ${2} && ${2:0:1} != - ]] ; then
              unset _CLEANUP_ALWAYS_
              TEST_SHIFT="2"
            fi
          fi
          shift ${TEST_SHIFT}
          ;;
      ${_option_v_:-""}|${_option_version_:-""})
          echo -e "The current version is: ${SCRIPT_VERSION:-UNKNOWN}" ; (( IS_USAGE_EXIT )) && exit 2 || return 2
          ;;
       *) echo $* ; USAGE "Last two arguments to GET_ARGS must be \"--\" and then \"\$@\"."
          return 1
          ;;
    esac
  done
  # If options are expected (--Opts_Req N) then:
  if (( Opts_Required )) ; then
    Opts_Req="${Opts_Required}"
    (( TEST_SET )) && Opts_Required="$((Opts_Required++))"
    (( OPT_NUM != Opts_Required )) && _GET_ARGS_ERROR_ "$*" "Incorrect number of options.\nNumber of OPTIONS required is: ${Opts_Req}. OPTIONS found: ${OPT_NUM}."
  fi
  if (( Opts_Minimum )) ; then
    Opts_Min="${Opts_Minimum}"
    (( TEST_SET )) && Opts_Minimum="$((Opts_Minimum++))"
    (( OPT_NUM < Opts_Minimum )) && _GET_ARGS_ERROR_ "$*" "Incorrect number of options.\nMinimum number of OPTIONS required is: ${Opts_Min}. OPTIONS found: ${OPT_NUM}."
  fi
  # If action keys are expected, check the first arg to see if it matches, then remove the argument
  if [[ -n ${_KEYS_} ]] ; then
    if [[ \ ${_KEYS_}\  =~ \ $1\  ]] ; then
      Act_Key="$1"
      shift 1
    else
      _GET_ARGS_ERROR_ "$*" "Invalid action key \"$1\". Valid keys are \"${_KEYS_// /, }\"."
    fi
  else
    unset Act_Key
  fi
  # If no args expected (--NoArgs) then:
  (( Args_None && $# > 0 )) && _GET_ARGS_ERROR_ "$*" "No arguments are allowed."
  # If args expected or optional but not supplied or an incorrect number:
  if (( Args_Optional )) ; then
    (( $# == Args_Optional || $# == 0 )) || _GET_ARGS_ERROR_ "$*" "Incorrect number of arguments.\nNumber of optional ARGS allowed is: 0 or ${Args_Optional}. ARGS found: $# (${*@Q})."
  fi
  if (( Args_Required )) ; then
    (( $# != Args_Required )) && _GET_ARGS_ERROR_ "$*" "Incorrect number of arguments.\nNumber of ARGS required is: ${Args_Required}. ARGS found: $# (${*@Q})."
  fi
  if (( Args_Minimum )) ; then
    (( $# < Args_Minimum )) && _GET_ARGS_ERROR_ "$*" "Incorrect number of arguments.\nMinimum number of ARGS required is: ${Args_Minimum}. ARGS found: $# (${*@Q})."
  fi
  if (( Args_Maximum )) ; then
    (( $# > Args_Maximum )) && _GET_ARGS_ERROR_ "$*" "Incorrect number of arguments.\nMaximum number of ARGS allowed is: ${Args_Maximum}. ARGS found: $# (${*@Q})."
  fi
  # If --Args_Array then parse remaining arguments to create Args[1]="...", Args[2]="..." etc.
  unset Args
  if (( Args_Array )) ; then
    for (( I=1 ; I <= $# ; I++ )) ; do
      Args[I]="${!I}"					# Remember the argument
    done
  fi
  shift $#						# Ignore every script argument
  [[ -n ${Exec_Post} ]] && ${Exec_Post}			# Execute the "post GET_ARGS" command
  return $#						# The return code is the number of un-processed non-option arguments.
}

function _GET_ARGS_Args_MISSING_() {
  _GET_ARGS_ERROR_ "$2 $3" "GET_ARGS_OPTION \"${1}\": Required argument missing."
}

# INTERNAL FUNCTION - Called by GET_ARGS_DEFAULT
function _GET_ARGS_Args_VERIFY_() {
  local ARG_KEYWORD Idx					# ARG_COUNT
  if [[ -n ${_GET_ARGS_Args_VERIFY_CALLED_} ]]
    then _GET_ARGS_ERROR_ "" "GET_ARGS_OPTION \"${1}\" not allowed: \"${_GET_ARGS_Args_VERIFY_CALLED_}\" already specified."
    else _GET_ARGS_Args_VERIFY_CALLED_="$1"
  fi
  if [[ $3 =~ @ ]]
    then ARG_KEYWORD="${3##*@}"
    else ARG_KEYWORD="ARG"
  fi
  if (( Args_None )) ; then
    USAGE_GET_ARGS=""
  elif [[ -n ${Args_Optional} && ${Args_Optional} -ne 0 ]] ; then
    USAGE_GET_ARGS=" ["
    if (( Args_Optional == 1 ))
      then USAGE_GET_ARGS="${USAGE_GET_ARGS% } ${ARG_KEYWORD}"
      else for (( Idx=1 ; Idx <= "${Args_Optional}" ; Idx++ )) ; do
             USAGE_GET_ARGS="${USAGE_GET_ARGS% } ${ARG_KEYWORD}_${Idx}"
           done
    fi
    USAGE_GET_ARGS="${USAGE_GET_ARGS% } ]"
  elif (( Args_Required + Args_Minimum + Args_Maximum )) ; then
    local Bracket
    if (( Args_Required + Args_Minimum + Args_Maximum == 1 ))
      then (( Args_Maximum == 1 )) && USAGE_GET_ARGS=" [ ${ARG_KEYWORD} ]" || USAGE_GET_ARGS=" ${ARG_KEYWORD}"
      else USAGE_GET_ARGS=""
        for (( Idx=1 ; Idx <= "${Args_Required}${Args_Minimum}${Args_Maximum}" ; Idx++ )) ; do
          if (( Args_Maximum )) ; then
            USAGE_GET_ARGS="${USAGE_GET_ARGS% } [ ${ARG_KEYWORD}_${Idx}"
            Bracket+="]"
          else
            USAGE_GET_ARGS="${USAGE_GET_ARGS% } ${ARG_KEYWORD}_${Idx}"
          fi
        done
    fi
    (( Args_Minimum )) && USAGE_GET_ARGS+="..."
    (( Args_Maximum )) && USAGE_GET_ARGS+=" ${Bracket}"
  else
    USAGE_GET_ARGS=" [ ${ARG_KEYWORD}... ]"
  fi
}

function _GET_ARGS_DISPLAY_THIS_() {
  local FC F_CODE F_CODES I OPTION_CODES
  _GET_ARGS_OPTION_FOUND_="1"
  (( ! _FILTER_IS_ON_ )) && return 0			# If no --Filter then all paragraphs will be displayed.
  F_CODES="${1:=${_a_}}"				# Substitute the default if $1 empty
  F_CODES="${F_CODES//[ ,]/}"				# No spaces or commas please
  [[ "${FILTER_CODE}${F_CODES}" =~ "${_a_}" ]] && return 0 # If <FC>=`${_a_}' then all paragraphs will be displayed.
  for (( I = 0 ; I < ${#F_CODES} ; I++ )) ; do
    FC="${F_CODES:${I}:1}"				# Pick up the <FC> one-by-one
    # Is the GET_ARGS_OPTION filter code (FC) one of the VALID_FILTER_CODES
    [[ ${VALID_FILTER_CODES} =~ "${FC}" ]] || _GET_ARGS_ERROR_ "" "Filter code \"${FC}\" for \"$2\" has not been defined by --Filter."
    [[ ${FC} == "${FILTER_CODE}" ]] && return 0		# If there is a match return success.
  done
  return 1						# No match - don't display the paragrapph
}

# INTERNAL FUNCTION - Called by GET_ARGS_DEFAULT
function _GET_ARGS_ERROR_() {
  local CURRENT_ARGS="${1//\\/\\\\}"
  shift 1
  ERROR "GET_ARGS: $@\nThe error occured in the area of: \"${CURRENT_ARGS:0:${ERROR_LENGTH:-80}}...\""
  return 1
}

# INTERNAL FUNCTION - Called by GET_ARGS_DEFAULT
function _GET_ARGS_Opts_VERIFY_() {
  if [[ -n ${_GET_ARGS_Opts_VERIFY_CALLED_} ]]
    then _GET_ARGS_ERROR_ "GET_ARGS_OPTION \"${1}\" not allowed. GET_ARGS_OPTION \"${_GET_ARGS_Opts_VERIFY_CALLED}_\" already specified."
    else _GET_ARGS_Opts_VERIFY_CALLED_="$1"
  fi
  [[ ${2:0:1}${3:0:1} == -- ]] && _GET_ARGS_ERROR_ "" "GET_ARGS_OPTION \"${1} ${2} ${3}\" incorrect number of arguments or argument starts with \"--\"."
}

# INTERNAL FUNCTION - Called by GET_ARGS_DEFAULT
# Usage:   _GET_ARGS_Section_INSERT_ GET_ARGS_OPTION [-N] SECTION MESSAGE
function _GET_ARGS_Section_INSERT_() {
  local Indent No_Extra_NL Option Section
  [[ $1 == --Title ]] && unset Indent || Indent="\t"
  Option="$1" ; shift 1
  [[ ${1} == -N ]] && { No_Extra_NL="1" ; shift 1 ; } || No_Extra_NL=0
  Section="${1:0:1}"
  [[ \ ${!USAGE_SECTION_HEADER[*]}\   =~ \ ${Section}\  ]] || _GET_ARGS_ERROR_ "" "For GET_ARGS_OPTION \"${Option}\": SECTION \"${1}\" is invalid.\nValid sections (in order) are:\n${_VALID_SECTIONS_}"
  if [[ -z ${USAGE_SECTION_TEXT[${Section}]} && ! ${Section} =~ [sbn] ]] ; then
    USAGE_SECTION_TEXT[${Section}]="${EXTRA_NL}${USAGE_SECTION_HEADER[${Section}]}\n"
    [[ -n ${2} ]] && USAGE_SECTION_TEXT[${Section}]+="${Indent}${2}\n"	# Only if TEXT is not empty
  else
    (( No_Extra_NL )) && USAGE_SECTION_TEXT[${Section}]+="${Indent}${2}\n" || USAGE_SECTION_TEXT[${Section}]+="${EXTRA_NL}${Indent}${2}\n"
  fi
  return ${No_Extra_NL}
}

# INTERNAL FUNCTION - Called by GET_ARGS_DEFAULT
# Usage:   __GET_ARGS_SET_Alt_Opt_ BasicOption1 BasicOption2
function _GET_ARGS_SET_Alt_Opt_() {
  if [[ -n $1 ]] ; then
    Alt_Opt[$1]=" $2 "
  elif [[ -n $2 ]] ; then
    Alt_Opt[$2]=" "				# First basic option was redefined so use $2 as the index
  fi
}

##________________________________________________________________________________
##
## GET_ALL_PC_NAMES - Returns a space-separated lowercase list of valid PC names.
##   Usage: GET_ALL_PC_NAMES [ -V VARIABLE ]
##   Where: -V VARIABLE, is the name of the variable containing the result.
##          Global variable "_ALL_PCS_" will always contain the list of all PCs.
##   Note:  Requires variable LOCAL_PCS to be set.
function GET_ALL_PC_NAMES() {
  declare -gx _ALL_PCS_="${LOCAL_PCS,,}"
  [[ $1 == -V ]] && eval ${2}=\"${_ALL_PCS_}\" || echo -n "${_ALL_PCS_}"
}

##________________________________________________________________________________
##
## GET_IP_FROM_DOMAIN - Convert a domain name into an IP address.
##     Accepts DNS 'A', "AAAA" and 'CNAME' names and displays the IP(s)
##     that match.
##   Usage: GET_IP_FROM_DOMAIN [ -A ] [ -Q ] [ -V VAR ] DOMAIN
##   Where: DOMAIN is a valid DNS domain name (A, AAAA, or CNAME)
##          -6 Get the IPv6 address. The default is to get IPv4 addresses
##          -A Display all IPs found rather than just the first one.
##          -V VAR Store the result in the array VAR rather than displaying
##                 the result.
function GET_IP_FROM_DOMAIN() {
  local ALL_IPS DOMAIN IP IPVER="-4" VAR
  while (( $# > 0 )) ; do
    case "$1" in
      -6) IPVER="-6"   ; shift 1 ;;
      -A) ALL_IPS="1"  ; shift 1 ;;
      -V) VAR="$2"
          unset ${VAR} ; shift 2 ;;
       *) break ;;
    esac
  done
  [[ $1 =~ \. ]] && DOMAIN="$1" || DOMAIN="${1}.${_LOCAL_DOMAIN_}."
  while read -u 4 IP REST ; do
    [[ ${IP} =~ \.$ ]] && continue
    [[ -n ${VAR} ]] && eval ${VAR}+=\( \"${IP}\" \) || echo "${IP}"
    (( ALL_IPS )) || return
  done 4< <( dig ${IPVER} +short "${DOMAIN}" 2>/dev/null )
}

##________________________________________________________________________________
##
## GET_LOCAL_DOMAIN_NAME - Returns the lowercase name of this PC's DOMAIN.
##   Usage: GET_LOCAL_DOMAIN_NAME [ -V VARIABLE ]
##   Where: -V VARIABLE, if used, is the name of the variable containing
##             the result.
##          Global variable "_LOCAL_DOMAIN_" will always contain the result
function GET_LOCAL_DOMAIN_NAME() {
  [[ $1 == -V ]] && eval ${2}=\"${_LOCAL_DOMAIN_}\" || echo -n "${_LOCAL_DOMAIN_}"
}
declare -gx _LOCAL_DOMAIN_="${THIS_PC_DOMAIN}"
_LOCAL_DOMAIN_="${_LOCAL_DOMAIN_,,}"

##________________________________________________________________________________
##
## GET_LOCAL_PC_NAME - Returns the lowercase name of THIS PC.
##   Usage: GET_LOCAL_PC_NAME [ -V VARIABLE ]
##   Where: -V VARIABLE, if used, is the name of the variable containing
##             the result.
##          Global variable "_LOCAL_PC_" will always contain the result
function GET_LOCAL_PC_NAME() {
  [[ $1 == -V ]] && eval ${2}=\"${_LOCAL_PC_}\" || echo "${_LOCAL_PC_}"
}
declare -gx _LOCAL_PC_="$(hostname -s)"
_LOCAL_PC_="${_LOCAL_PC_,,}"

##________________________________________________________________________________
##
## GET_MATCHING_NFS_DOMAIN_IN_FSTAB - Display the DNS domain of an NFS entry in
##     /etc/fstab that matches the domain of $1. Since  DNS domain names may have
##     any number of aliases the IP addresses of the  domains are used to make a
##     match.
##   Usage:   GET_MATCHING_NFS_DOMAIN_IN_FSTAB [ -I ] [ -Q ] [ -V VAR ] NFSPATH
##   Where:   -I Returns the IP address rather than  the matching domain name.
##            -Q Don't display error messages. Return 1
##            -V VAR Store the result in variable VAR rather than displaying it.
##            NFSPATH has the format domain[:path[ or IP[:path[
##   Returns: If successful, displays matching fstab domain name (or IP address
##            if '-I') and returns 0. Otherwise returns 1.
function GET_MATCHING_NFS_DOMAIN_IN_FSTAB() {
  local ARG_IP FSTAB_DOMAIN FSTAB_DOMAIN_IP QUIET RESULT VAR WANT_IP="0"
  while (( $# > 0 )) ; do
    case $1 in
     -I) WANT_IP="1" ; shift 1 ;;
     -Q) QUIET="$1"  ; shift 1 ;;
     -V) VAR="$2"    ; shift 2 ;;
      *) break ;;
    esac
  done
  GET_IP_FROM_DOMAIN ${QUIET} -V ARG_IP "${1%%:*}"
  for FSTAB_DOMAIN in $( GET_UNIQUE_NFS_DOMAINS_IN_FSTAB ) ; do # Collect all the possible (unique) nfs domains IPs
    GET_IP_FROM_DOMAIN ${QUIET} -V FSTAB_DOMAIN_IP "${FSTAB_DOMAIN}"
    if [[ ${FSTAB_DOMAIN_IP} == ${ARG_IP} ]] ; then
      (( ! WANT_IP )) && RESULT="${FSTAB_DOMAIN}" || RESULT="${FSTAB_DOMAIN_IP}"
      [[ -n ${VAR} ]] && eval ${VAR}=\"${RESULT}\" || echo "${RESULT}"
      return 0
    fi
  done
  return 1
}

##________________________________________________________________________________
##
## GET_OTHER_PC_NAME - Returns/Validates a lowercase PC name from the list of
##     PC names in this domain excluding the name of this PC.
##   Usage: GET_OTHER_PC_NAME [-V VARIABLE ] [ -S | PC ]
##   Where: -S Sets the global variable _OTHER_PCS_, unsets _OTHER_PC_
##          -V Sets VARIABLE to _OTHER_PCS_ and exits.
##          PC Is prompted for if missing. Otherwise it is compared against
##             the list of other PCs. A match returns 0 otherwise 1.
##   The global variable _OTHER_PCS_ will always contain the PC name list
##     minus this PC's name.
##   The global variable _OTHER_PC_ is unset if -S is used. Otherwise it will
##     contain the result.
##   Note:  Requires variable LOCAL_PCS to be set.
function GET_OTHER_PC_NAME() {
  local ARG OTHER_PCS _PC_ SET VAR
  unset _ERROR_MESSAGE_
  [[ -z ${_LOCAL_PC_} ]] && GET_LOCAL_PC_NAME -V _LOCAL_PC_
  [[ -z ${_ALL_PCS_} ]]  && GET_ALL_PC_NAMES -V _ALL_PCS_
  declare -gx _OTHER_PC_ _OTHER_PCS_
  OTHER_PCS=" ${_ALL_PCS_} "
  OTHER_PCS=( ${OTHER_PCS/ ${_LOCAL_PC_} / } )
  _OTHER_PCS_="${OTHER_PCS[*]}"
  while (( $# > 0 ))  ; do
    case ${1} in
      -S) SET="1" ; shift 1 ;;
      -V) VAR="$2"  ; shift 2 ;;
       *) _PC_="$1" ; shift 1 ;;
    esac
  done
  if (( SET )) ; then
    [[ -n ${VAR} ]] && eval ${VAR}=\"${_OTHER_PCS_}\"
    unset _OTHER_PC_
    return
  fi
  if [[ -z ${_PC_} ]] ; then
    unset _OTHER_PC_ ${VAR}
    ASK_WITH_MENU -M -H "\nSelect the other PC" OTHER_PCS
    (( $? > 0 )) && return
    _OTHER_PC_="${ANSWER_VAL}"
  else
    _OTHER_PC_="${_PC_,,}"
    if [[ ! " ${OTHER_PCS[*]} " =~ " ${_OTHER_PC_} " ]] ; then
      unset _OTHER_PC_
      ERROR "PC \"${_PC_}\" is invalid. Valid values are ${GLD}${_OTHER_PCS_}${BLK}."
    fi
  fi
  [[ -n ${VAR} ]] && eval ${VAR}=\"${_OTHER_PC_}\"
}

##________________________________________________________________________________
##
## GET_UNIQUE_NFS_DOMAINS_IN_FSTAB - Display all the NFS domain names found
##     in /etc/fstab
##   Usage: GET_UNIQUE_NFS_DOMAINS_IN_FSTAB [ -I ] [ -Q ] [ -V VAR ]
##   Where: -I Display the domain IP(s) rather than the names.
##          -Q Don't display error messages. Return 1
##          -V VAR Store the result in variable VAR rather than displaying it.
function GET_UNIQUE_NFS_DOMAINS_IN_FSTAB() {
  local IPS RESULT VAR
  while (( $# > 0 )) ; do
    case $1 in
      -I) IPS="1"    ;  shift 1 ;;
      -Q) QUIET="$1" ;  shift 1 ;;
      -V) VAR="$2"   ; shift 2 ;;
       *) break ;;
     esac
  done
  RESULT=( $( gawk '/^[^#].*:.*\snfs[0-9]*\s+/ { a=gensub(/:.*/,"","1",$1)} ; !seen[a]++ { printf("%s ", a) }' /etc/fstab ) )
  if (( IPS )) ; then
    for IPS in ${#RESULT[*]} ; do
      GET_IP_FROM_DOMAIN ${QUIET} -V RESULT[${IPS}] "${RESULT[IPS]}" || return 1
    done
  fi
  [[ -n ${VAR} ]] && eval ${VAR}=\"${RESULT[*]}\" || echo "${RESULT[*]}"
}

##________________________________________________________________________________
##
## HUMAN_READABLE - Displays a number in human readable format.
##   Usage: HUMAN_READABLE [ -1 ] [ -f FORMAT ] [ -l LENGTH ] [ -n ] \
##            [ -o OPTIONS ] [ NUMBERS... ]
##   Where: -1 Display the results as one field. I.E. '22.0MiB' rather than
##             the default '22.0 MiB'.
##          -f FORMAT is one of 'iec-i', 'iec' or 'si'. The default is 'iec-i".
##             Note: iec-i ==> 1 MiB=1024; iec ==> 1 MiB=1000; si ==> 1 MB=1000
##          -l LENGTH is the length in characters of the output.
##          -n Do not include 'B' in the output. I.E. '22.0 Mi' rather than
##             the default '22.0 MiB'.
##          -o OPTIONS Include any options allowed by 'numfmt'.
##   If NUMBERS... is not present, the numbers can be piped into HUMAN_READABLE
##     E.G. echo 1234567 | HUMAN_READABLE
##   All NUMBERS must only contain digits from the set '[0-9.]'.
function HUMAN_READABLE() {
  local Bytes="B" Fmt="iec-i" Len="8" Options Space=" "
  while true ; do
    case "$1" in
      -1) unset Space     ; shift 1 ;;
      -f) Fmt=${2:-iec-i} ; shift 2 ;;
      -l) Len=${2:-8}     ; shift 2 ;;
      -n) unset Bytes     ; shift 1 ;;
      -o) Options="$2"    ; shift 2 ;;
       *) break ;;
    esac
  done
  if [[ "${Fmt}" == iec-i ]] ; then
    numfmt --to="${Fmt}" --format="%${Len}.1f" ${Options} $* | sed -e 's/[A-Z]./'"${Space}"'&'"${Bytes}"'/' -e 's/\( \)\([0-9]*\)\([.0-9]*$\)/ \2'"${Space}"''"${Bytes}"'  /'
  else
    numfmt --to="${Fmt}" --format="%${Len}.1f" ${Options} $* | sed -e 's/[A-Z]$/'"${Space}"'&'"${Bytes}"'/' -e 's/\( \)\([0-9]*\)\([.0-9]*$\)/  \2'"${Space}"''"${Bytes}"' /'
  fi
}

##________________________________________________________________________________
##
## IS_EXCLUSIVE - Returns successfully to the parent script when a valid
##     combination of parent options is detected. Otherwise it issues an error
##     message and exits the calling script.
##   Usage: IS_EXCLUSIVE [--Strict] [EXCLOPT] OPTIONS
##   Where:
##     OPTIONS is a space separated list (arg_i) of the first OPTi in any
##       OPLIST (without the preceeding "-" or "--").
##     EXCLOPT is one of the following options:
##          <empty>  If EXCLOPT is not present then the options in OPTIONS
##                   are mutually exclusive (only one can be specified).
##       --Only_One  If specified, will check if only one (or none) of the
##                   arg_i has been specified.
##       --Default   If specified, will set OPTLIST arg_1 as the default if
##                   none of arg_2, arg_3 ... has been used.
##       --Just_One  If specified, will check if just one (or none) of the
##                   arg_i has been specified. No other options are allowed.
##       --One_Of    If specified, will check if exactly one of the arg_i
##                   has been specified.
##       --All_Of    If specified, will check if all (or none) of the arg_i
##                   have been specified.
##       --At_Least  If specified, will check if at least one of the arg_i
##                   has been specified.
##       --Only_With If specified, will verify the option specified in arg_1 can
##                   only be used with the options specified in arg_2, arg_3 ...
##       --Not_With  If specified, will check that the option specified in arg_1
##                   must not be paired with any of the options specified in
##                   arg_2, arg_3 ...
##       --Paired_With[=N]
##                   If specified, will check that any N options specified in
##                   arg_2, arg_3 ... must be used with arg_1. N defaults to 1
##       --Strict    If specified, modifies the test by counting every occurance
##                   of arg_i. By default IS_EXCLUSIVE tests if any single arg_i
##                   has been specified at least once. --Strict ensures only one
##                   occurance of any arg_i was specified. It must be the 1st arg.
##   EXAMPLES:
##    IS_EXCLUSIVE q V
##      Assuming -q can be used more than once,
##      returns TRUE only if either -q, -qq, -qqq... or -V (or none) is used.
##    IS_EXCLUSIVE --Strict q V
##      Returns TRUE if exactly one of -q or -V (or none) of the two is used.
##    IS_EXCLUSIVE --Only_One q V
##      Assuming -q can be used more than once,
##      returns TRUE only if just -q, -qq, -qqq... or -V (or none) is used.
##    IS_EXCLUSIVE --Default a b c
##      If none of -a, -b or -c has been used, sets Opt_a=1 and includes -a
##      in ${Opts_All}.
##    IS_EXCLUSIVE --Just_One q V
##      Returns TRUE if -q or -V is used with no other options, or if neither -q
##      or -V is used.
##    IS_EXCLUSIVE --One_Of q V
##      Returns TRUE only if one of -q, -qq, -qqq... or -V is used. One of them
##      must be used.
##    IS_EXCLUSIVE --Strict --One_Of q V
##      Returns TRUE only if exactly one of -q or -V is used. One of them must
##      be used.
##    IS_EXCLUSIVE --All_Of q V
##      Returns TRUE only if all of -q, -qq, -qqq... or -V is used.
##      In this case --Strict has no effect.
##    IS_EXCLUSIVE --At_Least q V
##      Returns TRUE if at least one of -q or -V is used.
##      In this case --Strict has no effect.
##    IS_EXCLUSIVE --Only_With V a b cc
##      Returns TRUE only if -V is not used or, if used once, can only be used
##      with -a -b or --cc.
##    IS_EXCLUSIVE --Not_With V a b cc
##      Returns TRUE only if -V is not used or, if used once, cannot be used
##      with -a -b or --cc.
##    IS_EXCLUSIVE --Paired_With V a b cc
##      Returns TRUE only if -V is used and one of -a -b or --cc is also used.
##    IS_EXCLUSIVE --Paired_With=2 V a b cc
##      Returns TRUE only if -V is used and any two of -a -b or --cc is also used.
##   Note: This function assumes the script arguments have been parsed by the
##      function GET_ARGS above.
function IS_EXCLUSIVE() {
  local ALL_OF ARG1 ARGS AT_LEAST CHECK_IT_OUT DASH DEFAULT NOT_WITH ONE_OF ONLY_ONE OPTS OPTS_ALL PAIRED_WITH
  local EXCLUSIVE_ARRAY EXCLUSIVE_ARRAY_COUNT EXCLUSIVE_COUNT EXCLUSIVE_COUNTS EXCLUSIVE_OPTIONS EXECUTE_ME
  [[ ${1^^} == --STRICT ]] && { STRICT="1" ; shift 1 ; }
  [[ ${*^^} =~ --STRICT ]] && _USAGE_CHOICE_ "IS_EXCLUSIVE: If used, option --Strict must be the first argument."
  [[ ${*} =~ --.*-- ]] && _USAGE_CHOICE_ "IS_EXCLUSIVE: Only one (or none) of the following can be used:\n    --Default  --Only_One  --Just_One  --One_Of  --All_Of  --At_Least  --Only_With  --Not_With  --Paired_With"
  ARGS="$@"
  while (( $# > 0 )) ; do
    ARG1="$1"
    case "${1^^}" in
      --ONLY_ONE) ONLY_ONE="1" ; shift 1 ;;
        --ONE_OF)   ONE_OF="1" ; shift 1 ;;
        --ALL_OF)   ALL_OF="1" ; shift 1 ;;
      --AT_LEAST) AT_LEAST="1" ; shift 1 ;;
      --JUST_ONE) shift 1
                  OPTS_ALL=( ${Opts_All} )		# make an array so easy to count
                  (( ${#OPTS_ALL[*]} < 2 )) && return	# Zero or one option used so don't have to check
                  for OPTS in $* ; do
                    (( ${#OPTS} > 1 )) && DASH="--" || DASH="-"
                    if [[ " ${Opts_All} " =~ " ${DASH}${OPTS} " ]] ; then
                      _USAGE_CHOICE_ "IS_EXCLUSIVE: No other option can be used with option ${DASH}${OPTS}."
                    fi
                  done
                  return
                  ;;
      --NOT_WITH|--PAIRED_WITH*|--DEFAULT)
                  case "${1^^}" in
                    --DEFAULT)
                        (( ${#2} == 1 )) && Dash="-" || Dash="--"
                        [[ ${_ALL_OPTIONS_} =~ \ $2\  ]] || _USAGE_CHOICE_ "For the command 'IS_EXCLUSIVE ${ARGS}' the option '${Dash}$2' has not been defined."
                        DEFAULT="$2"
                        ;;
                    --NOT_WITH)
                        NOT_WITH="1" ;;
                    --PAIRED_WITH*)
                        PAIRED_COUNT="${1##=}"
                        PAIRED_COUNT="${PAIRED_COUNT-:1}"
                        PAIRED_WITH="1" ;;
                  esac
                  ;&							# Continue with the next 'list' with no test
      --ONLY_WITH) shift 1
                  eval ONE_OF=\"\${Opt_${1//-/_}}\"			# If ONE_OF (the test option name with '-' converted to '_') > 0 ==> it was used
                  (( ${#1} == 1 )) && ONLY_ONE="-$1" || ONLY_ONE="--$1"	# For reporting
                  (( ! ONE_OF && ${#DEFAULT} == 0 )) && return 0	# Option not used so return
                  shift 1
                  local Comma=" " Dash
                  while (( $# != 0 )) ; do
                    (( ${#1} == 1 )) && Dash="-" || Dash="--"
                    OPTS+="${Comma}${Dash}${1}"				# For reporting
                    [[ ${_ALL_OPTIONS_} =~ \ $1\  ]] || _USAGE_CHOICE_ "For the command 'IS_EXCLUSIVE ${ARGS}' the option '${Dash}$1' has not been defined."
                    #[[ ${Opts_All}\ ${DEFAULT} =~ \ ${Dash}$1\  ]] || _USAGE_CHOICE_ "For the command 'IS_EXCLUSIVE ${ARGS}' the option '${Dash}$1' has not been defined."
                    Comma=", "
                    eval ONE_OF=\$\(\( ONE_OF + Opt_${1//-/_} \)\)	# Add any occurance of the remaining options (with '-' converted to '_')
                    shift 1
                  done
                  if [[ -n ${DEFAULT} ]] ; then
                    if (( ! ONE_OF )) ; then
                      eval Opt_${DEFAULT//-/_}=1
                      Opts_All+=" ${ONLY_ONE} "
                    fi
                    return 0
                  elif (( JUST_ONE )) ; then
                    [[ ${ONE_OF}  ]] && _USAGE_CHOICE_ "IS_EXCLUSIVE: No other options can be used with option ${ONLY_ONE}."
                  elif (( PAIRED_WITH )) ; then
                    (( ONE_OF != ( 1 + PAIRED_COUNT ) )) && _USAGE_CHOICE_ "IS_EXCLUSIVE: Option ${ONLY_ONE} must be paired with exactly ${PAIRED_COUNT} of option(s) ${OPTS}."
                  elif (( NOT_WITH )) ; then
                    (( ONE_OF > 1 )) && _USAGE_CHOICE_ "IS_EXCLUSIVE: Option ${ONLY_ONE} cannot be used with option(s)${OPTS}."
                  else					# Must be --Only_With
                    (( ONE_OF == 1 )) && _USAGE_CHOICE_ "IS_EXCLUSIVE: Option ${ONLY_ONE} can only be used with option(s)${OPTS}."
                  fi
                  return 1
                  ;;
               *) OPTS+="${ARG1} " ; shift 1 ;;
    esac
  done
  CHECK_IT_OUT="$(( ONLY_ONE + JUST_ONE + ONE_OF + ALL_OF + AT_LEAST + MUST_WITH + NOT_WITH + ONLY_WITH + DEFAULT ))"
  (( ! CHECK_IT_OUT )) && ONLY_ONE="1"		# The default
  OPTS=" ${OPTS// --/ }"
  EXECUTE_ME=$( gawk --assign Var="${OPTS// -/ }" '
    BEGIN {
      ArrayNum=split(Var, Array, " ")
      FormatCounts = "0${Opt_%s} + "
      FormatArray = "${Opt_%s} "
      ExclusiveCounts = "EXCLUSIVE_COUNTS=\" "
      ExclusiveArray = "EXCLUSIVE_ARRAY=\" "
      ExclusiveOptions = "EXCLUSIVE_OPTIONS=\"( "
      for(Idx=1 ; Idx<=ArrayNum ; Idx++) {
        VariableName = gensub(/-/,"_","g",Array[Idx])
        ExclusiveCounts = ExclusiveCounts sprintf(FormatCounts, VariableName)
        ExclusiveArray = ExclusiveArray sprintf(FormatArray, VariableName)
        (length(Array[Idx]) == 1) ? FormatOptions = "-%s " : FormatOptions = "--%s "
        ExclusiveOptions = ExclusiveOptions sprintf(FormatOptions, Array[Idx])
      }
      printf "%s0 \" ; %s \" ; %s)\" ; EXCLUSIVE_IDX=%d", ExclusiveCounts, ExclusiveArray, ExclusiveOptions, Idx -1
    }	# End of BEGIN
'
              )
  eval ${EXECUTE_ME}
  if (( STRICT )) ; then
    eval EXCLUSIVE_COUNT="\$(( EXCLUSIVE_COUNTS ))"
  else
    EXCLUSIVE_COUNT=( ${EXCLUSIVE_ARRAY} )
    EXCLUSIVE_COUNT="${#EXCLUSIVE_COUNT[*]}"
  fi
  eval EXCLUSIVE_ARRAY=\(${EXCLUSIVE_ARRAY}\)
  (( ONLY_ONE )) && (( EXCLUSIVE_COUNT  > 1 )) && _USAGE_CHOICE_ "Invalid combination of options.\nOptions ${EXCLUSIVE_OPTIONS} are mutually exclusive or used more than once."
  [[ -n ${ONE_OF}   ]] && (( EXCLUSIVE_COUNT != 1 )) && _USAGE_CHOICE_ "Required option error.\nOne of ${EXCLUSIVE_OPTIONS} must be specified."
  (( AT_LEAST )) && (( EXCLUSIVE_COUNT  < 1 )) && _USAGE_CHOICE_ "Required option missing.\nAt least one of ${EXCLUSIVE_OPTIONS} must be specified."
  if (( ALL_OF )) ; then
    (( ${#EXCLUSIVE_ARRAY[*]} != EXCLUSIVE_IDX && ${#EXCLUSIVE_ARRAY[*]} != 0 )) && \
       _USAGE_CHOICE_ "Required options missing.\nAll (or none) of ${EXCLUSIVE_OPTIONS} must be specified."
  fi
  (( EXCLUSIVE_COUNT !=0 &&  EXCLUSIVE_COUNT > 1 )) && _USAGE_CHOICE_ "Invalid combination of options.\nOptions ${EXCLUSIVE_OPTIONS} are mutually exclusive."
}

##________________________________________________________________________________
##
## IS_HEX - Returns 0 (true) if HEXNUM is valid; otherwise 1 (false).
##   Usage: IS_HEX HEXNUM
##     A vallid HEXNUM can be in many of the acceptable HEX representations.
##        1111, 0x1111, #1111, %1111, \\x1111, $#x1111
function IS_HEX() {
  [[ ${1,,} =~ ^(0x|#|%|\\x|&#x)*[a-f0-9]+$ ]]
  return $?
}

##________________________________________________________________________________
##
## IS_IP_ALIVE - Analyzes all IP_ARG... (domain names or IP addresses) to
##     determine if any is active.
##   Usage:   IS_IP_ALIVE [ -V VAR ] IP_ARG...
##     If an active IP address is found it is stored in the variable VAR
##       (if -V is used) and a return 0 is executed.
##     Otherwise,if -V is used VAR is set to "" then a message is stored in
##       $_ERROR_MESSAGE_ and return 1.
function IS_IP_ALIVE() {
  local IP LINE IP_MSG IP_MSG_SEP PLURAL QUIET VAR WORD1 WORD2
  unset _ERROR_MESSAGE_
  [[ $1 == -V ]] && { VAR="$2"  ; shift 2 ; }
  [[ -n ${VAR} ]] && eval unset ${VAR}			# Default value if no IP was found to be alive.
  if (( $# == 0 )) ; then
    _ERROR_MESSAGE_="No IP addresses or domain names specified.\nUSAGE: IS_IP_ALIVE [ -V VAR ] IP..."
    return 1
  fi
  while read -u 3 WORD1 WORD2 WORD3 REST ; do
    case "${WORD1}${WORD2}${WORD3}" in
      Nmapscanreport)
        if [[ ${REST} =~ \( ]]
          then IP="${REST#*\(}"
               IP="${IP%)*}"
          else IP="${REST##for }"
        fi
        ;;
      Hostisup*)
        if [[ -n ${IP} ]] ; then
          [[ -n ${VAR} ]] && eval ${VAR}+=\( \"${IP}\" \)
          return 0					# Return the first IP found to be alive.
        fi
        ;;
      Failedto) : ;;
    esac
  done 3< <( nmap --max-retries 2 -T4 -sn "$@" 2>/dev/null )
  # All IPs dead so generate a message.
  (( $# > 1 )) && PLURAL="s"
  for PC in "$@" ; do
    if IS_NUMERIC "${PC:0:1}" ; then
      IP_MSG="${IP_MSG}${IP_MSG_SEP}${PC}"
    else
      GET_IP_FROM_DOMAIN -Q -V PC_IP "${PC}"
      IP_MSG="${IP_MSG}${IP_MSG_SEP}${PC} (${PC_IP})"
    fi
    IP_MSG_SEP=", "
  done
  _ERROR_MESSAGE_="Cannot contact PC IP${PLURAL}: ${IP_MSG}"
  return 1
}

##________________________________________________________________________________
##
## IS_LOGICAL_VOLUNE - Returns TRUE if $1 is a logical volume, otherwise
##   returns false.
function IS_LOGICAL_VOLUME() {
  local STATUS DEVICE REST LVM WHAT
  WHAT="$( realpath --canonicalize-missing ${1} )"	# convert to an absolute pathname by following links
  while read -u 3 STATUS DEVICE REST ; do
    LVM="$( eval realpath --canonicalize-missing ${DEVICE} )"
    [[ ${WHAT} == ${LVM} ]] && return 0
  done
  return 1
} 3< <( lvscan 2>/dev/null )

##________________________________________________________________________________
##
## IS_MAC - Returns 0 (true) if MACADR is valid; otherwise 1 (false).
##   Usage: IS_MAC  MACADDR
##     MACADDR is a mac address'
function IS_MAC() {
  [[ ${1,,} =~ ^([a-f0-9]{2}:){5}[a-f0-9]{2}$ ]]
  return $?
}

##________________________________________________________________________________
##
## IS_NUMERIC - Returns 0 (true) if $1 is numeric; otherwise returns 1 (false).
##   Integers, positive and negative numbers, floating point numbers, and
##     exponents (12.3e45) are detected.
##   If $1 is -A (absolute) then $2 cannot have either a '+' or a '-' sign.
function IS_NUMERIC() {
  if [[ $1 == -A ]] ; then
    [[ $2 =~ ^[0-9]*\.?[0-9]*([eE]?[0-9]+)?$ ]]
  else
    [[ $1 =~ ^[+-]?[0-9]*\.?[0-9]*([eE]?[0-9]+)?$ ]]
  fi
  return $?
}

##________________________________________________________________________________
##
## IS-ROOT - Returns TRUE (0) if the EUID is "root"; otherwise FALSE (1).
function IS_ROOT() {
  (( EUID )) && return 1 || return 0
}

##________________________________________________________________________________
##
## IS_TESTING - Returns TRUE if TESTing is enabled.
function IS_TESTING() {
  (( TESTING ))
  return $?
}

##________________________________________________________________________________
##
## IS_UUID - Returns 0 (true) if UUID is valid; otherwise returns 1 (false).
##   Usage: IS_UUID UUID
##   A valid UUID has the accepted format: XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
function IS_UUID() {
  [[ ${1,,} =~ ^[a-f0-9-]+$ ]] \
    && [[ ${2} =~ ^........-....-....-....-............$ ]]
  return $?
}

##________________________________________________________________________________
##
## MODIFY_GTK_FONT - Set or reset the default font setting for GTK-based
##      applications.
##   Usage: MODIFY_GTK_FONT {-s | -r} -f FONT [ -v VER ]
##   Where:
##    -F FONT  Specify the font (in gtk format == no quotes)
##    -R       Remove the line identified by FONT.
##    -S       Append a font directive (e.g. "gtk-font-name=Monospace 14") onto
##               ~/.config/gtk-VER/settings.ini to set the font to FONT.
##             If neither -S or -R is specified, -S "Monospace 14" is assumed.
##    -V VER   The gtk version of the settings.ini file to change. The default
##             is "3.0". I.E. "~/.config/gtk-3.0/settings.ini".
function MODIFY_GTK_FONT () {
  local GTK_DIR GTK_FILE GTK_FONT_DIRECTIVE GTK_TMP_FILE GTK_VER
  local DEFAULT_GTK_VER="3.0"
  local DEFAULT_GTK_FILE="settings.ini"
  local DEFAULT_GTK_FONT="Monospace 14"
  local DEFAULT_GTK_COMMENT="# GTKGTK "
  unset _ERROR_MESSAGE_
  while (( $# > 0 )) ; do
    case $1 in
      -F) GTK_FONT="$2"
          shift 2
          ;;
      -R) RESET="1"
          shift 1
          ;;
      -S) unset RESET
          shift 1
          ;;
      -V) GTK_VER="$2"
          shift 2
          ;;
    esac
  done
  GTK_VER="${GTK_VER:-${DEFAULT_GTK_VER}}"
  GTK_DIR=~/.config/gtk-${GTK_VER}
  [[ -d ${GTK_DIR} ]] || ERROR "MODIFY_GTK_FONT: GTK version \"${GTK_VER}\" is incorrect or directory \"${GTK_DIR}\" doesn't exist."
  GTK_FILE="${GTK_DIR}/${DEFAULT_GTK_FILE}"
  GTK_FONT="${GTK_FONT:-${DEFAULT_GTK_FONT}}"
  GTK_FONT_DIRECTIVE="gtk-font-name=${GTK_FONT}"

  [[ -f "${GTK_FILE}" ]] || echo -e "[Settings]\n" >"${GTK_FILE}"	# In case no settings.ini file exists
  TMP_FILE_CREATE GTK_TMP_FILE
  sed -e "/${DEFAULT_GTK_COMMENT}/,+1d" "${GTK_FILE}" >"${GTK_TMP_FILE}"
  cat "${GTK_TMP_FILE}" >"${GTK_FILE}"
  (( RESET > 0 )) && return
  echo -e "${DEFAULT_GTK_COMMENT}${GTK_FONT_DIRECTIVE}\n${GTK_FONT_DIRECTIVE}" >>"${GTK_FILE}"
}

##________________________________________________________________________________
##
## MOUNT_IT - Mount the filesystem $1 onto directory $2 and remember where it
##     was mounted.
##   Usage: MOUNT_IT FILESYSTEM [ WHERE ] [ MOUNT_OPTIONS]
##   Where:
##     FILESYSTEM can be a device special file (/dev/...), an NFS mount
##       (aa.bb.cc:/PATH) or a UUID ( UUID=...)
##     WHERE is the pathname of mount point. It must be a directory that exists.
##       If both FILESYSTEM and WHERE are present they are used as is.
##       If WHERE is not present or if $2 begins with a '-', then FILESYSTEM
##         is assumed to be a device or directory in /etc/fstab. So a search
##         is made in /etc/fstab for mounting information.
##       If directory $1 is not found then a recursive  search of the parent
##         directory is made until a matching directory is found or the root
##         directory is reached.
##     MOUNT_OPTIONS are any options acceptable to the mount command.

unset _MOUNTED_FS_ARRAY_ ; declare -a _MOUNTED_FS_ARRAY_
_MOUNTED_FS_ARRAY_IDX_="0"

function MOUNT_IT() {
  local IS_LV SUDO NFS_SERVER NFS_WHAT_CANON TEST_WHAT_CANON WHAT_CANON WHAT_FS WHAT_ORIG WHERE_CANON WHERE_FS WHERE_ORIG
  IS_ROOT || SUDO="sudo"
  if [[ $# == 1 || ${2:0:1} == - ]]			# $1 alone or with MOUNT_OPTIONS
    then _MOUNT_IT_FIND_IN_FSTAB_ "$1"			# Set the values for WHAT and WHERE: XXX_ORIG, XXX_CANON, XXX_FS
         shift 1					# Remaining args are MOUNT_OPTIONS
    else WHAT_ORIG="$1"
         WHAT_CANON="$1"
         WHAT_FS="$1"
         WHERE_ORIG="$2"
         WHERE_CANON="$2"
         WHERE_FS="$2"
         shift 2					# Remaining args are MOUNT_OPTIONS
  fi
  [[ -d ${WHERE_CANON} ]] || _USAGE_CHOICE_ "MOUNT_IT: Mount point '${WHERE_CANON}' does not exist."
  if (( ! NFS )) && [[ ! ${WHAT_CANON} =~ : ]] ; then
    [[ -b ${WHAT_CANON} ]]  || _USAGE_CHOICE_ "MOUNT_IT: Filesystem \"${WHAT_CANON}\" doesn't exist or is not a block device."
    TEST_WHAT_CANON="${WHAT_CANON}"
  else
    TEST_WHAT_CANON=":${NFS_WHAT_CANON}"
  fi
  if mount | grep -q "${TEST_WHAT_CANON}.*${WHERE_CANON}" ; then
    echo -e "Note: '${WHAT_CANON}' is already mounted onto '$WHERE_CANON'. It will be used as-is."
  else
    if IS_LOGICAL_VOLUME "${WHAT_CANON}"
      then IS_LV="YES"
           ${SUDO} lvchange -ay "${WHAT_CANON}"
      else IS_LV="NO"
    fi
    ${TEST_CMD} eval ${SUDO} mount "$@" "${WHAT_CANON}" "${WHERE_CANON}" ${TEST_FALSE} _USAGE_CHOICE_ "MOUNT_IT: Error mounting '$1' onto '$2'."
  fi
  # Remember where it was mounted and whether it is a logical volume
  _MOUNTED_FS_ARRAY_[_MOUNTED_FS_ARRAY_IDX_++]="${WHAT_CANON} ${WHERE_CANON} ${WHAT_FS} ${WHERE_FS} ${WHAT_ORIG} ${WHERE_ORIG} ${IS_LV}"
}

# INTERNAL FUNCTION - Called by MOUNT_IT
# In column 2 of /etc/fstab, look for the directory '$1' or (recursively) for the parent.
function _MOUNT_IT_FIND_IN_FSTAB_() {
  local ERROR_CODE=0 ERROR_TRESHOLD=0 NFS=0 NUM_PATTERN="[0-9]*"
  unset WHAT_CANON
  set -o pipefail
  case "$1" in
    UUID=*)						# Identify device by UUID ==> UUID="..."
      WHAT_CANON="$( lsblk --noheadings --output UUID ${1} )" ; ERROR_CODE="$?"
      ;&						# Continue to next pattern
    *:/*)						# Identify device by NFS address ==> system:/path
      if [[ -z ${WHAT_CANON} ]] ; then
        WHAT_CANON="$1"
        NFS_WHAT_CANON="${1##*:}"
        NFS_SERVER="${1%%:*}"
        What_CANON="$( GET_MATCHING_NFS_DOMAIN_IN_FSTAB ${NFS_SERVER} ):${NFS_WHAT_CANON}"
        (( ERROR_CODE <= ERROR_TRESHOLD )) && { FSTAB_LINE=( $( grep -E --max-count 1 "^${WHAT_CANON}\s" /etc/fstab ) ) ; ERROR_CODE="$?" ; }
        if (( ERROR_CODE <= ERROR_TRESHOLD )) ; then
          NFS="1"
          WHERE_FS="${WHERE_FS[1]}"			# Get the 2nd column
          WHERE_ORIG="${WHERE_FS}"
          WHERE_CANON="${WHERE_FS}"
        fi
      fi
      ;&						# Continue to next pattern
    /dev/*)						# Identify device by special device name ==> /dev/...
      WHAT_ORIG="$1"
      [[ -z ${WHAT_CANON} ]] && WHAT_CANON="$1"
      (( ERROR_CODE <= ERROR_TRESHOLD && ! NFS )) && { WHAT_CANON="$( realpath --canonicalize-missing "${WHAT_CANON}" )" ; ERROR_CODE="$?" ; }
      (( ERROR_CODE <= ERROR_TRESHOLD )) && { FSTAB_LINE=( $( grep -E --max-count 1 "^${1}\s" /etc/fstab ) ) ; ERROR_CODE="$?" ; }
      if (( ERROR_CODE <= ERROR_TRESHOLD )) ; then
        WHAT_FS="${FSTAB_LINE[0]}"			# Get the 1st column
        WHERE_FS="${WHERE_FS[1]}"			# Get the 2nd column
        WHERE_ORIG="${WHERE_FS}"
        WHERE_CANON="${WHERE_FS}"
      fi
      ;;
    *)							# Must be a mount-point pathname
      WHERE_ORIG="$1"
      WHERE_CANON="$( realpath --canonicalize-missing "$1" )" ; ERROR_CODE="$?"
      if (( ERROR_CODE <= ERROR_TRESHOLD )) ; then
        while : ; do
          if (( ERROR_CODE <= ERROR_TRESHOLD )) ; then
            FSTAB_LINE=( $( grep -E --max-count 1 "\s${WHERE_CANON}${NUM_PATTERN}\s" /etc/fstab ) )
            ERROR_CODE="$?"
          fi
          if (( ERROR_CODE <= ERROR_TRESHOLD )) ; then
            WHERE_FS="${FSTAB_LINE[1]}"			# Prepare to get the 2nd column
            WHAT_FS="${FSTAB_LINE[0]}"			# Get the 1st column
            WHAT_ORIG="${WHAT_FS}"
            WHAT_CANON="${WHAT_FS}"
            break
          else
            WHERE_CANON="$(dirname "${WHERE_CANON}")"
            [[ $WHERE_CANON == / ]] && break
          fi
          ERROR_CODE=0
        done
      fi
      ;;
  esac
  set +o pipefail
  (( ERROR_CODE <= ERROR_TRESHOLD )) && return 0
  _USAGE_CHOICE_ "_MOUNT_IT_FIND_IN_FSTAB: Cannot find filesystem in column two of /etc/fstab for filesystem \"$1\"."
}

##________________________________________________________________________________
##
## UMOUNT_IT - Un-mount the filesystems/devices ($*) mounted by MOUNT_IT.
##   Usage: UMOUNT_IT [ -A | --ALL | FS_OR_DEVICE... ]
##     If $1 == -A or --ALL then umount all remembered mounts in reverse order
##       of mounting.
##     If $1 is missing the last entry in _MOUNTED_FS_ARRAY_ is un-mounted.
##       Otherwise search the "mounted" array for  FS_OR_DEVICE.
function UMOUNT_IT() {
  local FS_ARRAY FS_ARRAY_IDX FS_ARRAY_IDX_LAST FS IDX _MOUNTED_FS_ARRAY_IDX_ IS_LVM SUDO
  IS_ROOT || SUDO="sudo"
  [[ $1 == -A || $1 == --ALL ]] && set -- $( REVERSE_ARGS "${!_MOUNTED_FS_ARRAY_[@]}" )
  if (( $# == 0 )) & then
    set -- ${!_MOUNTED_FS_ARRAY_[@]}
    (( $# > 0 )) && shift $((${#_MOUNTED_FS_ARRAY_[@]} - 1))
  fi
  while (( $# > 0 )) ; do				# Each entry in "_MOUNTED_FS_ARRAY_" contains WHAT, WHERE and LVM information (space separated)
    for _MOUNTED_FS_ARRAY_IDX_ in ${!_MOUNTED_FS_ARRAY_[*]} ; do
      [[ -z ${_MOUNTED_FS_ARRAY_[${_MOUNTED_FS_ARRAY_IDX_}]} ]] && break 2	# Empty entry ==> END
      FS_ARRAY=( ${_MOUNTED_FS_ARRAY_[${_MOUNTED_FS_ARRAY_IDX_}]} )		# Get the info as an array
      FS_ARRAY_IDX_LAST="$(( ${#FS_ARRAY[*]} - 1 ))"	# Caculate the index of the last entry
      IS_LVM=${FS_ARRAY[${FS_ARRAY_IDX_LAST}]}		# Remember the last entry
      unset FS_ARRAY[${FS_ARRAY_IDX_LAST}]		# Do not want the last entry any more
      if IS_NUMERIC "$1" ; then
        FS=${FS_ARRAY[0]}				# Assume the first one is the best to use
        break
      else
        for FS_ARRAY_IDX in $( echo -n ${!FS_ARRAY[*]} ) ; do	# Have to look for the right saved entry
          [[ $1 == ${FS_ARRAY[${FS_ARRAY_IDX}]} ]] && { FS="${1}" ; break 2 ; }
        done
        continue					# Not found. Look for the next one
      fi
    done
    [[ -z $FS ]] && _USAGE_CHOICE_ "UMOUNT_IT: Cannot find the device/filesystem entry \"$1\" in _MOUNTED_FS_ARRAY_."
    ${TEST_CMD} eval ${SUDO} umount ${FS} ${TEST_FALSE} _USAGE_CHOICE_ "UMOUNT_IT: Error while un-mounting \"$1\"."
    [[ ${IS_LVM} == YES ]] && ${TEST_CMD} ${SUDO} lvchange -an ${FS_ARRAY[${IDX}]}	# if an LV then de-activate it
    ${TEST_CMD} unset _MOUNTED_FS_ARRAY_[${_MOUNTED_FS_ARRAY_IDX_}]			# Remove this element from the list
    shift 1
  done
}

##________________________________________________________________________________
##
## PAD_IT - Returns a string padded to a specific LENGTH with PAD.
##   Usage: PAD_IT [ -R ] [ -T ] STRING [ LENGTH [ PAD ] ]
##   Where:
##     LENGTH Is the length of the output string. The default LENGTH is 8.
##        PAD Is a string of 1 or more characters used to pad STRING to
##            length LENGTH. The default PAD is a space " ".
##         -R Right justified. Place the padding before STRING. The default
##            is to pad after STRING.
##         -T Truncate overlength STRING on the left if -R otherwsise truncate
##            on the right.
##         -V VAR Store the result in variable VAR rather than displaying
##            the result.
function PAD_IT() {
  local RightJust Truncate Var
  while (( $# > 0 )) ; do
    case "$1" in
      -R) RightJust="1" ; shift 1 ;;
      -T) Truncate="1"  ; shift 1 ;;
      -V) Var="${2}"    ; shift 2 ;;
       *) break ;;
    esac
  done
  local Count LenResult="${2:-8}" LenStr="${#1}" Padding PadStr="${3:- }"
  if (( LenStr > LenResult )) ; then			# Too long already
    if (( Truncate == 1 )) ; then
      (( RightJust == 1 )) && Result="${1:LenStr-LenResult}" || Result="${1:0:LenResult}"
    else
      Result="${1}"
    fi
  else
    Count=$(( ( ( LenResult - LenStr ) / ${#PadStr} ) + 2 ))
    Padding="$( eval "printf '${PadStr}%.0s' {1..${Count}}" )"
    if (( RightJust == 1 )) ; then
      Result="${Padding}${1}"
      Result="${Result:${#Result}-LenResult}"
    else
      Result="${1}${Padding}"
      Result="${Result:0:${LenResult}}"
    fi
  fi
  [[ -n ${VAR} ]] && eval ${VAR}=\"${Result}\" || echo -n "${Result}"
}

##________________________________________________________________________________
##
## PAUSE - A simple function that waits for a carriage return or 'q' to quit.
##   Usage: PAUSE [ARGS}
##   Where: ARGS, if present, will be displayed before the prompt.
##          They may contain escape characters.
function PAUSE() {
  local ANSWER
  # Display the ARGS this way as the prompt for 'read' does not recognize excape sequences.
  echo -en "${@}Press ENTER to continue (or q to quit): "
  read ANSWER
  [[ ${ANSWER} == "q" ]] && exit
}

##________________________________________________________________________________
##
## PROGRESS - Displays a "." every INTERVAL times it is called.
##   Usage: (To set the parameters):
##     PROGRESS [ INTERVAL [ EXPECTEDCALLS [ MAXDOTS ]]]
##   Usage: (While inside a loop):
##     PROGRESS
##   Where: (all args must be a positive integer):
##     INTERVAL      Set the progress interval (default = 1). A "." will be
##                   displayed every INTERVAL times PROGRESS is called.
##     EXPECTEDCALLS Number of times PROGRESS is expected to be called by the
##                   script (default = 0).
##     MAXDOTS       The maximun number of "." to be displayed (default = 100).
##   To change the INTERVAL default, PROGRESS can be called (with arguments)
##     once outside a loop.
##   Within a loop PROGRESS (without arguments) displys "." every INTERVAL time.
##   The arguments INTERVAL, EXPECTEDCALLS and MAXDOTS can be used to
##     recalculate a reasonable INTERVAL to limit the total number of "."
##     displayed. The calculations are:
##       1)   Set: INTERVAL = abs(EXPECTEDCALLS - INTERVAL)
##       2) While: INTERVAL > MAXDOTS ; Set: INTERVAL = INTERVAL/2
##       3)   Set: INTERVAL to upper half of MAXDOTS
##          Where: MAXDOTS/2 <= INTERVAL <= MAXDOTS
function PROGRESS() {
  local RESULT _PROGRESS_CALLS_
  unset _ERROR_MESSAGE_
  if (( $# > 0 )) ; then				# Recalculate INTERVAL if arguments are present
    [[ 0$1$2$3 =~ - ]] && $((RESULT++))			# No negative numbers
    IS_NUMERIC "0$1$2$3" ]] || $((RESULT++))		# All args must be numeric
    (( RESULT > 0 )) && ERROR "PROGRESS: All arguments - $1 $2 $3 - must be positive integers."
    _PROGRESS_COUNTER_="-1"				# Set  to -1 so first dot will not display
    _PROGRESS_INTERVAL_="${1:-1}"			# Get the interval (or set to the default)
    _PROGRESS_CALLS_="${2:-0}"				# Get the expected number of calls (or set to the default)
    _PROGRESS_MAX_="${3:-100}"				# Get the maximum number of dots (or set to the default)
    _PROGRESS_INTERVAL_="$(( _PROGRESS_CALLS_ - _PROGRESS_INTERVAL_ ))"
    _PROGRESS_INTERVAL_="${_PROGRESS_INTERVAL_//-/}"	# Ensure it is a positive number
    while (( _PROGRESS_INTERVAL_ > _PROGRESS_MAX_ )) ; do
      _PROGRESS_INTERVAL_=$((_PROGRESS_INTERVAL_/2))	# Anything under _PROGRESS_MAX_ dots (default=100) is AOK
    done
    # Ensure the _PROGRESS_INTERVAL_ is always greater than _PROGRESS_MAX_/2
    (( _PROGRESS_INTERVAL_ * 2 < _PROGRESS_MAX_ )) && _PROGRESS_INTERVAL_=$(( _PROGRESS_INTERVAL_ + (_PROGRESS_MAX_ / 2) ))
  fi
  (( $((++_PROGRESS_COUNTER_)) < ${_PROGRESS_INTERVAL_} )) && return
  echo -n "."
  _PROGRESS_COUNTER_="0"
}

##________________________________________________________________________________
##
## REVERSE_ARGS - Display the arguments in reverse order.
function REVERSE_ARGS() {
  local ARG REV_ARG
  for ARG in "${@}" ; do
    REV_ARG=("${ARG}" "${REV_ARG[@]}")
  done
  echo "${REV_ARG[@]}"
}

##________________________________________________________________________________
##
## SORT_ARGS - Sort the arguments to this function and display the sorted result.
##             No argument can have whitepace.
##   Usage: SORT_ARGS [ -S "SORTOPTIONS" ] ARGS...
##   Where: SORTOPTIONS are any options allowed by the sort command
##                 ARGS are the valuse to be sorted
##   EXAMPLE:
##     Sort AN_ARRAY on the numeric digits following a '-'
##   AN_ARRAY=(file-1 file-10 file-11 file-2 file-20 file-3 file-30)
##   SORTED_ARRAY=( $( SORT_ARGS -S "-n -t- -k 2,2" ${AN_ARRAY[*]} ) )
##   echo "${SORTED_ARRAY[@]}"
##     file-1 file-2 file-3 file-10 file-11 file-20 file-30
function SORT_ARGS() {
  local SORT_OPTIONS
  [[ $1 == -S ]] && { SORT_OPTIONS=$2 ; shift 2 ; }
  ( set -f ; IFS=$'\n ' ; sort ${SORT_OPTIONS} <<<"${*}" )	# So "${*}" expands with each argument on a new line
}

##________________________________________________________________________________
##
## SORT_ARGS_WS - Sort the arguments and display the results.
##                Arguments can have whitepace.
##   Usage: SORT_ARGS_WS [ -S "SORTOPTIONS" ] ARGS...
##   Where: SORTOPTIONS are any options allowed by the sort command.
##   Notes: This function is the same as SORT_ARGS but is slower in execution.
##          Each ARGi must be quoted
##   EXAMPLE:
##     Sort AN_ARRAY on the numeric digits following a '-'
##   AN_ARRAY=( "f ile-1" "fil e-10" "fi le-11 x" file-2 file-20 file-3 file-30 )
##   SORTED_ARRAY=( $(SORT_ARGS_WS -S "-n -t- -k 2,2" "${AN_ARRAY[@]}" ) )
##   echo ${SORTED_ARRAY[*]}
##     'f ile-1' 'file-2' 'file-3' 'fil e-10' 'fi le-11 x' 'file-20' 'file-30'
function SORT_ARGS_WS() {
  local I SORT_OPTIONS
  [[ $1 == -S ]] && { SORT_OPTIONS=$2 ; shift 2 ; }
  for (( I = 1 ; I <= $# ; I++ )) ; do
    #eval echo -e \"\${${I@Q}}\"
     eval echo -e "\${${I}@Q}"
  done | sort ${SORT_OPTIONS}
}

##________________________________________________________________________________
##
## ROOT_ONLY - Ensures only 'root' can run this script.
function ROOT_ONLY() {
  if ! IS_ROOT ; then
    _USAGE_CHOICE_ "You must be root to run this script."
    (( IS_USAGE_EXIT )) && exit 2 || return 2
  fi
}

##________________________________________________________________________________
##
## TEST_DISPLAY - Display the TESTing variable values.
##   Useful for determining what variables (nad their values) are available.
function TEST_DISPLAY() {
  set | grep "^TEST_.*="
}
##________________________________________________________________________________
##
## TEST_RESET - Reset the TESTing variables to the defaults and stop TESTing.
##
## The TEST_RESET function defines the TESTing variables shown by the
## TEST_DISPLAY command. To see all the TESTing variable assignments
##   execute the following:
##       source <PATH>/functions.sh ; TEST_DISPLAY
##   Use them to correctly display commands in a script whose TEST_SET is
##     on. Note: If any of the defined TESTing variables are used in a command
##     ine, that command line must start with: '${TEST_CMD} eval '.
##   NOTE: Any bash metacharacters must be escape'd.
##   The following are examples using the TESTing variables.
##     EXAMPLE:
##       Using the TESTing variables. Notice the required "eval" if any bash
##         operators are replaced in the command line.
##
##        ${TEST_CMD} eval CMD1 ${TEST_IN} FILE1 ${TEST_PIPE} CMD2 \
##          ${TEST_OUT}FILE2 ${TEST_ERR_OUT} ${TEST_TRUE} CMD_TRUE \
##          ${TEST_FALSE} CMD_FALSE ${TEST_BG}
##
##        If TESTing is off, will execute:
##    eval CMD1 < FILE1 | CMD2 >FILE2 2>&1 && CMD_TRUE || CMD_FALSE &
##       If TESTing is on,  will display:
#3   Testing: eval CMD1 < FILE1 | CMD2 >FILE2 2>&1 && CMD_TRUE || CMD_FALSE &
##
##     EXAMPLE: Using the TESTing metacharacters.
##        ${TEST_CMD} eval ${TEST_OPEN} CMD1 ${TEST_NL} CMD2 ${TEST_CLOSE}
##         If TESTing is off, will execute:          ( CMD1 ; CMD2 )
##         If TESTing is on,  will display: Testing: ( CMD1 ; CMD2 )
##     EXAMPLE: Using TESTing with no extra TESTing variables in a command
##              (no "eval" is needed).
##      ${TEST_CMD} rm -rf $1
##         If TESTing is off, will execute:          rm -rf $1
##         If TESTing is on,  will display: Testing: rm -rf $1
function TEST_RESET() {
  unset TESTING
  declare -gx  TEST_CMD=''
  declare -gx  TEST_TRUE='&&'   TEST_FALSE='||'  TEST_PIPE='|'          TEST_ERR_PIPE='|&'
  declare -gx  TEST_IN='<'      TEST_HERE='<<'   TEST_HERE_EOF='<<-EOF' TEST_HERE_STRING='<<<'
  declare -gx  TEST_OUT='>'     TEST_APPEND='>>' TEST_ERR='2>'          TEST_OUT_ERR='2>&1'    TEST_ERR_OUT='${TEST_OUT_ERR}' TEST_BOTH='>&'
  declare -gx  TEST_BG='&'      TEST_NL=';'      TEST_OPEN='('          TEST_CLOSE=')'         TEST_LIST1='{'                 TEST_LIST2=' ; }'
  declare -gx  TEST_EXPR1='(('  TEST_EXPR2='))'  TEST_EVAL1='[['        TEST_EVAL2=']]'
  declare -gx  TEST_CMD1='$('   TEST_CMD2=')'    TEST_CMD3='<('
  declare -gx  TEST_OUT_SINK='>/dev/null'        TEST_ERR_SINK='2>/dev/null'                   TEST_BOTH_SINK='>&/dev/null'
}

TEST_RESET						# The default is to NOT test

##________________________________________________________________________________
##
## TEST_SET - Turn on TESTing.
##   A script option of '-t' or '--test' will enable the display of TEST
##   commands rather than executing them.
function TEST_SET() {
  TESTING="1"
  TEST_CMD="echo -e '${RED}Testing:${BLK}' "
}

##________________________________________________________________________________
##
## TMP_FILE_CREATE - Create a temporary work file/directory that can be referenced
##     by TMP_NAME_VAR. Temporary files/directories created by this functiom will
##     be deleted by CLEANUP_SCRIPT upon exit from the calling script.
##   Usage:
##     TMP_FILE_CREATE [ --DIR ] [ -S SUFFIX ] { [ -D DIRPATH ] TMPnameVAR }...
##   Where:
##          --DIR Treat the names (TMPnameVAR) specified in the remaining
##                arguments as directory names. --DIR must be the first argument.
##      -S SUFFIX Optional suffix used to make TMP files unique. The default is
##                SUFFIX = $BASHPID. "-S $$" uses the script PID as a suffix.
##     -D DIRPATH Optional pathname of the directory where the TMP files are
##                created (the default is: /tmp). DIRPATH is created if it
##                doesn't exist. DIRPATH remains in effect for all subsequent
##                TMPnameVAR or until another "-d DIRPATH" is encountered.
##                  EXAMPLE:  cat ${TMPnameVAR}
##     TMPnameVAR The variable name used to reference the file/directory.
##   Returns 0 if TMP file created successfully otherwise returns 1.
##   Returns 2 if the temporary file or directory already exists.
##   If a temporary directory (TMPDIR) is created, all contents of TMPDIR are
##     deleted by CLEANUP_SCRIPT above.

unset _TMP_NAMES_ARRAY_
declare -Agx _TMP_NAMES_ARRAY_				# _TMP_NAMES_ARRAY_ must be declared outside of any function

function TMP_FILE_CREATE() {
  local _FILE_DIR_ _RETURN_=0 _SUFFIX_ _TMP_NAME_ _TMP_PATH_ _TMP_DIR_="/tmp"
  _SUFFIX_="$BASHPID"
  [[ $1 == --DIR ]] && { _FILE_DIR_="DIR" ; shift 1 ; } || _FILE_DIR_="FILE"
  while (( $# != 0 )) ; do
    case "$1" in
      -D) _TMP_DIR_="$( realpath $2 )"
          { [[ -d ${_TMP_DIR_} ]] || mkdir "${_TMP_DIR_}" ; } || _USAGE_CHOICE_ "TMP_FILE_CREATE: Directory \"$2\" cannot be created."
          shift 2
          ;;
      -S) _SUFFIX_="$2" ; shift 2
          ;;
       *) [[ $1 =~ ^[A-Za-z][A-Za-z0-9_]*$ ]] || _USAGE_CHOICE_ "TMP_FILE_CREATE: Parameter name \"$1\" is invalid."
          if [[ -n ${_TMP_NAMES_ARRAY_[$1]} ]] ; then
            _TMP_PATH_="${_TMP_NAMES_ARRAY_[$1]}"
            _TMP_NAME_="$( basename "${_TMP_PATH_}" )"
            _RETURN_="2"				#_USAGE_CHOICE_ "TMP_${_FILE_DIR_}_CREATE: TMP ${_FILE_DIR_,,} \"$1\" already exists."
          else
            _TMP_NAME_="${1}.${_FILE_DIR_}.${_SUFFIX_}"
            _TMP_PATH_="${_TMP_DIR_}/${_TMP_NAME_}"
          fi
          [[ -e ${_TMP_PATH_} ]] && _RETURN_="2"	#_USAGE_CHOICE_ "TMP_${_FILE_DIR_}_CREATE: TMP ${_FILE_DIR_,,} \"${_TMP_PATH_}\" already exists."
          if (( _RETURN_ != 2 )) ; then
            if [[ ${_FILE_DIR_} == FILE ]] ; then
              touch "${_TMP_PATH_}" || _USAGE_CHOICE_ "TMP_FILE_CREATE: The temporary file \"${_TMP_PATH_}\" cannot be created."
            else
              mkdir "${_TMP_PATH_}" || _USAGE_CHOICE_ "TMP_FILE_CREATE: The temporary directory \"${_TMP_PATH_}\" cannot be created."
            fi
          fi
          _TMP_NAMES_ARRAY_[$1]="${_TMP_PATH_}"		# Store the TMP path in the array using the variable name ($1) as the index
          declare -g -x $1				# Create $1 as a (global, exportable) reference (to the _TMP_NAMES_ARRAY_)
          eval export $1="${_TMP_NAMES_ARRAY_[$1]}"	# Create the reference ==> the variable named in $1 to the array element
          shift 1
          ;;
    esac
  done
  return ${_RETURN_}
}

##________________________________________________________________________________
##
## TMP_DIR_CREATE - Like TMP_FILE_CREATE but creates a temporary directory rather
##                  than a file.
function TMP_DIR_CREATE() {
  TMP_FILE_CREATE --DIR "$@"
}

##________________________________________________________________________________
##
## TMP_FILE_DELETE - Delete TMP files or dirs created by TMP_FILE_CREATE
##   Usage: TMP_FILE_DELETE [--DIR ] { -P PATTERN | -A | TMPfileVAR ... }
##   Where:
##          --DIR Treat the names (TMPfileVAR) specified in the remaining
##                arguments as directory names. --DIR must be the first argument.
##             -A Delete all known TMP files (or dirs) created.
##     -P PATTERN Delete all the TMP files (or dirs) matching PATTERN.
##     TMPfileVAR The Variable reference of the TMP file (or dir) to delete.
function TMP_FILE_DELETE() {
  local PATTERN _FILE_DIR_ _TMP_NAME_ _TMP_NAMES_
  PATTERN="$BASHPID"
  [[ $1 == --DIR ]] && { _FILE_DIR_="DIR" ; shift 1 ; } || _FILE_DIR_="FILE"
  unset PATTERN
  while (( $# != 0 )) ; do
    case "$1" in
      -A) _TMP_NAMES_="${!_TMP_NAMES_ARRAY_[*]}"	# Remove all the TMP files or dirs
          break
          ;;
      -P) PATTERN="$2"
          _TMP_NAMES_="${!_TMP_NAMES_ARRAY_[*]}"	# Remove TMP files or dirs matching PATTERN
          break
          ;;
       *) _TMP_NAMES_+="$1"				# Just delete the named TMP file/dir.
          shift 1
          ;;
    esac
  done
  for _TMP_NAME_ in ${_TMP_NAMES_} ; do
    [[ -n ${PATTERN} ]] && { [[ ${_TMP_NAME_} =~ ${PATTERN} ]] || continue ; }
    [[ ${_TMP_NAMES_ARRAY_[${_TMP_NAME_}]} =~ .${_FILE_DIR_}. ]] || continue	# Skip all files/dir names that don't match ${_FILE_DIR_}
    if [[ ${_FILE_DIR_} == FILE ]] ; then
      rm -f "${_TMP_NAMES_ARRAY_[${_TMP_NAME_}]}"	# &>/dev/null
    else
      rmdir "${_TMP_NAMES_ARRAY_[${_TMP_NAME_}]}"	# &>/dev/null
    fi
    unset _TMP_NAMES_ARRAY_[${_TMP_NAME_}]
    shift 1
  done
  (( ${#_TMP_NAMES_ARRAY_[*]} == 0 )) && unset _TMP_NAMES_ARRAY_
}

##________________________________________________________________________________
##
## TMP_DIR_DELETE - Like TMP_FILE_DELETE but deletes temporary directories
##                  instead of files.
function TMP_DIR_DELETE() {
  TMP_FILE_DELETE --DIR "$@"
}

##________________________________________________________________________________
##
## TMP_FILE_PERMANENT - Prevent CLEANUP from deleting the TMP file created by
##                      TMP_FILE_CREATE function
##   Usage: TMP_FILE_PERMANENT [--DIR ] TMPfileVAR [ NEWNAME ]
##   Where:
##          --DIR Treat the name (TMPfileVAR) as a directory name.
##     TMPfileVAR The Variable reference of the TMP file (or dir) to delete.
##        NEWNAME The TMP file/dir is renamed to the pathname NEWNAME.
function TMP_FILE_PERMANENT(){
  local Name="file" _TMP_NAME_
  [[ $1 == --DIR ]] && { Name="directory" ; shift 1 ; }	# Ignore it. It is only there for compatibility
  for _TMP_NAME_ in ${!_TMP_NAMES_ARRAY_[*]} ; do
    if [[ ${_TMP_NAME_} == $1 ]] ; then
      [[ -n $2 ]] && mv "${_TMP_NAMES_ARRAY_[${_TMP_NAME_}]}" "$2"
      unset ${_TMP_NAMES_ARRAY_[${_TMP_NAME_}]}
      return
    fi
  done
  _USAGE_CHOICE_ "Temporary ${Name} \"$1\" does not exist."
}

##________________________________________________________________________________
##
## TMP_DIR_PERMANENT - Like TMP_FILE_PERMANENT but works for temporary directories
##                     instead of files.
function TMP_DIR_PERMANENT() {
  TMP_FILE_PERMANENT --DIR "$@"
}

##________________________________________________________________________________
##
## TRIM - Returns STRING with surrounding whitespace removed.
##        Whitespace within STRING will not be changed.
##   Usage: TRIM "STRING"
function TRIM() {
  local VAL
  read VAL <<<"$1"
  echo -n "${VAL}"
}

##________________________________________________________________________________
##
## USAGE - External stub for normal error processing.
##         Calls USAGE_DEFAULT passing all arguments.
##   Usage: USAGE [OPTIONS] [MESSAGE]
##   Where: OPTIONS and MESSAGE are described in USAGE_DEFAULT below.
##   Depending upon USAGE it will exit the script with a return code of 1
##     or will return to the script with a return code of 2
##   The calling script may redefine this function to implement its own USAGE.
##   ================================================
##   =  NOTE: The function GET_ARGS must be called  =
##   =        prior to calling any USAGE function.  =
##   ===============================================
function USAGE() {
  USAGE_DEFAULT "$@"
  return $?
}

# ________________________________________________________________________________________________
#
# Internal USAGE_DEFAULT stub for internal error processing.
# If LOCAL_USAGE is not set, it will invoke the normal USAGE routine which may be redefined by the calling routine.
function _USAGE_CHOICE_() {
  _ERROR_MESSAGE_="$@"
  (( LOCAL_USAGE )) && USAGE_DEFAULT "$@" || USAGE "$@"
  return $?
}

##________________________________________________________________________________
##
## USAGE_DEFAULT - Default help and error function.
##     Displays an optional message  possibly followed by a "USAGE" message.
##   Usage: USAGE [ MESSAGE... ]
##   Where: MESSAGE is the message to be displayed.
##          If missing a default message is displayed.
##   If MESSAGE is an (internal?) error, it is displayed on stderr.
##     Otherwise it is displayed on stdout.
##   ================================================
##   =  NOTE: The function GET_ARGS must be called  =
##   =        prior to calling any USAGE function.  =
##   ===============================================
function USAGE_DEFAULT() {
  local EXTRA_INFO U_A_I
  if [[ $1 == - ]] ; then				# Must be a HELP_CODE
    local USAGE_ARG_2
    USAGE_ARG_2="${2:1:1}"				# Get the second character as the first is a single quote
    if [[ -n $2 && ${_b_}${VALID_FILTER_CODES} =~ "${USAGE_ARG_2}" ]] ; then	# Right. But is it valid?
      [[ ${USAGE_ARG_2} != ${_a_} ]] && _GET_ARGS_Section_INSERT_ "--Filter" "P" "FILTERED HELP for filter code ${USAGE_ARG_2}: \"${FILTER_HELP_TEXT[${USAGE_ARG_2}]}\""
      shift 2
    else
      _ERROR_MESSAGE_="${FILTER_HELP_MESSAGE_PFX}\n  ${_option_h_/ /}<FC>[<FM>]  ${_option_H_/ /}<FC>[<FM>]  ${_option_help_/ /}=<FC>[<FM>]  ${_option_HELP_/ /}=<FC>[<FM>]  ${FILTER_HELP_MESSAGE_SFX}" 2>&1
      echo -e "${_ERROR_MESSAGE_}" 1>&2
      exit 1
    fi
  fi
  if (( $# > 0 )) ; then
    (( $# > 1 )) && { _HEADING_="${CMD}: ${1}: " ; shift 1 ; } || _HEADING_="${CMD}: "
    _ERROR_MESSAGE_="${_HEADING_}${USAGE_ERROR_PREFIX}${*}" 1>&2
    if (( IS_USAGE_EXIT )) ; then			# If 'returning' then do not issue the 'Try...' line
      _ERROR_MESSAGE_+="\nTry \"${CMD} -${_h_}\" or \"${CMD} --${_help_}\" for more information." 1>&2
    fi
    echo -e "${_ERROR_MESSAGE_}" 1>&2
    (( IS_USAGE_EXIT )) && exit 2 || { IS_USAGE_EXIT="${OLD_IS_USAGE_EXIT}" ; return 2 ; }
  fi
  if (( _FILTER_IS_ON_ )) ; then
    EXTRA_INFO=" Omit the optional filter <FM> to get a list of acceptable filter values."
  else
    EXTRA_INFO=" An <FM> of ${_b_} (brief), ${_c_} (compact) or ${_e_} (expand) will modify the help display."
  fi
  if (( ${#_USAGE_h_} + ${#_USAGE_help_} + 1 > TAB_STOP_WIDTH ))
    then _GET_ARGS_Section_INSERT_ "--help" "B" "${_USAGE_h_}${_USAGE_help_}\n\t\tDisplay this information and exit.${EXTRA_INFO}"
    else [[ -n ${_USAGE_h_}${_USAGE_help_} ]] && _GET_ARGS_Section_INSERT_ "--help" "B" "${_USAGE_h_}${_USAGE_help_}\tDisplay this information and exit.${EXTRA_INFO}"
  fi
  if (( ${#_USAGE_H_} + ${#_USAGE_HELP_} + 1 > TAB_STOP_WIDTH ))
    then _GET_ARGS_Section_INSERT_ "--HELP" "B" "${_USAGE_H_}${_USAGE_HELP_}\n\t\tDisplay this information with \"less\" as a screen pager and exit.${EXTRA_INFO}"
    else [[ -n ${_USAGE_H_}${_USAGE_HELP_} ]] && _GET_ARGS_Section_INSERT_ "--HELP" "B" "\n\t${_USAGE_H_}${_USAGE_HELP_}\tDisplay this information with \"less\" as a screen pager and exit.${EXTRA_INFO}"
  fi
  _GET_ARGS_Section_INSERT_ "--test" "B" "${_option_t_}${_option_test_}\n\t\tTest the script. Commands preceeded by \"\${TEST_CMD}\" are displayed rather than executed.\n\t\tAny cleanup scripts (delete tmp files & mounts etc.) are executed unless the keyword ${_NO_CLEANUP_} (case insensitive) is specified. Then no cleanup operations will be executed. This option may be used with any OPTIONS or ACTIONS above."
  if [[ ${_option_v_}${_option_version_} == -${_v_}\ --${_version_}\  ]]
    then _GET_ARGS_Section_INSERT_ "--version" "B" "${_option_v_}${_option_version_}\n\t\tDisplay the version and exit."
    else [[ -n ${_option_v_}${_option_version_} ]] && _GET_ARGS_Section_INSERT_ "--version" "B" "\n\t${_option_v_}${_option_version_}\tDisplay the version and exit."
  fi
  if [[ -n ${USAGE_ACTION_INFO} ]] ; then
    U_A_I="${USAGE_ACTION_INFO/ /[}"
    U_A_I+="] "
  fi
  _GET_ARGS_Section_INSERT_ "USAGE" "S" "${CMD}${USAGE_ACTION_INFO}${_USAGE_OPTIONS_}${USAGE_GET_ARGS}"
  _GET_ARGS_Section_INSERT_ "USAGE" "S" "${CMD} ${U_A_I}BASIC_OPTION${USAGE_GET_ARGS}${_USAGE_BASIC_OPTION1_}"

  THE_MESSAGE="${CMD}${_HEADING_}${EXTRA_NL}${USAGE_SECTION_TEXT[P]}${EXTRA_HELP_MESSAGE}${USAGE_SECTION_TEXT[S]}${USAGE_SECTION_TEXT[s]}${USAGE_SECTION_TEXT[D]}${USAGE_SECTION_TEXT[A]}${USAGE_SECTION_TEXT[O]}${USAGE_SECTION_TEXT[B]}${USAGE_SECTION_TEXT[b]}${USAGE_SECTION_TEXT[W]}${USAGE_SECTION_TEXT[I]}${USAGE_SECTION_TEXT[E]}${USAGE_SECTION_TEXT[C]}${USAGE_SECTION_TEXT[N]}${USAGE_SECTION_TEXT[n]}"

  if [[ ${_FM_brief_} == ${_b_} ]] ; then
    TMP_FILE_CREATE HELP_OUT
    eval echo -e '"${THE_MESSAGE}"' ${TEST_PIPE} expand --initial --tabs=\\${TAB_STOP_WIDTH} ${_USAGE_FORMAT_} --width=$COLUMNS ${TEST_OUT} "${HELP_OUT}"
    echo -e "EOF" >> "${HELP_OUT}"
    eval gawk -v Columns="${COLUMNS}" --file \"${COMMON_FUNCTIONS_DIR}/.functions.sh.USAGE_BRIEF.gawk\" \"${HELP_OUT}\" ${_USAGE_less_}
  else
    eval echo -e '"${THE_MESSAGE}"' ${TEST_PIPE} expand --initial --tabs=\\${TAB_STOP_WIDTH} ${_USAGE_FORMAT_} ${_USAGE_less_}
  fi
  unset LOCAL_USAGE
  (( IS_USAGE_EXIT )) && exit 2 || { IS_USAGE_EXIT="${OLD_IS_USAGE_EXIT}" ; return 2 ; }
}

##________________________________________________________________________________
##
## ERROR_PREFIX - Alias for ERROR_SET_PREFIX
function ERROR_PREFIX() {
  ERROR_SET_PREFIX "$@"
}

##________________________________________________________________________________
##
## USAGE_SET - Function to invoke a USAGE control function using an option.
##   Usage: USAGE_SET OPTION
##          OPTION may be:
##            -E  USAGE_SET_EXIT
##            -F  USAGE_FORCE_RETURN
##            -R  USAGE_SET_RETURN
## -P [-R] "PFX"  ERROR_SET_PREFIX [ -R ] "PFX" ...
function USAGE_SET() {
  local ARG
  case "$1" in
    -E)
      USAGE_SET_EXIT ;;
    -F)
      USAGE_FORCE_RETURN ;;
    -P)
      [[ $2 == -R ]] && ARG="$2"
      shift 2
      ERROR_SET_PREFIX ${ARG} "$@"
      ;;
    -R)
      USAGE_SET_RETURN ;;
     *)
      _USAGE_CHOICE_ "ERROR: USAGE_SET: Argument 1 must be one of -E, -F, -P OR -R."
  esac
}

##________________________________________________________________________________
##
## USAGE_SET_EXIT - Exit after displaying an error message.
##   From this point forward, the USAGE and ERROR functions exit with an
## This is the default.
function USAGE_SET_EXIT() {
  IS_USAGE_EXIT="1"
}
USAGE_SET_EXIT						# Default is to exit if USAGE function is called.

##________________________________________________________________________________
##
## USAGE_EXIT - Alias for USAGE_SET_EXIT
function USAGE_EXIT() {
  USAGE_SET_EXIT
}

##________________________________________________________________________________
##
## USAGE_SET_RETURN - Return after displaying an error message.
##   From this point forward, the USAGE and ERROR functions return with an
##   error code of 2 rather than exit the script.
function USAGE_SET_RETURN() {
  unset IS_USAGE_EXIT
}

##________________________________________________________________________________
##
## USAGE_RETURN - Alias for USAGE_SET_RETURN
function USAGE_RETURN() {
  USAGE_SET_RETURN
}

##________________________________________________________________________________
##
## USAGE_FORCE_RETURN - Issue a USAGE message and return even if set to USAGE_EXIT
function USAGE_FORCE_RETURN() {
  OLD_IS_USAGE_EXIT="${IS_USAGE_EXIT}"
  unset IS_USAGE_EXIT
  USAGE_DEFAULT "$@"
}

##________________________________________________________________________________
##
## USAGE_OBSOLETE - Issue a default 'obsolete' message and 'exit' irrespective
##                  of USAGE_RETURN. The exit code is 2.
##   Usage: USAGE_OBSOLETE [ ARGS ]
##   If no ARGS present the default message displayed is:
##       The script "${CMD}" is obsolete.
##   If only one argument then the default message is displayd followed by the
##     contents of '$1' on a new line.
##   Otherwise the 1st argument replaces the default message and is displayed
##     followed by the contents of the remaining arguments.
##   Include this function at the beginning of an obsolete script.
##   The message is displayed on stderr.
function USAGE_OBSOLETE() {
  local DEFAULT_MESSAGE="The script \"${CMD}\" is obsolete."
  if (( $# == 1 )) ; then
    DEFAULT_MESSAGE+="\\n$1"
  elif (( $# > 1 )) ; then
    DEFAULT_MESSAGE="$@"
  fi
  echo -e "${DEFAULT_MESSAGE}" 1>&2
  exit 2
}

##________________________________________________________________________________
##
## OBSOLETE - Alias for USAGE_OBSOLETE
function OBSOLETE() {
  USAGE_OBSOLETE "$@"
}

##________________________________________________________________________________
##
## USAGE_FORCE_OBSOLETE - Call  USAGE_OBSOLETE with a different default message.
##   Usage: USAGE_FORCE_OBSOLETE [ ARGS... ]
##   Display the default message and ARGS.
##      Exit forced. This script "${CMD}" is obsolete.
function USAGE_FORCE_OBSOLETE() {
  USAGE_OBSOLETE "Exit forced. This script \"${CMD}\" is obsolete." "$@"
}

##________________________________________________________________________________
##
## ERROR_SET_PREFIX - Change the ERROR message prefix
##   Usage: ERROR_SET_PREFIX [ -R ] [ ARGS... ]
##   Where: ARGS Replace the default prefix proceeding any ERROR message.
##   No trailing space is added. The default(in red characters) is: "ERROR: "
##   If the first ARG is "-R" (raw) then the the prefix is printed as is (no
##     red characters).
##   Calling this function with no ARGS resets the prefix to the default.
function ERROR_SET_PREFIX() {
  local blk red
  [[ $1 == -R ]] && { unset blk red ; shift 1 ; } || { blk="${BLK}" ; red="${RED}" ; }
  if (( $# == 0 ))
    then export USAGE_ERROR_PREFIX="${red}ERROR:${blk} " # Default USAGE message prefix.
    else export USAGE_ERROR_PREFIX="${red}$*${blk}"
  fi
}
ERROR_SET_PREFIX					# Default USAGE message prefix.

##________________________________________________________________________________
##
## WARNING - Simple error reporting with no USAGE message.
##   The message is displayed on stderr.
function WARNING() {
  echo -e "${WARNING_ERROR_PREFIX}""$@" 1>&2
  return 2
}

##________________________________________________________________________________
##
## WARNING_SET_PREFIX - Change the  WARNING message prefix.
##   Usage: WARNING_SET_PREFIX [ -R ] [ ARGS... ]
##   Where: ARGS Replace the default prefix proceeding any WARNING message.
##   No trailing space is added. The default (in purple characters) is:
##     "WARNING: "
##   If the first ARG is "-R" (raw) then the the prefix is printed as is (no
##     purple characters).
##   Calling this function with no ARGS resets the prefix to the default.
function WARNING_SET_PREFIX() {
  local pur
  [[ $1 == -R ]] && { pur="${BLK}" ; shift 1 ; } || pur="${PUR}"
  if (( $# == 0 ))
    then export WARNING_ERROR_PREFIX="${pur}WARNING:${BLK} "	# Default WARNING message prefix.
    else export WARNING_ERROR_PREFIX="${pur}$*${BLK}"
  fi
}
WARNING_SET_PREFIX					# Default WARNING message prefix.

##________________________________________________________________________________
##
## ZERO_FILL - Display a zero-filled NUMBER of size NUMDIGITS.
##   Usage: ZERO_FILL NUMBER [ NUMDIGITS ]
##   Where: NUMDIGITS is the size of the displayed number. It defaults to 2.
##          If length NUMBER > NUMDIGITS, NUMBER is returned.
function ZERO_FILL() {
  ((${#1} < ${2:-2} )) && eval "printf '0%.0s' {1..$((${2:-2}-${#1}))}"
  echo -n "$1"
}

##________________________________________________________________________________
##
## END of help for "functions.sh"

