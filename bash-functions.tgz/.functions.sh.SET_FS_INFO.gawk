#!/usr/bin/gawk -f

# gawk script to extract pertinent system device and filesystem information from the output of the command:
#       for Device in $(lsblk --nodeps --noheadings --paths | cut -f1 -d\  ) ; do lsblk --output Name,Type,FStype,UUID,MountPoint --pairs --sort MountPoint --paths $Device ; echo "Name="$Device" : Type="END\"" ; done | \
#       gawk --assign=Assoc="" --assign All="" --assign Ignore="sdb" --file /usr/local/bin/.functions.sh.SET_FSInfo.gawk

# VERSION="02.01.01 - Jul 31, 2019"

function AssignVars(	EqualLocation,Arg) {
  delete VariableArray					# clean up previous variable values
  for(Arg = 1 ; Arg <= NF ; ++Arg) {			# walk through fields
    EqualLocation = index($Arg, "=")			# search for =
    if (EqualLocation > 0) {				# if there is one:
      VariableArray[substr($Arg, 1, EqualLocation - 1)] = substr($Arg, EqualLocation + 1)
    }
  }
  Name       = gensub("\"", "", "g", VariableArray["NAME"])
  Type       = gensub("\"", "", "g", VariableArray["TYPE"])
  FStype     = gensub("\"", "", "g", VariableArray["FSTYPE"])
  UUID       = gensub("\"", "", "g", VariableArray["UUID"])
  MountPoint = gensub("\"", "", "g", VariableArray["MOUNTPOINT"])
}

function CheckPart1Part2(GoToNext) {
      if (IsThisLV == "") {
        if (PartitionInfo1 != "") SaveOneFS(PartitionArrayName1, PartitionInfo1)
        if (PartitionInfo2 != "") SaveOneFS(PartitionArrayName2, PartitionInfo2)
      }
      else {
        if (PartitionInfo2 != "") {	# Check the second one first as it is the boot partition
          PartitionArrayName = sprintf(LVarrayName2, SavedLVpartitionNumber, ++LVcounter)
          SaveOneFS(PartitionArrayName, PartitionInfo2)
        }
        if (PartitionInfo1 != "") {
          PartitionArrayName = sprintf(LVarrayName1, SavedLVpartitionNumber, ++LVcounter)
          SaveOneFS(PartitionArrayName, PartitionInfo1)
        }
        IsThisLV = ""
      }
      PartitionInfo1 = "" ; PartitionInfo2 = ""
      if (GoToNext != "") next
    }

function GetName(Value) {
  return substr(Value, 1, match(Value,"[0-9][0-9]*$") - 1)
}

function GetNumber(Value) {
  return substr(Value, match(Value,"[0-9][0-9]*$"))
}

function RecordIgnored(What,It,IsAll) {
  if ( IsAll != "" ) return			# If 'IsAll' not empty, include all devices/partitions
  Ignored = Ignored " '" What "(" It ")'"
  next
}

function SaveOneFS(ArrayName,FSinfo) {
  if (FSinfo != "") {
    printf(DeclareFormat, ArrayName, ArrayName)
    printf(FSArrayFormat, ArrayName, FSinfo)
    IDX = 0
  }
}

function SetDeviceOrPartitionForIgnore(This) {
  if (Ignore != "" && This ~ Ignore) {
     IgnoreIt = This
     RecordIgnored(Type,This " by request",All)
  }
  else IgnoreIt = ""
}

function SetLVandVGinfo(Value) {
  LVdevice = Value
  LVID = gensub(".*/", "", 1, LVdevice)
  LogicalVol = gensub("--", ";;","g", LVID)
  split(LogicalVol, VG_LV, "-")
  VolGroup = VG_LV[1]
  gsub(";;", "-", VolGroup)
  LogicalVol = VG_LV[2]
  gsub(";;", "-", LogicalVol)
  if (IsThisLV == "") IsThisLV = VolGroup
  }

BEGIN {
         ArrayFormat = "\n%s=( %s )\n"
       DeclareFormat = "\nunset %s\ndeclare -Agx %s\n"
     ArrayNameFormat = "FILESYSTEM_%s_%s_%s_%s_%s_%s"
       FSArrayFormat = "FILESYSTEMS+=( [%s]=%s )\n"
         FSidxFormat = "'[%s]=\"%s\" [%s]=\"%s\" [%s]=\"%s\" [%s]=\"%s\" [%s]=\"%s\" [%s]=\"%s\" [%s]=\"%s\"'"
     FSassocLVformat = "'[FS_DEV]=\"%s\" [LV_PART]=\"%s\" [FS_VG]=\"%s\" [FS_LV]=\"%s\" [FS_UUID]=\"%s\" [FS_TYPE]=\"%s\" [FS_MOUNT]=\"%s\"'"
   FSassocPartFormat = "'[FS_DEV]=\"%s\" [FS_PART]=\"%s\" [FS_VG]=\"%s\" [FS_LV]=\"%s\" [FS_UUID]=\"%s\" [FS_TYPE]=\"%s\" [FS_MOUNT]=\"%s\"'"
           IDXFormat = "\nFS_DEV_IDX=%d ; FS_PART_IDX=%d ; FS_VG_IDX=%d ; FS_LV_IDX=%d ; FS_UUID_IDX=%d ; FS_TYPE_IDX=%d ; FS_MOUNT_IDX=%d\n"
      Comment1Format = "\n# FILESYSTEM_... logical volume array legend: [%s]=Device, [%s]=Partition, [%s]=VolGroup, [%s]=LogicalVol, [%s]=UUID, [%s]=FStype, [%s]=MountPoint\n"
      Comment2Format =   "# FILESYSTEM_... partition array legend:      [%s]=Device, [%s]=Partition, [%s]=\"\",       [%s]=\"\",         [%s]=UUID, [%s]=FStype, [%s]=MountPoint\n"
  printf("%s\n\n%s\n%s\n","#!/bin/bash", "unset FILESYSTEMS", "declare -Agx FILESYSTEMS")
  if (Assoc == "") {
    IDX = 0 ; printf(IDXFormat,      IDX++, IDX++, IDX++, IDX++, IDX++, IDX++, IDX++)
    IDX = 0 ; printf(Comment1Format, IDX++, IDX++, IDX++, IDX++, IDX++, IDX++, IDX++)
    IDX = 0 ; printf(Comment2Format, IDX++, IDX++, IDX++, IDX++, IDX++, IDX++, IDX++)
  }
  else {
    Assoc = "yes"
    IDX = 0 ; printf(Comment1Format, "FS_DEV", "LV_PART", "FS_VG", "FS_LV", "FS_UUID", "FS_TYPE", "FS_MOUNT" )
    IDX = 0 ; printf(Comment2Format, "FS_DEV", "FS_PART", "FS_VG", "FS_LV", "FS_UUID", "FS_TYPE", "FS_MOUNT" )
  }
  printf("\n# First create this script with:\n#\tLSBLK=\"for Device in $(lsblk --nodeps --noheadings --paths | cut -f1 -d\\ ) ; do\n#\t  lsblk --output Name,Type,FStype,UUID,MountPoint --pairs --sort MountPoint --paths $Device ; echo Name=\\\"$Device\\\" Type=\\\"END\\\"\n#\tdone\"\n")
  printf(  "#\tgawk=\"/root/tmp/.functions.sh.SET_FSInfo.gawk\"")
  printf(  "# Then execute the following:\n#\t$LSBLK | gawk --assign Assoc=\"%s\" --assign All=\"\" --assign Ignore=\"\" --file ${gawk} >& CreateArrays.sh\n", Assoc)
  printf(  "# Then'source' this script with:\n#\tsource Create_Arrays.sh\n#\n")
  printf(  "# To list the set of filesystem arrays use:\t\techo ${!FILESYSTEMS[*]} | sed -e 's/ /\\n/g' | sort -t_ -k 2,2 -k 3n,3 -k 4n,4\n")
  printf(  "# To display the unique VGs/partitions use:\t\techo ${!FILESYSTEMS[*]} | sed -e 's/ /\\n/g' | sort -t_ -k 2,2 -k 3n,3 -k 4n,4 | uniq -w 15\n")
  printf(  "# To access info about partition 1 on 'sde' use:\teval ONE_FS=( ${FILESYSTEMS[FILESYSTEM_e_1_1_X_X_Partition]} )\n")
  if (Assoc == "") printf(  "# And to get all the info or just the UUID use:\t\techo \"${ONE_FS[*]}   ${ONE_FS[$FS_UUID_IDX]} ...\"\n")
  else printf(  "# And to get all the info or just the UUID use:\t\techo \"${ONE_FS[*]}   ${ONE_FS[FS_UUID]} ...\"\n")
  IDX = 0
  if ( Ignore != "" ) Ignore = "^" gensub(",", "|^", "g", Ignore) ""
  Devices = "" ; Ignored = ""
  IsThisLV = "" ; LVpartitionCount = 0 ; SavedLVcounter = 0
  PartitionInfo1 = "" ; PartitionInfo2 = ""
  }

END {
  printf(ArrayFormat, "FILESYSTEMS_DEVICES", Devices)
  printf(ArrayFormat, "FILESYSTEMS_IGNORED", Ignored)
  }

# Process every line
  {
  AssignVars( )
  print >/dev/stderr
  switch (Type) {				# Check whet type of drive/partition/LV

    case "disk": {
      Device = Name
      Devices = Devices " " Device
      DeviceName = gensub("/dev/", "", "g", Device)
      DeviceID = gensub("^..", "", "1", DeviceName)
      VolGroup = ""
      SetDeviceOrPartitionForIgnore(Device)
      RecordIgnored(Name,"device", All)	# Record thet is was ignored
      break
    }

    case "part": {
      if ( UUID == "" ) RecordIgnored(Name,"no filesystem", All)	# Ignore anything without a filesystem
      Partition = Name
      PartitionName = gensub("/dev/", "", "g", Partition)
      PartitionNumber = GetNumber(PartitionName)
      ###if (PartitionNumber >       ) SetDeviceOrPartitionForIgnore(Partition)
      if (FStype == "LVM2_member") {		# This partition contains a logical volume or volume group
        IsThisLV = PartitionName
        LVpartition = Partition
        LVpartitionNumber = GetNumber(PartitionName)
        LVpartitionCount = ++LVpartitionCount
        LVcounter = 1				# Leave room for the root LV
        SetDeviceOrPartitionForIgnore(Partition)
        RecordIgnored(Name,"VG partition", All)	# Record it
      }
      if (Assoc == "") PartitionInfo = sprintf(FSidxFormat, IDX++, Device, IDX++, Partition, IDX++, "", IDX++, "", IDX++, UUID,  IDX++, FStype, IDX++, MountPoint)
      else PartitionInfo = sprintf(FSassocPartFormat, Device, Partition, "", "", UUID,  FStype, MountPoint)
      IDX = 0
      PartitionArrayName = sprintf(ArrayNameFormat, DeviceID, PartitionNumber, 1, "x", "x", "PART")
      switch(PartitionNumber) {
        case 1: {
          LVarrayName1 = sprintf(ArrayNameFormat, DeviceID, "%d", "%d", "x", "x", "EFI")
          PartitionInfo1 = PartitionInfo
          PartitionArrayName1 = PartitionArrayName
          break
          }
        case 2: {
          LVarrayName2 = sprintf(ArrayNameFormat, DeviceID, "%d", "%d", "x", "x", "BOOT")
          PartitionInfo2 = PartitionInfo
          PartitionArrayName2 = PartitionArrayName
          break
          }
        default: {
          SaveOneFS(PartitionArrayName, PartitionInfo)
          break
          }
      }
      break
    }

    case "lvm": {
      SetLVandVGinfo(Name)
      if (UUID == "") RecordIgnored(LVID, "no filesystem", All)	# Ignore anything without a filesystem
      if (IgnoreIt != "") RecordIgnored(Type, LVID, All)
      CheckPart1Part2("")
      if ( MountPoint == "[SWAP]") LogicalVolName = "SWAP" ; else LogicalVolName = LogicalVol
      if (Assoc == "") LVinfo = sprintf(FSidxFormat, IDX++, Device, IDX++, LVpartition, IDX++, VolGroup, IDX++, LogicalVol, IDX++, UUID,  IDX++, FStype, IDX++, MountPoint)
      else LVinfo = sprintf(FSassocLVformat, Device, LVpartition, VolGroup, LogicalVol, UUID,  FStype, MountPoint)
      IDX = 0
      if (MountPoint == "/" || LogicalVol == "root") {
        LVarrayName = sprintf(ArrayNameFormat, DeviceID, LVpartitionNumber, 1, VolGroup, LogicalVol, "LVM")
      }
      else {
        LVarrayName = sprintf(ArrayNameFormat, DeviceID, LVpartitionNumber, ++LVcounter, VolGroup, LogicalVol, "LVM")
      }
      SaveOneFS(LVarrayName, LVinfo)
      if (LVpartitionCount == 1) {
        SavedLVcounter = LVcounter
        SavedLVpartitionNumber = LVpartitionNumber
      }
      break
    }

    case  "END": {			# Marks the end of one device
      CheckPart1Part2("")
      LVpartitionCount = 0
      break
    }
  }
  next
}
