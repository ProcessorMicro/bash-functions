#!/bin/bash
# ======================================================
# This file contains useful functions. They are:
#   DEBUG_SCRIPT Use 'set -x' leaving standard file
#                descriptors free.
#   FUNCTIONS    Loads functions.sh into the environment
# ======================================================
# Copy this file into the /etc/profile.d directory with:
#
#   cp extra-bash-functions.sh /etc/profile.d
# ======================================================
#
# Copyright © 2013-2023 by Mike Armstrong
#
# This script is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software
# Foundation; either version 3 of the License, or any later version.
#
# This script is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
# PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy (the file 'LICENSE') of the GNU General Public
# License along with this script; if not, see <https://www.gnu.org/licenses>.


# DEBUG_SCRIPT - Debug a script with "set -x" putting all debug output
#   into a file in ~/tmp while leaving file descriptors 0, 1 and 2 available.
# Usage: DEBUG_SCRIPT { -d | [ -f NUM ] BASH_SCRIPT SCRIPT_ARGS }
# Where:  -f NUM  Will use file descriptor NUM. The default is 9.
#         -d      Will (interactively) delete all files named [~]/tmp/bash-x-*.
#         BASH_SCRIPT  Is the bash script to ve debugged with "-x"
#         SCRIPT_ARGS  Are any arguments needed/wanted in the debug process.
function DEBUG_SCRIPT () {
  local BASH_X FDX
  [[ -d ~/tmp ]] && BASH_X=~/tmp/bash-x- || BASH_X=/tmp/bash-x-
  if [[ $1 == -d ]] ; then
    eval rm -i ${BASH_X}*
    return
  elif [[ $1 == -f ]] ; then
    FDX="${2}"
    shift 2
  fi
  BASH_X+="$$"
  FDX="${FDX:-9}"
  eval exec ${FDX}\>\>\"${BASH_X}\"	# Open the file descriotor
  export BASH_XTRACEFD="${FDX}"		# Set bash trace to write to it
  # Run the command traping all debug output to a file
  eval bash --login -x -c \"\$*\" ${FDX}\>\"${BASH_X}\"
  set +x
  unset BASH_XTRACEFD
  echo -e "
Debug output of \"$1\" is in file \"${BASH_X}\".
Remove it with \"DEBUG_SCRIPT -d\"."
}

# FUNCTIONS will load the functions.sh script into the current environment
#   and set all EXITs to RETURNs.
function FUNCTIONS () {
  set +x
  source ${1:-functions.sh}
  USAGE_RETURN
}
