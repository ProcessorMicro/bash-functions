#!/usr/bin/gawk -f

# This gawk script is executed by the GET_ARGS function in /usr/local/bin/functions.sh
# It provides a pre-scan of the GET_ARGS_OPTIONS and of the calling script options
# to extract a possible help <code> filter and to enable changing the option character
# for the basic options (help,test and version).

# The following variables must be assigned with -v on the gawk command line that
# calls this script.
#    _a_  _b_   _c_  _e_
#    _h_  _help_   _H_  _HELP_     _t_  _test_    _v_  _version_
#    BasicOptsLHS     DefaultTabStopWidth
#
# It returns several (bash) variable assignments

# VERSION="02.02.03 - Apr 27,2023"

BEGIN {
  Opt_D_OPLISTS = " "
}

END {
  if ( Compress ) CreateVar("EXTRA_NL","")
  if ( TabStop )  CreateVar("TAB_STOP_WIDTH",TabStop)
  if ( BasicOptsLHSModified ) CreateVar("BASIC_OPTS",BasicOptsLHS)
}

# AnalyzeHelpCodes is only called if the parent script HELP is requested.
# Args: 1='-'or '--', 2=Help_Code, 3='' or '=', 4=Parsed_OptionArray
# Parsed_OptionArray index: 1=Help, 2=Help_Option, 3=<FC> or <FM>, 4=<FM> if 2=<FC>, 4 or 5=final "'"
function AnalyzeHelpCodes(Pre,Help,Post,Codes,	Idx,Filter) {
  Filter = ""
  if ( Codes[4] Codes[5] !~ "'" ) {			# 4th or 5th element must be a "'"
    Filter = gensub(/[' ]/,"","g",Codes[0])
    Error("Too many <filter> codes or missing code: " Filter "\nA maximum of two alphanumeric <filter> codes is allowed.")
  }
  CreateVar("_REMAKE_SAVED_", 1)
  for (Idx = 2 ; Idx <= 3 ; Idx++) {
    if ( Codes[Idx] ~ /'/ ) {
        break
    } else if ( Codes[Idx] == _b_ ) {
        CreateVar("_FM_brief_", _b_)
        continue
    } else if ( Codes[Idx] == _c_ ) {
        Compress = 1
        TabStop = DefaultTabStopWidth
        continue
    } else if ( Codes[Idx] == _e_ ) {
        continue
    } else if ( Codes[Idx] ~ /^[[:alnum:]]$/ ) {
        Filter = Codes[Idx]
        continue
    } else if ( Codes[Idx] == "" ) {
        continue
    } else if ( Idx > 3 ) {
        Filter = gensub(/[' ]/,"","g",Codes[0])
        Error("Too many <filter> codes or invalid code: " Filter "\nA maximum of two alphanumeric <filter> codes is allowed.")
    }
  }
  Do_It(Help,Filter)
}

function CreateVar(Var,Val) {
  printf(" %s=\"%s\" ;",Var,Val)
}

function Do_It(HelpMatch,FilterCode) {
  if ( index(Opt_D_OPLISTS,HelpMatch ) == 0) {
    if ( FilterCode ~ /\W/ ) {
      if ( FilterCode == "'" ) FilterCode = ""		# This happens if HelpMatch is the last character in the arg
    }
  }
  CreateVar("FILTER_CODE",FilterCode)
  exit 0						# No need to continue
}

function Error(Message) {
  printf(" ERROR \"GET_ARGS: %s\" ; ",Message)
  exit 2
}

function FilterError() {
  Error("All '--Filter' GET_ARGS_OPTIONS must preceed any GET_ARGS_OPTION that uses a filter code 'FC'.")
  }

# Here we change any basic option <code> to another <CODE>
function GetBasicOption(BasicOption,	LHside,LHsideOrig,RHside,RHsideOrig,TheMatch) {
  TheMatch = index(BasicOption, "=")
  if ( TheMatch == 0 ) Error("Incorrectly formatted GET_ARGS_OPTION \\\"--Bas_O " BasicOption "\\\". The correct format is \\\"OLDOPT=NEWOPT\\\".")
  LHsideOrig = substr(BasicOption, 1, TheMatch - 1)
  RHsideOrig = substr(BasicOption, TheMatch + 1)
  LHside = LHsideOrig
  RHside = RHsideOrig
  if ( LHside == _all_ || LHside == _brief_ || LHside == _compact_ || LHside == _expand_ ) LHside = substr(LHside,1,1)
  if ( length(LHside) == 1 ) RHside = substr(RHside, 1, 1)
  switch ( LHside ) {
    case "h":       { _h_       = RHside ; break }
    case "H":       { _H_       = RHside ; break }
    case "help":    { _help_    = RHside ; break }
    case "HELP":    { _HELP_    = RHside ; break }
    case "t":       { _t_       = RHside ; break }
    case "test":    { _test_    = RHside ; break }
    case "v":       { _v_       = RHside ; break }
    case "version": { _version_ = RHside ; break }
   #case "all":					# Not needed
    case "a":       { _a_ = GetAnnotation(RHsideOrig, "_a_msg_")
                      RHside = _a_
                      break }
   #case "brief":				# Not needed
    case "b":       { _b_ = GetAnnotation(RHsideOrig, "_b_msg_")
                      RHside = _b_
                      break }
   #case "compact":				# Not needed
    case "c":       { _c_ = GetAnnotation(RHsideOrig, "_c_msg_")
                      RHside = _c_
                      break }
   #case "expand":				# Not needed
    case "e":       { _e_ = GetAnnotation(RHsideOrig, "_e_msg_")
                      RHside = _e_
                      break }
    default: Error("For GET_ARGS_OPTION \\\"--Bas_O " BasicOption "\\\", the LHS \\\"" LHsideOrig "\\\" must be one of:\\n\\t" BasicOptsLHS)
  }
  if ( match(BasicOptsLHS, " " RHside " ") > 0 ) Error("For GET_ARGS_OPTION \\\"--Bas_O " BasicOption "\\\", \\\"" RHside "\\\" is already in use.")
  gsub(" " LHsideOrig " ", " " RHside " ", BasicOptsLHS)
  CreateVar("_" LHside "_", RHside)
  BasicOptsLHSModified = 1
}

function GetAnnotation(TheRHside,Var,	TheMatch) {
  TheMatch = index(TheRHside, "@")
  if ( TheMatch > 0 ) CreateVar(Var, substr(TheRHside, TheMatch + 1) )
  else TheMatch = 2
  return substr(TheRHside, 1, 1)
}

# Do a prescan to process --Filter, --Bas_O, --Compact, --Save, --Tab GET_ARGS_OPTIONS.
function Prep_It(	ExpectingFilterGoTo,GoToForNextArg,Idx,OneArg,Pos,Result,Tokins) {
  BaseIdx = 1
  Pos = match($0,/ '--'/)				# Find the first '--'
  ParentArgs = substr($0,Pos+4)				# Get the parent script options without the '--'
  $0 = substr($0,1,Pos+1)				# Reset $0 to just have the GET_ARGS_OPTIONS and '--'
  FilterPos = match($0,"'--Filter'")			# Find the character position of the 1st --Filter (if any)
  if ( FilterPos > 0 ) {					# Found one...
    ExpectingFilterGoTo = 2				# Want to skip FC arg
    CreateVar("EXPECTING_FILTER",1)
  } else {
    ExpectingFilterGoTo = 3				# Next arg is the OPTLIST1
    CreateVar("EXPECTING_FILTER",0)
  }
  # Now look for special GET_ARGS_OPTIONS
  split($0,OneArg,"' '")
  GoToForNextArg = 1					# This is equivalent to "ignore me"
  for (Idx in OneArg) {					# Look at each GET_ARGS_OPTION
    if ( OneArg[Idx] == "--" ) break			# No more GET_ARGS_OPTIONS
    if ( ( FilterPos > 0 ) && OneArg[Idx] ~ /^--/ ) {	# Check if any <FC> options preceed --Filter
      OptionPart = substr(OneArg[Idx],3,3)
      if ( OptionPart !~ /Fil|Bas|Com|Exe|Hea|Sav|Tab/)  {	# Only if uses FC, ie NOT one of these
        OptionPos = match($0," '--" OptionPart)		# So get the position
        if ( OptionPos < FilterPos ) FilterError()
        if ( match(substr($0,OptionPos),/'--Filter'/) > 0 ) FilterError()
        FilterPos = 0					# So we only test once
      }
    }
    switch (GoToForNextArg) {
      case 1: {
        # If it is an option description (--Act_D,--Hid_D,--Opt_D) then get the OPTLIST
        # so we can see all the options defined
        if ( OneArg[Idx] ~ /^--(Act|Hid|Opt)[a-z]*_D[a-z]*$/ ) {
          GoToForNextArg = ExpectingFilterGoTo
          break }
        if ( OneArg[Idx] ~ /^--Bas[a-z]*_O[a-z]*$/ ) {
          GoToForNextArg = 4
          break }
        if ( OneArg[Idx] ~ /^--Tab[a-z]*$/ ) {
          GoToForNextArg = 5
          break }
        if ( OneArg[Idx] ~ /^--Comp[a-z]*$/ ) {
          Compress = 1
          TabStop = DefaultTabStopWidth
          GoToForNextArg = 1
          break }
        if ( OneArg[Idx] == "--Save" ) {
          CreateVar("SAVE_VARIABLES",1)
          GoToForNextArg = 1
          break }
        break }
      case 2: {						# This is the FC
        GoToForNextArg = 3				# It is ignored
        break }
      case 3: {						# This is the OPTLIST of each --Opt_D
        OptList=gensub(/@.*/,"","1",OneArg[Idx])	# Remove any "@..."
        Opt_D_OPLISTS = Opt_D_OPLISTS " " gensub(/[*:]/,"","g",OptList) " "	# Remove any ':' or '*'
        GoToForNextArg = 1
        break }
      case 4: {
        GetBasicOption(OneArg[Idx])
        GoToForNextArg=1
        break }
      case 5: {
        if ( OneArg[Idx] !~ /^[0-9]+$/ ) Error("For option \\\"--Tab " OneArg[Idx] "\\\", the tab width \\\"" OneArg[Idx] "\\\" is not numeric.")
        TabStop = OneArg[Idx]
        GoToForNextArg=1
        break }
      case 9: {						# Ignore this argument
        GoToForNextArg = 1
        break }
    }
  }
}

# The input is a single line containing all of the GET_ARGS options
{ Prep_It()
  # Prep_It has scanned $0. Now need to look at all parent script args following
  # the GET_ARGS_OPTIONS (after '--') to see if help is requested.
  Start = match(ParentArgs, " '(--" _help_ "[= ']*)(.?)(.?)(.*)(')", Result)
  if ( Start ) AnalyzeHelpCodes("--", _help_, "=", Result)

  Start = match(ParentArgs, " '(--" _HELP_ "[= ']*)(.?)(.?)(.*)(')", Result)
  if ( Start ) AnalyzeHelpCodes("--", _HELP_,"=", Result)

  Start = match(ParentArgs, " '-\\w*(" _h_ "[ ']*)(.?)(.?)(.*)(')", Result)
  if ( Start ) AnalyzeHelpCodes("-", _h_, " ", Result)

  Start = match(ParentArgs, " '-\\w*(" _H_ "[ ']*)(.?)(.?)(.*)(')", Result)
  if ( Start ) AnalyzeHelpCodes("-", _H_, " ", Result)

  CreateVar("FILTER_CODE","")				# There is no help so no filter code
  CreateVar("_REMAKE_SAVED_", 0)
}
