#!/bin/bash

SCRIPT_PURPOSE="This script shows examples of GET_ARGS_OPTIONS for the GET_ARGS function.\n\tGET_ARGS is a fully featured bash function that enables easy generation and\n\tmanagement of parent script command-line options and arguments.\n\tIt also generates manpage-like help."

SCRIPT_VERSION="01.01.01 - Jul 10, 2022"

# Locate common functions.
COMMON_FUNCTIONS="$(type -p functions.sh)"
[[ -x ${COMMON_FUNCTIONS} ]] && source "${COMMON_FUNCTIONS}" || { echo -e "Cannot locate \"${COMMON_FUNCTIONS:-functions.sh}\"." 1>&2 ; exit ; }

Cmd="script.sh"
WHICH_ONE="0"					# The default ment

function DISPLAY_MENU() {
  local LAST_ONE MENU PROMPT
  while true ; do
    MENU="Menu${WHICH_ONE}"
    if (( WHICH_ONE )) ; then
      PROMPT="invalid combinations of options and arguments."
      LEGEND="    Note: y=this menu, n=next menu (Examples of options and arguments)\n"
    else
      PROMPT="valid option and argument combinations."
      LEGEND="    Note: y=this menu, n=next menu (Examples of errors)\n"
    fi
    ASK_WITH_MENU -1 -H "\n    Type a number to execute an example of ${PROMPT}\n    \"${Cmd}\" is a simulated parent script containing the same GET_ARGS_OPTIONS as in\n    \"${CMD}\" and implemented with the hidden option: --Hid_d \"EXEC EXECUTE\".\n" ${MENU}
    eval LAST_ONE=\"\${\#${MENU}[*]}\"
    if (( ANSWER_IDX < LAST_ONE -1 )) ; then
      break
    else
      WHICH_ONE="$(( (WHICH_ONE + 1) % 2 ))"
    fi
  done
}

function DO_IT() {
  DISPLAY_MENU
  ANSWER_VAL="${ANSWER_VAL/${Cmd}/${CMD} --EXEC}"
  eval ${ANSWER_VAL%#*}
  ASK -yn -D y -L "${LEGEND}" "\nSelection \"${ANSWER}\" finished. Display menu again?"
  [[ ${ANSWER} == n ]] && WHICH_ONE="$(( (WHICH_ONE + 1) % 2 ))"
}

function MAKE_MENUS() {
  # First menu - combinatons of options and arguments.
  Menu0+=( "${Cmd} -H 				# Display the filters available." )
  Menu0+=( "${Cmd} -Ha				# Display all help (with 'less')." )
  Menu0+=( "${Cmd} -hb				# Display the basic GET_ARGS_OPTS" )
  Menu0+=( "${Cmd} -hi				# Display the informatipn GET_ARGS_OPTS" )
  Menu0+=( "COLUMNS=80 ${Cmd} -Ha			# Show line folding simulated 80-column terminal" )
  Menu0+=( "COLUMNS=500 ${Cmd} -ha | less -S	# No line folding. Use ← → to see ling lines" )
  Menu0+=( "${Cmd} -b -x CCC -a --exclude ddd	# Display the variables created" )
  Menu0+=( "${Cmd} file1 file2			# Display the argument values" )
  Menu0+=( "${Cmd} file1 file2 -c f1		# Display a mixture of arguments and options" )
  Menu0+=( "${Cmd} 				# Default set by: \"IS_EXCLUSIVE --Default a d e\"" )
  Menu0+=( "${Cmd} --edit				# --edit overrides --Default set above " )
  Menu0+=( "Switch menu to examples of errors." )
  # Second menu - Sample errors.
  Menu1+=( "${Cmd} -z				# Error because option -z was not defined" )
  Menu1+=( "${Cmd} file1			# Error because of \"--Args_Opt 2@FILE\"" )
  Menu1+=( "${Cmd} -cf1 --copy-it:=f2		# Error because of: \"IS_EXCLUSIVE c C\"" )
  Menu1+=( "${Cmd} 				# " )
  Menu1+=( "${Cmd} 				# " )
  Menu1+=( "Switch menu to examples of options and arguments." )
}

#echo "OPT=$OPT ; VAR=$VAR ; COUNT=$COUNT ; INDICES=$INDICCES"
PARSE_OPTIONS_AND_ARGS() {
  local COUNT FOUNDOPTS IDX INDICES OPTSALL OLDOPT OPT VAL VAR
  echo -e "\nThe variables/arguments created by the simulated script:\n\t${@}\n"
  OPTSALL="${Opts_All// /}"
  if [[ -n ${OPTSALL/--EXEC/} ]] ; then
    unset OPTSALL
    FOUNDOPTS="YES"
    { echo -e "${UL}OPTION${BLK};${UL}OPTi${BLK};${UL}VALUE${BLK}"
      for OPT in ${Opts_All[*]} ; do
      [[ ${OPT} =~ ^--EXEC ]] && continue
      [[ ${OPTSALL} =~ \ ${OPT}\  ]] && continue
      OPTSALL+=" ${OPT} "
        [[ ${OPT} =~ ^-- ]] && VAR="${OPT:2}" || VAR="${OPT:1}"	# Strip leading "-"
        VAR="Opt_${VAR//-/_}"			# Convert into a variable name
        eval COUNT=\"\${${VAR}}\"
        INDICES=$( eval echo {0..$((COUNT-1))} )
        for IDX in ${INDICES} 99 ; do
          (( IDX == 99 )) && break
          eval VAL=\"\${${VAR}_Val[IDX]}\"
          if [[ -z ${VAL} ]] ; then
            echo -e "${OPT};${VAR}=${COUNT};"
          else
            if [[ ${OPT} == ${OLDOPT} ]] ; then
              echo -e ";;${VAR}_Val[${IDX}]=\"${VAL}\""
            else
              echo -e "${OPT};${VAR}=${COUNT};${VAR}_Val[${IDX}]=\"${VAL}\""
            fi
          fi
          OLDOPT="${OPT}"
        done
      done
    } | column --table --separator=";" | sed -e 's/^/    /'
  fi
  if (( ${#Args[*]} > 0 )) ; then		# Any args?
    [[ -n ${FOUNDOPTS} ]] && echo		# Need a blank line
    { echo -e "${UL}ARG${BLK};${UL}VALUE${BLK}"
      for IDX in ${!Args[*]} ; do
        echo -e "Args[${IDX}];${Args[IDX]}"
      done
    } | column --table --separator=";" | sed -e 's/^/    /'
  fi
  #[[ -n ${FOUNDOPTS} && ${#Args[*]} -gt 0 ]] && echo
}

  #--Bas_O  b=hello@"THIS IS A HELLO"  \
  #--Bas_O   "brief=X@XCCCCCCCCCCCCCCCCC" \
GET_ARGS \
  --Header "\t\tHello there" \
  --Bas_O   "b=X@CCCCCCCCCCCCCCCCCC" \
  --Filter  t "Display all --Title GET_ARGS_OPTION." \
  --Filter  p "Display all --Paragraph GET_ARGS_OPTION." \
  --Filter  T "Display all --Title and --Paragraph GET_ARGS_OPTIONS." \
  --Filter  P "Display all --Title and --Paragraph GET_ARGS_OPTIONS." \
  --Filter  C "bbb" \
  --Para  CpTP    S "A paragraph in SYNOPSYS" \
  --Para  CpTP    s "a paragraph in mysynopsys" \
  --Para  CpTP -N B "A paragraph in BASIC OPTIONS" \
  --Para  CpTP    b "A paragraph in mybasicoptions" \
  --Para  CpTP -N B "Another paragraph in BASIC OPTIONS" \
  --Para  pTP  -N O "A paragraph" \
  --Opt_D C   "a: aaa:@FILES"	--Des_D "aaaaa aaaaaaa aaaa" \
  --Opt_D C   "b bb"		--Des_D "bbb adsdas a asd as as as das as as" \
  --Title CtTP    O "TiTlE that is a long title" \
  --Title CtTP    O "TiTlE that is a long title" \
  --Para  CpTP    O "A paragraph in OPTIONS" \
  --Opt_D C   "c"		--Des_D "Full help message can" \
  --Para   pTP -N C "A paragraph in COPYRIGHT" \
  --Copy a \
  --Para   pTP -N C "A paragraph in COPYRIGHT" \
  --Para   pTP    N "A paragraph in NOTE" \
  --Args_None a \
  --Para  CpTP    n "A paragraph in mynote" \
  -- "$@"

exit
  #--Bas_O  b=Sugar@"A brief message"  \

  #--Action b     "This option was created with the GET_ARGS_OPTION: --Action." \
GET_ARGS \
  --Bas_O all="x@Show all help\t\t\t(--Bas_O all=\"x@Show...\")." \
  --Filter b     "Show simple GET_ARGS_OPTS\t(--Filter b \"Show...\")." \
  --Filter i     "Show information GET_ARGS_OPTS\t(--Filter i \"Show...\")." \
  --Args_Opt a 2@PATTERN \
  --Bas_O "h=z@aaa" \
  --Basic_Option "b=s@Help summarized. Default \\\"b\\\" changed to \\\"s\\\" with: --Bas_O \\\"b=s@Help summ...\\\"" \
  --Cmd_D        "The full help message can be displayed with the command:\n\t\t${CMD} -Ha\n\tIt shows examples of how GET_ARGS_OPTIONS can create parent script options and how a help display is created.\n\tIn addition it demonstrates the --Filter GET_ARGS_OPTION that enables a selective help display. To see this, type the command:\n\t\t${CMD} -H\n\tThis multi-line \"paragraph\" (using \\\n\\\t) was created with the GET_ARGS_OPTION: --Para b \"The full...\\\n\"\n\tIt is in the DESCRIPTION section created by the --Title above." \
  --Cmd_D        "The full help message can be displayed with the command:\n\t\t${CMD} -Ha\n\tIt shows examples of how GET_ARGS_OPTIONS can create parent script options and how a help display is created.\n\tIn addition it demonstrates the --Filter GET_ARGS_OPTION that enables a selective help display. To see this, type the command:\n\t\t${CMD} -H\n\tThis multi-line \"paragraph\" (using \\\n\\\t) was created with the GET_ARGS_OPTION: --Para b \"The full...\\\n\"\n\tIt is in the DESCRIPTION section created by the --Title above." \
  --Comp --Tab 3 \
  --Action a     "ACTION" \
  --Title bi "A TITLE CREATED WITH: --Title bi \"A TITLE...\"" \
  --Para  bi -N "Para 1" \
  --Act_D  b "a add" -O -A -I "\t# Add the ..." \
                                        --Des_D "Basic option format. If the parent script is invoked with -a or --add, a variable \"Opt_a=1\" is created.\n\t\tThis option was created with the GET_ARGS_OPTION: --Opt_D s \"a add\"" \
  --Title bi "A TITLE CREATED WITH: --Title bi \"A TITLE...\"" \
  --Para  bi -N "Para 1" \
  --Opt_D  b "both-the-parts btp b"	--Des_D "Basic option format. If the parent script is invoked with --both-the-parts, --btp or -b a variable \"Opt_both_the_parts=1\" is created (with  all \"-\" converted to "_"). Note: the Opt_X variables are always named from the first OPTi in OPTLIST.\n\t\tThis option was created with the GET_ARGS_OPTION: --Opt_D s \"both-parts b bp\"" \
  --Opt_D  b "c: copy-the-file:" 	--Des_D "This option requires a VALUE. If the parent script is invoked with -cmyfile or --copy-the-file=myfile, variables \"Opt_c=1\" and \"Opt_c_Val=myfile\" are created.\n\t\tThis option was created with the GET_ARGS_OPTION: --Opt_D s \"c: copy-the-file:\"" \
  --Opt_D  b "C: copy-it:@FILE"		--Des_D "Like -c above except the \"@FILE\" is more descriptive. Variables \"Opt_C=1\" and \"Opt_C_Val=FILE\" are created.\n\t\tThis option was created with the GET_ARGS_OPTION: --Opt_D s \"C: copy-it:@FILE\"" \
  --Act_D  b "d delete" -O -A -I "\t# Delete the ..." \
                                        --Des_D "Basic option format. If the parent script is invoked with -d or --delete, a variable \"Opt_d=1\" is created.\n\t\tThis option was created with the GET_ARGS_OPTION: --Opt_D s \"d delete\"" \
  --Opt_D  b "D:: directory::@DIR"	--Des_D "Like -C above except DIR is optional (so the parent script must establish a default DIR). Variables \"Opt_d=1\" and \"Opt_d_Val=DIR\" are created. If DIR is missing Opt_d_Var=\"\".\n\t\tThis option was created with the GET_ARGS_OPTION: --Opt_D b \"D:: directory::@DIR\"" \
  --Act_D  b "e edit" -O -A -I "\t# Edit the ..." \
                                        --Des_D "Basic option format. If the parent script is invoked with -e or --edit, a variable \"Opt_e=1\" is created.\n\t\tThis option was created with the GET_ARGS_OPTION: --Opt_D s \"e edit\"" \
  --Opt_D  b "*x: exclude:@EXPATTERN"	--Des_D "\n\t\tThis option was created with the GET_ARGS_OPTION: ." \
  --Hid_D  a "EXEC EXECUTE"		--Des_D "A hidden option causing script to analyze the options rather than display a menu of examples." \
  --Title bi "A TITLE CREATED WITH: --Title bi \"A TITLE...\"" \
  --Where  i "Where www\n\tThis option was created with the GET_ARGS_OPTION: --Where \"...\"" \
  --Info   i "Info zzz\n\tThis option was created with the GET_ARGS_OPTION: --Info \"...\"" \
  --Exam   i "Example yyy\n\tThis option was created with the GET_ARGS_OPTION: --Exam \"...\"" \
  --Para   i "A paragraph is defined anywhere after the last --Opt_D will always immediately preceed the section \"BASIC OPTIONS\".\n\tThis option was created with the GET_ARGS_OPTION: --Para i \"A paragraph...\"\n" \
  --Para   b -N "This is a second paragraph (without a preceeding newline) generated by: --Para b -N \"This is...\\\n\"\n" \
  --Para  bi "This paragraph (and the A TITLE... header above) has a \"bi\" --Filter so it will appear either with -hb or -hi.\n\tThis option was created with the GET_ARGS_OPTION: --Para bi \"This paragraph...\"\n" \
  --Copy abc \
  -- "$@"
#  --Opt_D  ""			--Des_D "\n\t\tThis option was created with the GET_ARGS_OPTION: ." \

IS_EXCLUSIVE c C
IS_EXCLUSIVE a d e
IS_EXCLUSIVE --Default a d e

MAKE_MENUS
while true ; do
  if (( Opt_EXEC )) ; then
    ARGS="${@}"
    PARSE_OPTIONS_AND_ARGS "${Cmd} ${ARGS/--EXEC /}"
    exit
  else
    DO_IT
  fi
done

