#!/usr/bin/gawk -f

# This gawk script is executed by the GET_ARGS function in /usr/local/bin/functions.sh
# It provides a pre-scan of the GET_ARGS_OPTIONS and of the calling script options
# to extract a possible help <code> filter and to enable changing the option character
# for the basic options (help,test and version).

# The following variables must be assigned with -v on the gawk command line that
# calls this script.
#    _b_           _c_             _e_
#    _h_  _help_   _H_  _HELP_     _t_  _test_    _v_  _version_
#    BasicOpts     DefaultTabStopWidth

# VERSION="02.02.01 - Aug 27,2022"

BEGIN {
  Opt_D_Args = " "
}

END {
  if (Compress) CreateVar("EXTRA_NL","")
  if (TabStop)  CreateVar("TAB_STOP_WIDTH",TabStop)
  if (BasicOptsModified) CreateVar("BASIC_OPTS",BasicOpts)
}

function CreateVar(Var,Val) {
  printf(" %s=\"%s\" ;",Var,Val)
}

function Do_It(HelpMatch,FilterCode) {
  if (index(Opt_D_Args,HelpMatch) == 0) {
    if (FilterCode ~ /\W/ ) {
      if (FilterCode == "'") FilterCode = ""		# This happens if HelpMatch is the last character in the arg
    }
  }
  CreateVar("FILTER_CODE",FilterCode)
  exit 0						# No need to continue
}

function Error(Message) {
  printf(" ERROR \"GET_ARGS: %s\" ; ",Message)
  exit 2
}

function FilterError() {
  Error("All '--Filter' GET_ARGS_OPTIONS must preceed any GET_ARGS_OPTION that uses a filter code 'FC'.")
  }

# Here we change any basic option <code> to another <CODE>
function GetBasicOption(BasicOption,	LHside,LHsideOrig,RHside,RHsideOrig,Tmatch) {
  Tmatch = index( BasicOption, "=" )
  if ( Tmatch == 0 ) Error("For GET_ARGS_OPTION \\\"--Bas_O " BasicOption "\\\",\\\"" BasicOption "\\\" is missing a \\\"=\\\".")
  LHside = substr( BasicOption, 1, Tmatch - 1 )
  RHside = substr( BasicOption, Tmatch + 1 )
  LHsideOrig = LHside
  RHsideOrig = RHside
  if ( LHside == _brief_ || LHside == _compact_ || LHside == _expand_ ) LHside = substr(LHside,1,1)
  if ( length(LHside) == 1 ) RHside = substr(RHside,1,1)
  if ( match(BasicOpts," " RHside " ") > 0 ) Error("For GET_ARGS_OPTION \\\"--Bas_O " BasicOption "\\\",\\\"" RHside "\\\" is already in use.")
  switch ( LHside ) {
    case "h":       { _h_ = RHside       ; break }
    case "H":       { _H_ = RHside       ; break }
    case "help":    { _help_ = RHside    ; break }
    case "HELP":    { _HELP_ = RHside    ; break }
    case "t":       { _t_ = RHside       ; break }
    case "test":    { _test_ = RHside    ; break }
    case "v":       { _v_ = RHside       ; break }
    case "version": { _version_ = RHside ; break }
    case "c":       { _c_ = RHside       ; break }
    #case "compact": { _c_ = RHside       ; break }
    case "e":       { _e_ = RHside       ; break }
    #case "expand":  { _e_ = RHside       ; break }
    case "brief":   { LHside = substr(LHside,1,1)}
    case "b":       { _b_ = RHside
                      Tmatch = index(RHsideOrig,"@")
                      if ( Tmatch > 0 ) {
                        CreateVar( "_USAGE_brief_", substr(RHsideOrig, Tmatch + 1) )
                        RHside = substr(RHsideOrig, 1, Tmatch - 1)
                      }
                      break }
    default:        Error("For GET_ARGS_OPTION \\\"--Bas_O " BasicOption "\\\", \\\"" LHside "\\\" must be one of:\\n\\t" BasicOpts)
  }
  CreateVar("_" LHside "_",RHside)
  gsub(" " LHsideOrig " "," " RHside " ",BasicOpts)
  BasicOptsModified = 1
}

# Do a prescan to process --Filter, --Bas_O, --Compact, --Tab GET_ARGS_OPTIONS.
function Prep_It(	ExpectingFilterGoTo,GetArgs,GoToForNextArg,Idx,OneArg,Result,Tokins) {
  BaseIdx = 1
  GetArgs = " ' " gensub(/'--'.*$/,"",1,$0) " ' "	# Look at only the GET_ARGS_OPTIONS
  FilterPos = match(GetArgs,"'--Filter'")
  if (FilterPos > 0 ) {
    ExpectingFilterGoTo = 2				# Want to skip FC arg
    CreateVar("EXPECTING_FILTER",1)
    if (match(GetArgs,/('--Filter')\s+('-A')\s+('.)/, Result)) {
      CreateVar("_FILTER_CODE_ALL_",substr(Result[3],2)) }
  } else {
    ExpectingFilterGoTo = 3				# Next arg is the OPTLIST1
    CreateVar("EXPECTING_FILTER",0)
  }
  # Even if there in no --Filter there may be a filter code of b\"b" or "B" so...
  split(GetArgs,OneArg,"' '")
  GoToForNextArg = 1
  for (Idx in OneArg) {
    if (OneArg[Idx] == "--" ) break			# No more GET_ARGS_OPTIONS
    if ((FilterPos > 0) && OneArg[Idx] ~ /^--/) {
      OptionPart = substr(OneArg[Idx],3,3)
      if (OptionPart !~ /Fil|Bas|Hea|Com|Tab|Exe/) {
        OptionPos = match(GetArgs," '--" OptionPart)
        if (OptionPos < FilterPos) FilterError()
        if (match(substr(GetArgs,OptionPos),/'--Filter'/) > 0) FilterError()
        FilterPos = 0					# So we only test once
      }
    }
    switch (GoToForNextArg) {
      case 1: {
        # If it is an option description (--Act_D,--Hid_D,--Opt_D) then get the OPTLIST
        # so we can see all the options defined
        if (OneArg[Idx] ~ /^--(Act|Hid|Opt)[[:alpha:]]*_D[[:alpha:]]*$/) {
          GoToForNextArg = ExpectingFilterGoTo
          break }
        if (OneArg[Idx] ~ /^--Bas[[:alpha:]]*_O[[:alpha:]]*$/) {
          GoToForNextArg = 4
          break }
        if (OneArg[Idx] ~ /^--Tab[[:alpha:]]*$/) {
          GoToForNextArg = 5
          break }
        if (OneArg[Idx] ~ /^--Comp[[:alpha:]]*$/) {
          Compress = 1
          TabStop = DefaultTabStopWidth
          GoToForNextArg = 1
          break }
        break }
      case 2: {						# This is the FC (it is ignored)
        GoToForNextArg = 3
        break }
      case 3: {						# This is the --Opt_D OPTLIST
        OptList=gensub(/@.*/,"","1",OneArg[Idx])	# Remove any "@..."
        Opt_D_Args = Opt_D_Args " " gensub(/:/,"","g",OptList) " "
        GoToForNextArg = 1
        break }
      case 4: {
        GetBasicOption(OneArg[Idx])
        GoToForNextArg=1
        break }
      case 5: {
        if ( OneArg[Idx] !~ /^[0-9]+$/ ) Error("For option \\\"--Tab " OneArg[Idx] "\\\", the tab width \\\"" OneArg[Idx] "\\\" is not numeric.")
        TabStop = OneArg[Idx]
        GoToForNextArg=1
        break }
      case 9: {						# Ignore this argument
        GoToForNextArg = 1
        break }
    }
  }
}

# The input is a single line containing all of the GET_ARGS options
{ Prep_It()
  # Prep_It has scanned $0. Now need to look at all args after the GET_ARGS_OPTIONS (after '--').
  ParentArgs = " " gensub(/^.*'--'/,"",1,$0) " "	# Just look at the parent script options

  Start = match(ParentArgs," '(--" _help_ "[= ']*)(.?)(.?)(.*)(')",Result)
  if (Start) AnalyzeHelpCodes("--",_help_,"=",Result)

  Start = match(ParentArgs," '(--" _HELP_ "[= ']*)(.?)(.?)(.*)(')",Result)
  if (Start) AnalyzeHelpCodes("--",_HELP_,"=",Result)

  Start = match(ParentArgs," '-\\w*(" _h_ "[ ']*)(.?)(.?)(.*)(')",Result)
  if (Start) AnalyzeHelpCodes("-",_h_," ",Result)

  Start = match(ParentArgs," '-\\w*(" _H_ "[ ']*)(.?)(.?)(.*)(')",Result)
  if (Start) AnalyzeHelpCodes("-",_H_," ",Result)

  CreateVar("FILTER_CODE","")				# There is no help so no filter code
}

function AnalyzeHelpCodes(Pre,Help,Post,Codes,	Idx,Filter) {
  Filter = ""
  if (Codes[4] Codes[5] != "'") {
    Filter = gensub(/[' ]/,"","g",Codes[0])
    Error("Too many <filter> codes or invalid code: " Filter "\nA maximum of two alphanumeric <filter> codes is allowed.")
  }
  for (Idx = 2 ; Idx <= 3 ; Idx++ ) {
    if (Codes[Idx] ~ /'/) {
        break
    } else if ((Codes[Idx]) == _b_) {
        CreateVar("_FILTER_CODE_brief_",_b_)
        continue
    } else if (Codes[Idx] == _c_) {
        Compress = 1
        TabStop = DefaultTabStopWidth
        continue
    } else if (Codes[Idx] ~ /^[[:alnum:]]$/) {
        Filter = Codes[Idx]
        continue
    } else if (Codes[Idx] == "") {
        continue
    } else if (Idx > 3) {
        Filter = gensub(/[' ]/,"","g",Codes[0])
        Error("Too many <filter> codes or invalid code: " Filter "\nMaximum of two alphanumeric codes allowed.")
    }
  }
  Do_It(Help,Filter)
}

function Dummy() {
if (Start) printf("Code=%s<  Len=%d<  0=%s<  1=%s<  2=%s<  3=%s<  4=%s<\n", _help_,length(Result),Result[0],Result[1],Result[2],Result[3],Result[4]) > "/dev/stderr"
if (Start) printf("Code=%s<  Len=%d<  5=%s<  6=%s<  7=%s<  8=%s<  9=%s<\n", _help_,length(Result),Result[5],Result[6],Result[7],Result[8],Result[9]) > "/dev/stderr"
if (Start) printf("Code=%s<  Len=%d<  0=%s<  1=%s<  2=%s<  3=%s<  4=%s<\n", _HELP_,length(Result),Result[0],Result[1],Result[2],Result[3],Result[4]) > "/dev/stderr"
if (Start) printf("Code=%s<  Len=%d<  5=%s<  6=%s<  7=%s<  8=%s<  9=%s<\n", _HELP_,length(Result),Result[5],Result[6],Result[7],Result[8],Result[9]) > "/dev/stderr"
if (Start) printf("    Code=%s<  Len=%d<  0=%s<  1=%s<  2=%s<  3=%s<  4=%s<\n", _h_,length(Result),Result[0],Result[1],Result[2],Result[3],Result[4]) > "/dev/stderr"
if (Start) printf("    Code=%s<  Len=%d<  5=%s<  6=%s<  7=%s<  8=%s<  9=%s<\n", _h_,length(Result),Result[5],Result[6],Result[7],Result[8],Result[9]) > "/dev/stderr"
if (Start) printf("    Code=%s<  Len=%d<  0=%s<  1=%s<  2=%s<  3=%s<  4=%s<\n", _H_,length(Result),Result[0],Result[1],Result[2],Result[3],Result[4]) > "/dev/stderr"
if (Start) printf("    Code=%s<  Len=%d<  5=%s<  6=%s<  7=%s<  8=%s<  9=%s<\n", _H_,length(Result),Result[5],Result[6],Result[7],Result[8],Result[9]) > "/dev/stderr"
#     Code=H<  Len=18<  0= '-H' 'abcd'<  1=H' '<  2=a<  3=b<  4=cd<
#     Code=H<  Len=18<  5='<  6=<  7=<  8=<  9=<

#     Code=H<  Len=18<  0= '-HA' '-c' '-b'<  1=H<  2=A<  3='<  4= '-c' '-b<
#     Code=H<  Len=18<  5='<  6=<  7=<  8=<  9=<
printf "1 Idx=""%s""  Codes[Idx]=""%s""  Filter=""%s""\n",Idx,Codes[Idx], Filter > "/dev/stderr"
printf "2 Idx=""%s""  Codes[Idx]=""%s""  Filter=""%s""\n",Idx,Codes[Idx], Filter > "/dev/stderr"
printf "3 Idx=""%s""  Codes[Idx]=""%s""  Filter=""%s""\n",Idx,Codes[Idx], Filter > "/dev/stderr"
printf "4 Idx=""%s""  Codes[Idx]=""%s""  Filter=""%s""\n",Idx,Codes[Idx], Filter > "/dev/stderr"
printf "5 Idx=""%s""  Codes[Idx]=""%s""  Filter=""%s""\n",Idx,Codes[Idx], Filter > "/dev/stderr"
printf "6 Idx=""%s""  Codes[Idx]=""%s""  Filter=""%s""\n",Idx,Codes[Idx], Filter > "/dev/stderr"
printf "7 Idx=""%s""  Codes[Idx]=""%s""  Filter=""%s""\n",Idx,Codes[Idx], Filter > "/dev/stderr"
printf "8 Idx=""%s""  Codes[Idx]=""%s""  Filter=""%s""\n",Idx,Codes[Idx], Filter > "/dev/stderr"
printf "9 Idx=""%s""  Codes[Idx]=""%s""  Filter=""%s""\n",Idx,Codes[Idx], Filter > "/dev/stderr"
  }

