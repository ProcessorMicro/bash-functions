#!/usr/bin/gawk -f

BEGIN {
  Padding = "                                                "
  Pass = 1
  MaxIdx = 0
}

function Rewind(    i) {		# Rewind the current file and start over
  for (i = ARGC; i > ARGIND; i--)	# Shift remaining arguments up
      ARGV[i] = ARGV[i-1]
  ARGC++				# Make sure gawk knows to keep going
  ARGV[ARGIND+1] = FILENAME		# Make current file next to get done
  nextfile				# Do it
}

# This function is no longer used,
function GetRecordCount(    Cmd) {	# Get the total number of records
  Cmd = "wc -l " FILENAME
  while ( (Cmd | getline NumRec) > 0 ) NumRec = gensub(" .*$", "", 1, NumRec)
  close( Cmd )
}

function PadField(theField,theLen) {
  return substr(theField Padding, 1, theLen)
}

function ProcessOptionsLine(    idx,len) {
  if ( NF == 0 ) return 1
  for ( idx = 1 ; idx <= NF ; idx++ ) {
    if ( substr( $idx, 1, 1 ) != "-" ) return 1
  }
  if ( Pass == 1 ) {			# Pass 1 determinse the longest 'options' field
    for ( idx = 1 ; idx <= NF ; idx++ ) {
      len = length( $idx )
      if ( len > 0 + MaxLen[idx] ) MaxLen[idx] = len
    }
    if ( idx > MaxIdx ) MaxIdx = idx
    return 0
  } 					# Pass 2 actually extracts the brief info
  for ( idx = 1 ; idx <= MaxIdx ; idx++) {
    if ( idx <= NF ) {
      if ( idx == 1 ) Indent = "  "
      printf( "%s%s", Indent, PadField( $idx, MaxLen[idx] ) )
    } else {
      printf( " %s", PadField( "", MaxLen[idx] ) )
    }
    Indent = " "
  }
  return 0
}

{ if ( Pass == 1 ) {			# Get the max length of each option on an "options" line
    ProcessOptionsLine()
    if ( $0 == "EOF" ) {		# Is this the last record
      OptionsLen = 0
      for ( idx = 1 ; idx <= MaxIdx ; idx++ ) {
        OptionsLen += MaxLen[idx]
      }
      Pass=2				# Yup - so do it all again
      ProcessNext = 0
      Got_Synopsis = 0
      MaxLength = Columns - OptionsLen - ( MaxIdx * 2 )
      Rewind()
    }
  }
  if ( Pass == 2 ) {
    if ( ProcessNext == 0 ) {
      if ( Got_Headers == 0 ) {
	if ( $0 !~ /^\s*$|FILTERED HELP|BASIC_OPTION/ ) print $0
      } else {
        LineTrimmed = gensub(/^\s+/, "  ", 1, $0)
        if ( $1 ~ /ACTION/ ) StripFrom = 2
	else StripFrom = 1
        print substr ( LineTrimmed, 1, MaxLength )
      }
    }
    if ( Got_Headers == 0) {
      if ( $1 == "OPTIONS" ) {
	Got_Headers = 1
        ProcessNext = 1
      }
    } else {
      ProcessNext = ProcessOptionsLine()
    }
  }
}

